import React from 'react';
import { getThemeConfig } from '../ReaderUtils/themeUtils';

interface LoadingViewProps {
  theme: string;
}

const LoadingView: React.FC<LoadingViewProps> = ({ theme }) => {
  const themeConfig = getThemeConfig(theme as any);
  
  return (
    <div 
      className="absolute inset-0 flex items-center justify-center z-50"
      style={{ backgroundColor: themeConfig.bg }}
    >
      <div className="text-center">
        <div 
          className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4"
          style={{ borderColor: themeConfig.text }}
        />
        <p style={{ color: themeConfig.text }}>加载中...</p>
      </div>
    </div>
  );
};

export default LoadingView;