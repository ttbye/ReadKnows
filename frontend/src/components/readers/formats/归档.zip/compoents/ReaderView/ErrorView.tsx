import React from 'react';
import { getThemeConfig } from '../ReaderUtils/themeUtils';

interface ErrorViewProps {
  error: string;
  theme: string;
}

const ErrorView: React.FC<ErrorViewProps> = ({ error, theme }) => {
  const themeConfig = getThemeConfig(theme as any);
  
  return (
    <div 
      className="absolute inset-0 flex items-center justify-center z-50"
      style={{ backgroundColor: themeConfig.bg }}
    >
      <div className="text-center px-4">
        <div 
          className="text-6xl mb-4"
          style={{ color: themeConfig.text }}
        >
          ⚠️
        </div>
        <h2 
          className="text-xl font-semibold mb-2"
          style={{ color: themeConfig.text }}
        >
          加载失败
        </h2>
        <p 
          className="text-sm"
          style={{ color: themeConfig.text, opacity: 0.8 }}
        >
          {error}
        </p>
      </div>
    </div>
  );
};

export default ErrorView;

