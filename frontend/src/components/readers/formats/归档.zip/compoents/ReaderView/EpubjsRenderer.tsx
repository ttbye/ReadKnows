import React, { useCallback, useEffect, useRef } from 'react';
import { ReadingSettings } from '../../types/reader';
import { parseTOC, getTotalChapters } from '../ReaderUtils/epubUtils';
import { applyThemeToDOM } from '../ReaderUtils/themeUtils';
import toast from 'react-hot-toast';

interface EpubjsRendererProps {
  containerRef: React.RefObject<HTMLDivElement>;
  fileUrl: string;
  initialPosition?: any;
  settings: ReadingSettings;
  onReady?: (data: { book: any; rendition: any }) => void;
  onProgress?: (progress: number, position: any) => void;
  onTOCLoaded?: (toc: any[]) => void;
}

export const EpubjsRenderer: React.FC<EpubjsRendererProps> = ({
  containerRef,
  fileUrl,
  initialPosition,
  settings,
  onReady,
  onProgress,
  onTOCLoaded,
}) => {
  const bookRef = useRef<any>(null);
  const renditionRef = useRef<any>(null);
  const isInitializedRef = useRef(false);
  
  const setupEventListeners = useCallback((rendition: any, onProgress?: (progress: number, position: any) => void) => {
    const handleRelocated = (location: any) => {
      if (!onProgress) return;
      
      try {
        const spineIndex = location.start?.index ?? 0;
        const cfi = location.start?.cfi;
        const chapterCurrentPage = location.start?.displayed?.page || 1;
        const chapterTotalPages = location.start?.displayed?.total || 1;
        
        // 计算进度
        const withinChapter = chapterTotalPages > 1 && chapterCurrentPage >= 1
          ? Math.min(1, Math.max(0, (chapterCurrentPage - 1) / chapterTotalPages))
          : 0;
        
        const totalChapters = getTotalChapters(bookRef.current);
        const progress = Math.min(1, Math.max(0, (spineIndex + withinChapter) / totalChapters));
        
        const position = {
          chapterIndex: spineIndex,
          currentPage: chapterCurrentPage,
          totalPages: chapterTotalPages,
          progress,
          currentLocation: cfi,
        };
        
        onProgress(progress, position);
      } catch (error) {
        console.error('计算进度失败:', error);
      }
    };
    
    rendition.on('relocated', handleRelocated);
    
    // 监听 rendered 事件，在内容渲染后应用样式
    const handleRendered = () => {
      if (settings) {
        setTimeout(() => {
          applyThemeToDOM(rendition, settings);
        }, 100);
      }
    };
    
    rendition.on('rendered', handleRendered);
    
    // 保存清理函数
    (rendition as any).__cleanup = () => {
      rendition.off?.('relocated', handleRelocated);
      rendition.off?.('rendered', handleRendered);
      // 移除错误处理
      if ((rendition as any).__errorHandler) {
        window.removeEventListener('error', (rendition as any).__errorHandler, true);
      }
    };
  }, [settings]);
  
  const initEpubjs = useCallback(async () => {
    if (!containerRef.current || isInitializedRef.current) return;
    
    try {
      const { default: ePub } = await import('epubjs');
      const container = containerRef.current;
      
      // 确保容器有尺寸
      if (container.offsetWidth === 0 || container.offsetHeight === 0) {
        container.style.width = '100%';
        container.style.height = '100%';
      }
      
      // 创建 book 实例
      const book = ePub(fileUrl, { openAs: 'epub' });
      bookRef.current = book;
      
      // 等待加载完成
      await book.ready;
      await book.loaded.navigation;
      
      // 获取目录
      const tocItems = parseTOC(book.navigation, book.spine);
      onTOCLoaded?.(tocItems);
      
      // 创建 rendition - 使用最简化的配置
      const rendition = book.renderTo(container, {
        width: container.offsetWidth || window.innerWidth,
        height: container.offsetHeight || window.innerHeight,
        flow: 'paginated',
        spread: 'none',
        allowScriptedContent: false, // 禁用脚本内容，更安全
      });
      
      renditionRef.current = rendition;
      
      // 完全禁用 themes API，防止内部调用 replaceCss
      const disableThemesAPI = () => {
        if (!rendition.themes) return;
        
        try {
          // 方法1: 替换 themes.default 为空函数
          if (typeof rendition.themes.default === 'function') {
            const safeThemesDefault = function(this: any, theme: any) {
              return this;
            };
            rendition.themes.default = safeThemesDefault.bind(rendition.themes);
          }
          
          // 方法2: 禁用内部 _themes 对象
          if ((rendition.themes as any)._themes) {
            const _themes = (rendition.themes as any)._themes;
            if (_themes && typeof _themes.default === 'function') {
              _themes.default = function(this: any, theme: any) {
                return this;
              };
            }
            if (_themes && typeof _themes.replaceCss === 'function') {
              _themes.replaceCss = function() {};
            }
          }
          
          // 方法3: 禁用 replaceCss 方法
          if ((rendition.themes as any).replaceCss) {
            (rendition.themes as any).replaceCss = function() {};
          }
          
          // 方法4: 遍历 themes 对象的所有属性
          for (const key in rendition.themes) {
            if (key.includes('replace') || key.includes('Css') || key.includes('css')) {
              try {
                const value = (rendition.themes as any)[key];
                if (typeof value === 'function') {
                  (rendition.themes as any)[key] = function() {
                    return this || rendition.themes;
                  };
                }
              } catch (e) {
                // 忽略错误
              }
            }
          }
        } catch (e) {
          // 忽略错误
        }
      };
      
      // 立即禁用 themes API
      disableThemesAPI();
      
      // 使用全局错误处理捕获 replaceCss 错误
      const errorHandler = (event: ErrorEvent) => {
        if (event.message && event.message.includes('replaceCss')) {
          console.warn('捕获到 replaceCss 错误，已忽略:', event.message);
          disableThemesAPI(); // 重新禁用
          event.preventDefault(); // 阻止错误传播
          return true;
        }
        return false;
      };
      
      window.addEventListener('error', errorHandler, true);
      
      // 保存错误处理器以便清理
      (rendition as any).__errorHandler = errorHandler;
      
      // 设置事件监听
      setupEventListeners(rendition, onProgress);
      
      // 在 display 之前再次确保 themes API 已禁用
      disableThemesAPI();
      
      // 恢复阅读位置
      let displayPromise: Promise<any>;
      
      try {
        if (initialPosition?.currentLocation?.startsWith('epubcfi(')) {
          try {
            displayPromise = rendition.display(initialPosition.currentLocation);
          } catch (error) {
            const item = book.spine.get(initialPosition.chapterIndex || 0);
            displayPromise = item ? rendition.display(item.href) : rendition.display(book.spine.get(0).href);
          }
        } else if (initialPosition?.chapterIndex !== undefined) {
          const item = book.spine.get(initialPosition.chapterIndex);
          displayPromise = item ? rendition.display(item.href) : rendition.display(book.spine.get(0).href);
        } else {
          displayPromise = rendition.display(book.spine.get(0).href);
        }
        
        // 等待 display 完成
        await displayPromise;
      } catch (displayError: any) {
        // 如果 display 失败且是因为 replaceCss 错误，尝试重新禁用并重试
        if (displayError?.message?.includes('replaceCss') || displayError?.message?.includes('undefined')) {
          console.warn('检测到 replaceCss 错误，重新禁用 themes API 并重试');
          disableThemesAPI();
          try {
            await rendition.display(book.spine.get(0).href);
          } catch (retryError) {
            throw displayError;
          }
        } else {
          throw displayError;
        }
      }
      
      // 等待内容渲染完成后再应用样式
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // 应用初始样式（使用 DOM 方法，完全避免 themes API）
      if (settings) {
        applyThemeToDOM(rendition, settings);
      }
      
      isInitializedRef.current = true;
      onReady?.({ book, rendition });
      
    } catch (error: any) {
      console.error('EpubjsRenderer: 初始化失败', error);
      toast.error(`加载失败: ${error.message || '未知错误'}`);
    }
  }, [containerRef, fileUrl, initialPosition, settings, onReady, onProgress, onTOCLoaded, setupEventListeners]);
  
  // 初始化
  useEffect(() => {
    initEpubjs();
    
    return () => {
      if (renditionRef.current) {
        const cleanupFn = (renditionRef.current as any).__cleanup;
        if (cleanupFn) cleanupFn();
        
        if (typeof renditionRef.current.destroy === 'function') {
          renditionRef.current.destroy();
        }
      }
      
      if (bookRef.current && typeof bookRef.current.destroy === 'function') {
        bookRef.current.destroy();
      }
    };
  }, [initEpubjs]);
  
  // 监听设置变化 - 使用 DOM 方法
  useEffect(() => {
    if (renditionRef.current && isInitializedRef.current) {
      applyThemeToDOM(renditionRef.current, settings);
    }
  }, [settings]);
  
  // 这个组件不渲染任何内容，epubjs会直接渲染到container中
  return null;
};
