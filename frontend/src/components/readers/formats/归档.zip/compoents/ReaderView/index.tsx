import React from 'react';
import { ReadingSettings, TOCItem } from '../../../types/reader';
import LoadingView from './LoadingView';
import ErrorView from './ErrorView';
import { EpubjsRenderer } from './EpubjsRenderer';

interface ReaderViewProps {
  loading: boolean;
  error: string | null;
  containerRef: React.RefObject<HTMLDivElement>;
  settings: ReadingSettings;
  toc: TOCItem[];
  fileUrl?: string;
  initialPosition?: any;
  onChapterSelect?: (href: string) => void;
  onReady?: (rendition: any) => void;
}

const ReaderView: React.FC<ReaderViewProps> = ({
  loading,
  error,
  containerRef,
  settings,
  toc,
  fileUrl,
  initialPosition,
  onChapterSelect,
  onReady,
}) => {
  if (error) {
    return <ErrorView error={error} theme={settings.theme} />;
  }
  
  if (loading) {
    return <LoadingView theme={settings.theme} />;
  }
  
  return (
    <>
      {fileUrl && (
        <EpubjsRenderer
          containerRef={containerRef}
          fileUrl={fileUrl}
          initialPosition={initialPosition}
          settings={settings}
          onReady={onReady}
        />
      )}
    </>
  );
};

export default ReaderView;