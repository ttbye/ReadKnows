import React, { ReactNode } from 'react';
import { ReadingSettings } from '../../../types/reader';
import { getThemeConfig, getReaderLayoutStyles } from './ReaderUtils/themeUtils';
import { useDeviceInfo } from './ReaderUtils/deviceUtils';

interface ReaderContainerProps {
  children: ReactNode;
  settings: ReadingSettings;
  containerRef: React.RefObject<HTMLDivElement>;
  onMouseDown?: (e: React.MouseEvent) => void;
  onMouseMove?: (e: React.MouseEvent) => void;
  onMouseUp?: () => void;
  onMouseLeave?: () => void;
  onTouchStart?: (e: React.TouchEvent) => void;
  onTouchMove?: (e: React.TouchEvent) => void;
  onTouchEnd?: (e: React.TouchEvent) => void;
  className?: string;
}

const ReaderContainer: React.FC<ReaderContainerProps> = ({
  children,
  settings,
  containerRef,
  onMouseDown,
  onMouseMove,
  onMouseUp,
  onMouseLeave,
  onTouchStart,
  onTouchMove,
  onTouchEnd,
  className = '',
}) => {
  const deviceInfo = useDeviceInfo();
  const themeConfig = getThemeConfig(settings.theme);
  const layoutStyles = getReaderLayoutStyles(settings, deviceInfo.isDesktop);
  
  return (
    <div
      className={`reader-container ${className}`}
      style={{
        backgroundColor: themeConfig.bg,
        color: themeConfig.text,
        touchAction: 'manipulation',
        WebkitTouchCallout: 'none',
        userSelect: 'text',
        paddingLeft: 'env(safe-area-inset-left, 0px)',
        paddingRight: 'env(safe-area-inset-right, 0px)',
        boxSizing: 'border-box',
        display: 'flex',
        alignItems: 'stretch',
        justifyContent: 'center',
        height: '100%',
        width: '100%',
        overflow: 'hidden',
        position: 'relative',
      }}
    >
      {/* 阅读区域背景 */}
      <div
        className="reader-background"
        style={{
          ...layoutStyles,
          transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
          backdropFilter: 'blur(12px) saturate(1.08)',
          WebkitBackdropFilter: 'blur(12px) saturate(1.08)',
          boxSizing: 'border-box',
          overflow: 'hidden',
          position: 'relative',
          width: '100%',
          height: '100%',
        }}
      >
        {/* 内容区域 */}
        <div
          ref={containerRef}
          className="reader-content"
          style={{
            height: '100%',
            width: '100%',
            overflow: 'hidden',
            position: 'relative',
            borderRadius: layoutStyles.borderRadius,
          }}
        >
          {children}
        </div>
        
        {/* 触摸事件捕获层 */}
        <div
          className="touch-overlay"
          onMouseDown={onMouseDown}
          onMouseMove={onMouseMove}
          onMouseUp={onMouseUp}
          onMouseLeave={onMouseLeave}
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 10,
            pointerEvents: 'auto',
            touchAction: 'manipulation',
            cursor: 'pointer',
            backgroundColor: 'transparent',
          }}
          aria-label="点击或滑动翻页"
        />
      </div>
    </div>
  );
};

export default ReaderContainer;