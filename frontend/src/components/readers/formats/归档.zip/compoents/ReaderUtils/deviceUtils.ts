import { useState, useEffect } from 'react';
import { DeviceInfo } from '../../../types/reader';

export const getDeviceInfo = (): DeviceInfo => {
  const userAgent = navigator.userAgent.toLowerCase();
  const width = window.innerWidth;
  const height = window.innerHeight;
  
  // 检测移动设备
  const mobileKeywords = ['android', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone'];
  const isMobile = mobileKeywords.some(keyword => userAgent.includes(keyword));
  
  // 检测平板
  const isTablet = /ipad|tablet|(android(?!.*mobile))/.test(userAgent) || 
    (width >= 768 && width <= 1024 && height >= 768 && height <= 1024);
  
  // 检测PWA模式
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
  const isFullscreen = (window.navigator as any).standalone === true;
  const isPWA = isStandalone || isFullscreen;
  
  // 检测桌面端
  const isDesktop = width >= 1024 && !isMobile && !isTablet;
  
  return {
    isMobile: isMobile || width <= 768,
    isPWA,
    isDesktop,
    isTablet,
  };
};

export const useDeviceInfo = () => {
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo>(getDeviceInfo());
  
  useEffect(() => {
    const checkDevice = () => {
      setDeviceInfo(getDeviceInfo());
    };
    
    checkDevice();
    window.addEventListener('resize', checkDevice);
    
    // 监听display-mode变化
    const mediaQuery = window.matchMedia('(display-mode: standalone)');
    mediaQuery.addEventListener('change', checkDevice);
    
    return () => {
      window.removeEventListener('resize', checkDevice);
      mediaQuery.removeEventListener('change', checkDevice);
    };
  }, []);
  
  return deviceInfo;
};