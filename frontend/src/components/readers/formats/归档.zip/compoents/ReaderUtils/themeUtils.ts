import { ReadingSettings, ThemeConfig, LayoutStyles } from '../../../types/reader';

export const getThemeConfig = (theme: ReadingSettings['theme']): ThemeConfig => {
  const configs = {
    light: {
      bg: '#ffffff',
      text: '#000000',
      border: '#e0e0e0',
      gradient: 'linear-gradient(145deg, rgba(255, 255, 255, 0.938) 0%, rgba(248, 250, 252, 0.5) 50%, rgba(241, 245, 249, 0.7) 100%)',
      shadow: '0 20px 60px rgba(0, 0, 0, 0.08), 0 8px 24px rgba(0, 0, 0, 0.05), 0 2px 8px rgba(0, 0, 0, 0.03)',
    },
    dark: {
      bg: '#1a1a1a',
      text: '#ffffff',
      border: '#404040',
      gradient: 'linear-gradient(145deg, rgba(28, 30, 34, 0.3) 0%, rgba(23, 25, 28, 0.5) 50%, rgba(18, 20, 23, 0.7) 100%)',
      shadow: '0 20px 60px rgba(0, 0, 0, 0.35), 0 8px 24px rgba(0, 0, 0, 0.25), 0 2px 8px rgba(0, 0, 0, 0.15)',
    },
    sepia: {
      bg: '#f4e4bc',
      text: '#5c4b37',
      border: '#d4c49c',
      gradient: 'linear-gradient(145deg, rgba(250, 247, 240, 0.3) 0%, rgba(245, 238, 225, 0.5) 50%, rgba(240, 232, 215, 0.7) 100%)',
      shadow: '0 20px 60px rgba(92, 75, 55, 0.12), 0 8px 24px rgba(92, 75, 55, 0.08), 0 2px 8px rgba(92, 75, 55, 0.05)',
    },
    green: {
      bg: '#c8e6c9',
      text: '#2e7d32',
      border: '#a5d6a7',
      gradient: 'linear-gradient(145deg, rgba(245, 252, 245, 0.3) 0%, rgba(237, 247, 237, 0.5) 50%, rgba(232, 245, 233, 0.7) 100%)',
      shadow: '0 20px 60px rgba(46, 125, 50, 0.08), 0 8px 24px rgba(46, 125, 50, 0.05), 0 2px 8px rgba(46, 125, 50, 0.03)',
    },
  };
  
  return configs[theme];
};

export const getFontFamily = (fontFamily: ReadingSettings['fontFamily']): string => {
  switch (fontFamily) {
    case 'serif':
      return '"Songti SC", "SimSun", "宋体", "STSong", serif';
    case 'sans-serif':
      return '-apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", "WenQuanYi Micro Hei", sans-serif';
    case 'monospace':
      return '"SF Mono", Monaco, "Cascadia Code", "Roboto Mono", Consolas, "Courier New", monospace';
    default:
      return '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
  }
};

export const getReaderLayoutStyles = (settings: ReadingSettings, isDesktop: boolean): LayoutStyles => {
  const isCentered = isDesktop && settings.readerWidth === 'centered';
  const themeConfig = getThemeConfig(settings.theme);
  
  const layout: LayoutStyles = {
    readerWidth: isCentered ? '980px' : '100%',
    maxWidth: isCentered ? '980px' : '100%',
    margin: isCentered ? '0 auto' : '0',
    borderRadius: isCentered ? '16px' : '0',
    padding: isCentered ? '24px' : '16px',
    background: themeConfig.gradient,
    boxShadow: isCentered ? themeConfig.shadow + ', inset 0 1px 0 rgba(255, 255, 255, 0.1)' : 'none',
    border: isCentered ? `1px solid ${themeConfig.border}` : 'none',
  };
  
  return layout;
};

/**
 * 创建简化的 EPUB 主题对象（避免触发 replaceCss 错误）
 * 只使用最基本的 CSS 属性，不使用复杂的 !important 规则
 */
export const createEpubTheme = (settings: ReadingSettings): any => {
  const themeConfig = getThemeConfig(settings.theme);
  const fontFamily = getFontFamily(settings.fontFamily);
  
  // 简化主题对象，避免复杂的 CSS 规则
  return {
    body: {
      'font-size': `${settings.fontSize}px`,
      'line-height': `${settings.lineHeight}`,
      'font-family': fontFamily,
      'padding': `${settings.margin}px`,
      'text-indent': `${settings.textIndent}em`,
      'background-color': themeConfig.bg,
      'color': themeConfig.text,
      'margin': '0',
    },
  };
};

/**
 * 直接通过 DOM 应用样式（避免使用 themes.default API）
 * 这是最安全的方法，不会触发 epubjs 内部错误
 */
export const applyThemeToDOM = (
  rendition: any,
  settings: ReadingSettings
): void => {
  if (!rendition) return;
  
  try {
    const views = rendition.views();
    if (!views || views.length === 0) return;
    
    const themeConfig = getThemeConfig(settings.theme);
    const fontFamily = getFontFamily(settings.fontFamily);
    
    views.forEach((view: any) => {
      if (!view?.document?.body) return;
      
      const doc = view.document;
      const body = doc.body;
      
      // 应用基础样式
      body.style.fontSize = `${settings.fontSize}px`;
      body.style.lineHeight = `${settings.lineHeight}`;
      body.style.fontFamily = fontFamily;
      body.style.padding = `${settings.margin}px`;
      body.style.backgroundColor = themeConfig.bg;
      body.style.color = themeConfig.text;
      body.style.margin = '0';
      
      // 应用文本缩进到段落
      const paragraphs = doc.querySelectorAll('p');
      paragraphs.forEach((p: HTMLElement) => {
        p.style.textIndent = `${settings.textIndent}em`;
        p.style.color = themeConfig.text;
      });
      
      // 应用颜色到文本元素
      const textElements = doc.querySelectorAll('div, span, h1, h2, h3, h4, h5, h6, li, td, th, a, em, strong, b, i, u, blockquote, pre, code');
      textElements.forEach((el: HTMLElement) => {
        if (el.style) {
          el.style.color = themeConfig.text;
        }
      });
    });
  } catch (error) {
    console.error('应用 DOM 样式失败:', error);
  }
};
