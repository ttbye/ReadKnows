import { BookData, TOCItem, ReadingPosition } from '../../../types/reader';
import { offlineStorage } from '../../../../../utils/offlineStorage';

/**
 * 获取 EPUB 文件的 URL
 * 优先使用离线缓存，如果缓存不存在则下载并缓存
 */
export const getFileUrl = async (book: BookData): Promise<string> => {
  if (!book.id) {
    throw new Error('书籍ID不存在');
  }

  const ext = book.file_name?.split('.').pop()?.toLowerCase() || 'epub';
  const serverUrl = `/books/${book.id}.${ext}`;

  try {
    // 尝试从缓存获取
    const cachedBlob = await offlineStorage.getBook(book.id);
    if (cachedBlob) {
      // 检查缓存的文件大小
      if (cachedBlob.size === 0) {
        throw new Error('缓存的EPUB文件为空，请重新下载');
      }
      return offlineStorage.createBlobURL(cachedBlob);
    }

    // 下载并缓存
    const blob = await offlineStorage.downloadBook(book.id, ext, serverUrl);
    // 检查下载的文件大小
    if (blob.size === 0) {
      throw new Error('下载的EPUB文件为空，请检查服务器上的文件');
    }
    return offlineStorage.createBlobURL(blob);
  } catch (error) {
    console.error('离线存储失败，使用服务器URL', error);
    // 如果离线存储失败，返回服务器URL
    return serverUrl;
  }
};

/**
 * 解析 EPUB 目录
 */
export const parseTOC = (navigation: any, spine: any): TOCItem[] => {
  const tocItems: TOCItem[] = [];
  
  if (!navigation || !spine) {
    return tocItems;
  }

  // 创建 href 到 spine index 的映射
  const hrefToIndex = new Map<string, number>();
  spine.each((item: any, index: number) => {
    if (item && item.href) {
      hrefToIndex.set(item.href, index);
    }
  });

  // 递归解析目录项
  const parseNavItem = (item: any, level: number = 1, parentIndex: number = 0): TOCItem[] => {
    const items: TOCItem[] = [];
    
    if (!item) return items;

    // 处理单个目录项
    if (item.href) {
      const href = item.href;
      const chapterIndex = hrefToIndex.get(href) ?? 0;
      
      items.push({
        id: href || `toc-${items.length}`,
        title: item.label || item.title || '未命名章节',
        href: href,
        level: level,
        chapterIndex: chapterIndex,
      });
    }

    // 处理子项
    if (item.children && Array.isArray(item.children)) {
      item.children.forEach((child: any) => {
        items.push(...parseNavItem(child, level + 1, items.length));
      });
    }

    return items;
  };

  // 处理 navigation.toc（标准目录）
  if (navigation.toc && Array.isArray(navigation.toc)) {
    navigation.toc.forEach((item: any) => {
      tocItems.push(...parseNavItem(item, 1));
    });
  }

  // 如果没有找到目录，尝试使用 spine 创建简单的目录
  if (tocItems.length === 0 && spine) {
    spine.each((item: any, index: number) => {
      if (item && item.href) {
        tocItems.push({
          id: item.href,
          title: item.label || `章节 ${index + 1}`,
          href: item.href,
          level: 1,
          chapterIndex: index,
        });
      }
    });
  }

  return tocItems;
};

/**
 * 获取总章节数
 */
export const getTotalChapters = (book: any): number => {
  if (!book || !book.spine) {
    return 1;
  }

  let count = 0;
  book.spine.each(() => {
    count++;
  });

  return Math.max(1, count);
};

/**
 * 计算阅读进度
 */
export const calculateProgress = (
  location: any,
  totalChapters: number
): { progress: number; position: ReadingPosition } => {
  const spineIndex = location.start?.index ?? 0;
  const cfi = location.start?.cfi;
  const chapterCurrentPage = location.start?.displayed?.page || 1;
  const chapterTotalPages = location.start?.displayed?.total || 1;

  // 计算章节内进度
  const withinChapter = chapterTotalPages > 1 && chapterCurrentPage >= 1
    ? Math.min(1, Math.max(0, (chapterCurrentPage - 1) / chapterTotalPages))
    : 0;

  // 计算全书进度
  const progress = Math.min(1, Math.max(0, (spineIndex + withinChapter) / totalChapters));

  const position: ReadingPosition = {
    chapterIndex: spineIndex,
    currentPage: chapterCurrentPage,
    totalPages: chapterTotalPages,
    progress: progress,
    currentLocation: cfi,
  };

  return { progress, position };
};
