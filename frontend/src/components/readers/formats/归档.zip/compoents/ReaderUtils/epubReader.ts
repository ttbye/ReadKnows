import ePub from 'epubjs';
import { EpubInitOptions, TOCItem } from '../../../types/reader';
import { parseTOC, getTotalChapters } from './epubUtils';
import { applyThemeToDOM } from './themeUtils';

export const initEpubjsInstance = async (options: EpubInitOptions): Promise<{ book: any; rendition: any }> => {
  const {
    fileUrl,
    container,
    initialPosition,
    settings,
    onTOCLoaded,
    onProgress,
  } = options;
  
  if (!container) {
    throw new Error('容器元素未提供');
  }
  
  // 创建 book 实例
  const book = ePub(fileUrl, { openAs: 'epub' });
  
  // 等待加载完成
  await book.ready;
  await book.loaded.navigation;
  
  // 获取目录
  const tocItems = parseTOC(book.navigation, book.spine);
  onTOCLoaded?.(tocItems);
  
  // 创建 rendition 配置
  const renditionConfig = {
    width: container.offsetWidth || window.innerWidth,
    height: container.offsetHeight || window.innerHeight,
    flow: 'paginated' as const,
    spread: 'none' as const,
    allowScriptedContent: true,
  };
  
  // 创建 rendition
  const rendition = book.renderTo(container, renditionConfig);
  
  // 完全禁用 themes API，防止内部调用 replaceCss
  // 将 themes.default 替换为一个安全的空函数
  if (rendition.themes && typeof rendition.themes.default === 'function') {
    const safeThemesDefault = function(theme: any) {
      // 完全禁用，不执行任何操作，防止 replaceCss 错误
      return this;
    };
    rendition.themes.default = safeThemesDefault.bind(rendition.themes);
  }
  
  // 设置事件监听
  if (onProgress) {
    rendition.on('relocated', (location: any) => {
      const spineIndex = location.start?.index ?? 0;
      const cfi = location.start?.cfi;
      const chapterCurrentPage = location.start?.displayed?.page || 1;
      const chapterTotalPages = location.start?.displayed?.total || 1;
      
      // 计算章节内进度
      const withinChapter = chapterTotalPages > 1 && chapterCurrentPage >= 1
        ? Math.min(1, Math.max(0, (chapterCurrentPage - 1) / chapterTotalPages))
        : 0;
      
      // 计算全书进度
      const totalChapters = getTotalChapters(book);
      const progress = Math.min(1, Math.max(0, (spineIndex + withinChapter) / totalChapters));
      
      const position = {
        chapterIndex: spineIndex,
        currentPage: chapterCurrentPage,
        totalPages: chapterTotalPages,
        progress,
        currentLocation: cfi,
      };
      
      onProgress(progress, position);
    });
  }
  
  // 恢复阅读位置
  let displayPromise: Promise<any>;
  
  if (initialPosition?.currentLocation?.startsWith('epubcfi(')) {
    try {
      displayPromise = rendition.display(initialPosition.currentLocation);
    } catch (error) {
      const item = book.spine.get(initialPosition.chapterIndex || 0);
      displayPromise = item ? rendition.display(item.href) : rendition.display(book.spine.get(0).href);
    }
  } else if (initialPosition?.chapterIndex !== undefined) {
    const item = book.spine.get(initialPosition.chapterIndex);
    displayPromise = item ? rendition.display(item.href) : rendition.display(book.spine.get(0).href);
  } else {
    displayPromise = rendition.display(book.spine.get(0).href);
  }
  
  await displayPromise;
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // 在 display 之后应用样式（使用 DOM 方法，避免 themes API）
  if (settings) {
    applyThemeToDOM(rendition, settings);
  }
  
  return { book, rendition };
};

export const destroyEpubjsInstance = (instance: { book?: any; rendition?: any }) => {
  if (instance.rendition) {
    try {
      if (typeof instance.rendition.destroy === 'function') {
        instance.rendition.destroy();
      }
    } catch (error) {
      console.error('销毁rendition失败:', error);
    }
  }
  
  if (instance.book) {
    try {
      if (typeof instance.book.destroy === 'function') {
        instance.book.destroy();
      }
    } catch (error) {
      console.error('销毁book失败:', error);
    }
  }
};