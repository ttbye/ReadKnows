import { ReadingPosition } from '../../../types/reader';

export class ProgressManager {
  private totalLocations: number = 0;
  private locationsReady: boolean = false;
  private lastCfi: string | null = null;
  private isRestoringLayout: boolean = false;
  private lastProgress: number = 0;
  private lastPosition: ReadingPosition | null = null;
  private locationsFailed: boolean = false;
  
  constructor() {}
  
  setLocationsReady(total: number): void {
    this.totalLocations = total;
    this.locationsReady = total > 0;
  }
  
  setLocationsFailed(): void {
    this.locationsReady = false;
    this.locationsFailed = true;
  }
  
  updateLastCfi(cfi: string | null): void {
    this.lastCfi = cfi;
  }
  
  setRestoringLayout(restoring: boolean): void {
    this.isRestoringLayout = restoring;
  }
  
  isLayoutRestoring(): boolean {
    return this.isRestoringLayout;
  }
  
  saveProgress(progress: number, position: ReadingPosition): void {
    this.lastProgress = progress;
    this.lastPosition = position;
  }
  
  getLastProgress(): { progress: number; position: ReadingPosition | null } {
    return {
      progress: this.lastProgress,
      position: this.lastPosition,
    };
  }
  
  calculateWithLocations(book: any, cfi: string): { currentPage: number; totalPages: number; progress: number } | null {
    if (!this.locationsReady || !book?.locations) return null;
    
    try {
      const loc = book.locations.locationFromCfi(cfi);
      const total = book.locations.length();
      
      if (typeof loc === 'number' && loc >= 0 && typeof total === 'number' && total > 0) {
        const currentPage = loc + 1;
        const progress = Math.min(1, Math.max(0, (loc + 1) / total));
        return { currentPage, totalPages: total, progress };
      }
    } catch (e) {
      // 忽略错误
    }
    
    return null;
  }
}