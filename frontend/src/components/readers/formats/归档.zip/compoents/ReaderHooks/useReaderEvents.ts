import { useCallback, useEffect } from 'react';
import { ReadingSettings } from '../../../../../../types/reader';
import { applyThemeToDOM } from '../ReaderUtils/themeUtils';

interface UseReaderEventsProps {
  settings: ReadingSettings;
  rendition: any;
  book: any;
}

export function useReaderEvents({
  settings,
  rendition,
  book,
}: UseReaderEventsProps) {
  // 应用设置到阅读器 - 使用 DOM 方法避免 themes API
  const applySettingsToReader = useCallback(() => {
    if (!rendition) return;
    
    // 直接使用 DOM 方法，完全避免 themes.default() API
    applyThemeToDOM(rendition, settings);
  }, [rendition, settings]);

  // 跳转到指定章节
  const goToChapter = useCallback((chapterIndex: number) => {
    if (!book || !rendition) return;

    try {
      const spine = book.spine;
      if (chapterIndex >= 0 && chapterIndex < spine.length) {
        const item = spine.get(chapterIndex);
        if (item) {
          rendition.display(item.href);
        }
      }
    } catch (error) {
      console.error('goToChapter: 跳转章节失败', error);
    }
  }, [book, rendition]);

  // 高亮文本
  const highlightText = useCallback((cfiRange: string, color?: string) => {
    if (!rendition) return;

    try {
      rendition.annotations.add('highlight', cfiRange, {}, () => {}, 'hl', {
        fill: color || 'yellow',
        'fill-opacity': '0.3',
        'stroke-opacity': '0',
      });
    } catch (error) {
      console.error('highlightText: 高亮失败', error);
    }
  }, [rendition]);

  // 处理窗口大小变化
  const handleResize = useCallback(() => {
    if (!rendition) return;

    try {
      rendition.resize(window.innerWidth, window.innerHeight);
    } catch (error) {
      console.error('handleResize: 调整大小失败', error);
    }
  }, [rendition]);

  // 设置键盘快捷键
  const setupKeyboardShortcuts = useCallback((container: HTMLElement) => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // 如果焦点在输入框/文本域，跳过
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      // 标记已处理，避免容器层重复处理
      (e as any).__readerHandled = true;

      if (!rendition) return;

      try {
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
          e.preventDefault();
          rendition.prev();
        } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === ' ') {
          e.preventDefault();
          rendition.next();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          // 可以在这里添加关闭菜单等操作
          if ((window as any).__toggleReaderNavigation) {
            (window as any).__toggleReaderNavigation();
          }
        }
      } catch (error) {
        console.error('键盘快捷键处理失败', error);
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [rendition]);

  // 设置全局函数
  const setupGlobalFunctions = useCallback(() => {
    // 暴露翻页函数给外部（供 ReaderContainer 调用）
    (window as any).__readerPageTurn = (direction: 'prev' | 'next') => {
      if (!rendition) return;
      try {
        if (direction === 'prev') {
          rendition.prev();
        } else {
          rendition.next();
        }
      } catch (error) {
        console.error('翻页失败', error);
      }
    };

    // 暴露章节跳转函数给外部
    (window as any).__epubGoToChapter = (href: string) => {
      if (!rendition) return;
      try {
        rendition.display(href);
      } catch (error) {
        console.error('跳转章节失败', error);
      }
    };

    return () => {
      delete (window as any).__readerPageTurn;
      delete (window as any).__epubGoToChapter;
    };
  }, [rendition]);

  return {
    applySettingsToReader,
    goToChapter,
    highlightText,
    handleResize,
    setupKeyboardShortcuts,
    setupGlobalFunctions,
  };
}

