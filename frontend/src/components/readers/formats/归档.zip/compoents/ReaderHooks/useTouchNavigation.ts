import { useCallback, useRef } from 'react';
import { ReadingSettings, TouchState, MoveState, PageTurnState } from '../../../types/reader';

interface UseTouchNavigationProps {
  settings: ReadingSettings;
  loading: boolean;
  rendition: any;
  onShowBars?: () => void;
}

export const useTouchNavigation = ({
  settings,
  loading,
  rendition,
  onShowBars,
}: UseTouchNavigationProps) => {
  const touchStartRef = useRef<TouchState | null>(null);
  const moveStateRef = useRef<MoveState>({ maxMoveX: 0, maxMoveY: 0, lastX: 0, lastY: 0 });
  const pageTurnStateRef = useRef<PageTurnState>({ lastPageTurnTime: 0, isTurningPage: false });
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const mouseDownRef = useRef<{ x: number; y: number; time: number } | null>(null);
  
  const LONG_PRESS_THRESHOLD = 500;
  const PAGE_TURN_DEBOUNCE = 300;
  
  // 清理定时器
  const clearLongPressTimer = useCallback(() => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  }, []);
  
  // 翻页函数
  const turnPage = useCallback((direction: 'prev' | 'next') => {
    if (!rendition || pageTurnStateRef.current.isTurningPage) return;
    
    const now = Date.now();
    if (now - pageTurnStateRef.current.lastPageTurnTime < PAGE_TURN_DEBOUNCE) return;
    
    pageTurnStateRef.current.isTurningPage = true;
    pageTurnStateRef.current.lastPageTurnTime = now;
    
    try {
      if (direction === 'prev') {
        rendition.prev();
      } else {
        rendition.next();
      }
    } catch (error) {
      console.error('翻页失败:', error);
    } finally {
      setTimeout(() => {
        pageTurnStateRef.current.isTurningPage = false;
      }, PAGE_TURN_DEBOUNCE);
    }
  }, [rendition]);
  
  // 判断滑动方向
  const getSwipeDirection = useCallback((): 'prev' | 'next' | null => {
    if (!touchStartRef.current) return null;
    
    const moveX = moveStateRef.current.maxMoveX;
    const moveY = moveStateRef.current.maxMoveY;
    const deltaX = moveStateRef.current.lastX - touchStartRef.current.clientX;
    const deltaY = moveStateRef.current.lastY - touchStartRef.current.clientY;
    
    const PRIMARY_THRESHOLD = 70;
    const DIRECTION_RATIO = 1.3;
    const DIRECTION_MIN = 40;
    
    if (settings.pageTurnMode === 'horizontal') {
      if (moveX > PRIMARY_THRESHOLD && moveX > moveY * DIRECTION_RATIO) {
        if (deltaX > DIRECTION_MIN) return 'next';
        if (deltaX < -DIRECTION_MIN) return 'prev';
      }
    } else {
      if (moveY > PRIMARY_THRESHOLD && moveY > moveX * DIRECTION_RATIO) {
        if (deltaY < -DIRECTION_MIN) return 'next';
        if (deltaY > DIRECTION_MIN) return 'prev';
      }
    }
    
    return null;
  }, [settings.pageTurnMode]);
  
  // 检查是否为有效点击
  const isValidClick = useCallback((): boolean => {
    if (!touchStartRef.current) return false;
    
    const touchDuration = Date.now() - touchStartRef.current.startTime;
    const distance = Math.sqrt(
      Math.pow(moveStateRef.current.lastX - touchStartRef.current.clientX, 2) +
      Math.pow(moveStateRef.current.lastY - touchStartRef.current.clientY, 2)
    );
    
    // 防误触条件
    if (touchDuration < 80) return false; // 点击太快
    if (touchDuration > 800) return false; // 长按
    if (distance > 15) return false; // 移动距离过大
    
    return true;
  }, []);
  
  // 处理触摸开始
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (loading || !e.touches[0]) return;
    
    const touch = e.touches[0];
    touchStartRef.current = {
      startX: touch.clientX,
      startY: touch.clientY,
      startTime: Date.now(),
      clientX: touch.clientX,
      clientY: touch.clientY,
    };
    
    moveStateRef.current = { maxMoveX: 0, maxMoveY: 0, lastX: touch.clientX, lastY: touch.clientY };
    
    // 长按显示导航栏
    if (onShowBars) {
      longPressTimerRef.current = setTimeout(() => {
        onShowBars();
        if (navigator.vibrate) navigator.vibrate(50);
      }, LONG_PRESS_THRESHOLD);
    }
  }, [loading, onShowBars]);
  
  // 处理触摸移动
  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!touchStartRef.current || !e.touches[0]) return;
    
    const touch = e.touches[0];
    const moveX = Math.abs(touch.clientX - touchStartRef.current.clientX);
    const moveY = Math.abs(touch.clientY - touchStartRef.current.clientY);
    
    moveStateRef.current.maxMoveX = Math.max(moveStateRef.current.maxMoveX, moveX);
    moveStateRef.current.maxMoveY = Math.max(moveStateRef.current.maxMoveY, moveY);
    moveStateRef.current.lastX = touch.clientX;
    moveStateRef.current.lastY = touch.clientY;
    
    // 取消长按定时器
    if ((moveX > 10 || moveY > 10) && longPressTimerRef.current) {
      clearLongPressTimer();
    }
    
    // 阻止默认滚动行为
    if (settings.pageTurnMethod === 'swipe') {
      if (settings.pageTurnMode === 'horizontal') {
        if (moveX > 10 && moveX > moveY * 1.2) e.preventDefault();
      } else {
        if (moveY > 10 && moveY > moveX * 1.2) e.preventDefault();
      }
    }
  }, [settings.pageTurnMethod, settings.pageTurnMode, clearLongPressTimer]);
  
  // 处理触摸结束
  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    clearLongPressTimer();
    
    if (!touchStartRef.current || loading || !rendition) {
      touchStartRef.current = null;
      return;
    }
    
    if (settings.pageTurnMethod === 'swipe') {
      const direction = getSwipeDirection();
      if (direction) {
        turnPage(direction);
      }
    } else if (settings.pageTurnMethod === 'click' && settings.clickToTurn) {
      if (isValidClick()) {
        const touch = e.changedTouches[0];
        const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const x = touch.clientX - rect.left;
        const y = touch.clientY - rect.top;
        
        if (settings.pageTurnMode === 'horizontal') {
          if (x < rect.width / 2) turnPage('prev');
          else turnPage('next');
        } else {
          if (y < rect.height / 2) turnPage('prev');
          else turnPage('next');
        }
      }
    }
    
    touchStartRef.current = null;
  }, [loading, rendition, settings, getSwipeDirection, turnPage, isValidClick, clearLongPressTimer]);
  
  // 鼠标事件处理
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (loading) return;
    
    mouseDownRef.current = {
      x: e.clientX,
      y: e.clientY,
      time: Date.now(),
    };
    
    // PC端长按
    if (onShowBars) {
      longPressTimerRef.current = setTimeout(() => {
        onShowBars();
      }, LONG_PRESS_THRESHOLD);
    }
  }, [loading, onShowBars]);
  
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (mouseDownRef.current && longPressTimerRef.current) {
      const deltaX = Math.abs(e.clientX - mouseDownRef.current.x);
      const deltaY = Math.abs(e.clientY - mouseDownRef.current.y);
      
      if (deltaX > 10 || deltaY > 10) {
        clearLongPressTimer();
      }
    }
  }, [clearLongPressTimer]);
  
  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    clearLongPressTimer();
    
    if (loading || !rendition || !settings.clickToTurn) {
      mouseDownRef.current = null;
      return;
    }
    
    if (settings.pageTurnMethod === 'click') {
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      if (settings.pageTurnMode === 'horizontal') {
        if (x < rect.width / 2) turnPage('prev');
        else turnPage('next');
      } else {
        if (y < rect.height / 2) turnPage('prev');
        else turnPage('next');
      }
    }
    
    mouseDownRef.current = null;
  }, [loading, rendition, settings, turnPage, clearLongPressTimer]);
  
  const handleMouseLeave = useCallback(() => {
    clearLongPressTimer();
    mouseDownRef.current = null;
  }, [clearLongPressTimer]);
  
  return {
    handleTouchStart,
    handleTouchMove,
    handleTouchEnd,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleMouseLeave,
    clearLongPressTimer,
  };
};