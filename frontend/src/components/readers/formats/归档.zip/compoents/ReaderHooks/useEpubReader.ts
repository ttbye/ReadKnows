import { useState, useCallback, useRef, useEffect } from 'react';
import { BookData, ReadingPosition, TOCItem, EpubInstance } from '../../types/reader';
import { getFileUrl, parseTOC, getTotalChapters, calculateProgress } from '../ReaderUtils/epubUtils';
import { applyThemeToDOM, getThemeConfig, getFontFamily } from '../ReaderUtils/themeUtils';
import { ProgressManager } from '../ReaderUtils/progressUtils';
import toast from 'react-hot-toast';

interface UseEpubReaderProps {
  book: BookData;
  containerRef: React.RefObject<HTMLDivElement>;
  initialPosition?: ReadingPosition;
  settings?: any;
  onTOCChange?: (toc: TOCItem[]) => void;
  onProgressChange?: (progress: number, position: ReadingPosition) => void;
}

export const useEpubReader = ({
  book,
  containerRef,
  initialPosition,
  settings,
  onTOCChange,
  onProgressChange,
}: UseEpubReaderProps) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toc, setToc] = useState<TOCItem[]>([]);
  const [isReady, setIsReady] = useState(false);
  
  const bookRef = useRef<any>(null);
  const renditionRef = useRef<any>(null);
  const totalChaptersRef = useRef<number>(1);
  const isInitializingRef = useRef(false);
  const progressManagerRef = useRef(new ProgressManager());
  
  const initEpubjsReader = useCallback(async () => {
    if (isInitializingRef.current || !containerRef.current) {
      return;
    }
    
    isInitializingRef.current = true;
    setLoading(true);
    setError(null);
    
    try {
      const fileUrl = await getFileUrl(book);
      if (!fileUrl) {
        throw new Error('无法获取书籍文件URL');
      }
      
      const { default: ePub } = await import('epubjs');
      const container = containerRef.current;
      
      // 确保容器有尺寸
      if (container.offsetWidth === 0 || container.offsetHeight === 0) {
        container.style.width = '100%';
        container.style.height = '100%';
      }
      
      // 创建 book 实例
      const bookInstance = ePub(fileUrl, { openAs: 'epub' });
      bookRef.current = bookInstance;
      
      // 等待加载完成
      await bookInstance.ready;
      await bookInstance.loaded.navigation;
      
      // 获取目录
      const navigation = bookInstance.navigation;
      const spine = bookInstance.spine;
      const tocItems = parseTOC(navigation, spine);
      
      setToc(tocItems);
      onTOCChange?.(tocItems);
      
      // 计算总章节数
      totalChaptersRef.current = getTotalChapters(bookInstance);
      
      // 创建 rendition - 使用最简化的配置
      const rendition = bookInstance.renderTo(container, {
        width: container.offsetWidth || window.innerWidth,
        height: container.offsetHeight || window.innerHeight,
        flow: 'paginated',
        spread: 'none',
        allowScriptedContent: false, // 禁用脚本内容，更安全
      });
      
      renditionRef.current = rendition;
      
      // 完全禁用 themes API，防止内部调用 replaceCss
      // 必须在 display() 之前完成，因为 epubjs 可能在 display 时调用 themes
      const disableThemesAPI = () => {
        if (!rendition.themes) return;
        
        try {
          // 方法1: 替换 themes.default 为空函数
          if (typeof rendition.themes.default === 'function') {
            const safeThemesDefault = function(this: any, theme: any) {
              // 完全禁用，不执行任何操作
              return this;
            };
            rendition.themes.default = safeThemesDefault.bind(rendition.themes);
          }
          
          // 方法2: 如果 themes 有 _themes 内部对象，也禁用它
          if ((rendition.themes as any)._themes) {
            const _themes = (rendition.themes as any)._themes;
            if (_themes && typeof _themes.default === 'function') {
              _themes.default = function(this: any, theme: any) {
                return this;
              };
            }
            // 禁用 _themes 的 replaceCss
            if (_themes && typeof _themes.replaceCss === 'function') {
              _themes.replaceCss = function() {};
            }
          }
          
          // 方法3: 如果 themes 有 replaceCss 方法，禁用它
          if ((rendition.themes as any).replaceCss) {
            (rendition.themes as any).replaceCss = function() {
              // 空函数，不执行任何操作
            };
          }
          
          // 方法4: 遍历 themes 对象的所有属性，禁用任何可能调用 replaceCss 的方法
          for (const key in rendition.themes) {
            if (key.includes('replace') || key.includes('Css') || key.includes('css')) {
              try {
                const value = (rendition.themes as any)[key];
                if (typeof value === 'function') {
                  (rendition.themes as any)[key] = function() {
                    return this || rendition.themes;
                  };
                }
              } catch (e) {
                // 忽略错误
              }
            }
          }
        } catch (e) {
          // 忽略错误，继续执行
        }
      };
      
      // 立即禁用 themes API
      disableThemesAPI();
      
      // 使用全局错误处理捕获 replaceCss 错误
      const originalErrorHandler = window.onerror;
      const errorHandler = (message: string | Event, source?: string, lineno?: number, colno?: number, error?: Error) => {
        if (typeof message === 'string' && message.includes('replaceCss')) {
          console.warn('捕获到 replaceCss 错误，已忽略:', message);
          disableThemesAPI(); // 重新禁用
          return true; // 阻止错误传播
        }
        return false;
      };
      
      // 临时设置错误处理
      window.addEventListener('error', errorHandler as any, true);
      
      // 在 cleanup 时移除错误处理
      (rendition as any).__errorHandler = errorHandler;
      
      // 设置 relocated 事件监听
      const handleRelocated = (location: any) => {
        if (progressManagerRef.current.isLayoutRestoring()) {
          return;
        }
        
        const cfi = location.start?.cfi;
        if (cfi) {
          progressManagerRef.current.updateLastCfi(cfi);
        }
        
        const { progress, position } = calculateProgress(location, totalChaptersRef.current);
        
        // 使用 locations 重新计算（如果可用）
        if (cfi && bookInstance?.locations) {
          const locationProgress = progressManagerRef.current.calculateWithLocations(bookInstance, cfi);
          if (locationProgress) {
            position.currentPage = locationProgress.currentPage;
            position.totalPages = locationProgress.totalPages;
            position.progress = locationProgress.progress;
          }
        }
        
        progressManagerRef.current.saveProgress(progress, position);
        onProgressChange?.(progress, position);
      };
      
      rendition.on('relocated', handleRelocated);
      
      // 监听 rendered 事件，在内容渲染后应用样式
      const handleRendered = () => {
        if (settings) {
          // 延迟应用样式，确保 DOM 完全准备好
          setTimeout(() => {
            applyThemeToDOM(rendition, settings);
          }, 100);
        }
      };
      
      rendition.on('rendered', handleRendered);
      
      // 在 display 之前再次确保 themes API 已禁用
      disableThemesAPI();
      
      // 恢复阅读位置或显示第一页
      let displayPromise: Promise<any>;
      
      try {
        if (initialPosition?.currentLocation?.startsWith('epubcfi(')) {
          try {
            displayPromise = rendition.display(initialPosition.currentLocation);
          } catch (error) {
            console.error('CFI 恢复失败，回退到章节索引', error);
            const item = spine.get(initialPosition.chapterIndex || 0);
            displayPromise = item ? rendition.display(item.href) : rendition.display(spine.get(0).href);
          }
        } else if (initialPosition?.chapterIndex !== undefined) {
          const item = spine.get(initialPosition.chapterIndex);
          displayPromise = item ? rendition.display(item.href) : rendition.display(spine.get(0).href);
        } else {
          displayPromise = rendition.display(spine.get(0).href);
        }
        
        // 等待 display 完成
        await displayPromise;
      } catch (displayError: any) {
        // 如果 display 失败且是因为 replaceCss 错误，尝试重新禁用并重试
        if (displayError?.message?.includes('replaceCss') || displayError?.message?.includes('undefined')) {
          console.warn('检测到 replaceCss 错误，重新禁用 themes API 并重试');
          disableThemesAPI();
          // 重试显示第一页
          try {
            await rendition.display(spine.get(0).href);
          } catch (retryError) {
            throw displayError; // 如果重试也失败，抛出原始错误
          }
        } else {
          throw displayError;
        }
      }
      
      // 等待内容渲染完成后再应用样式
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // 应用初始样式（使用 DOM 方法，避免 themes API）
      if (settings) {
        applyThemeToDOM(rendition, settings);
      }
      
      setIsReady(true);
      setLoading(false);
      
      // 保存清理函数
      (rendition as any).__cleanup = () => {
        rendition.off?.('relocated', handleRelocated);
        rendition.off?.('rendered', handleRendered);
        // 移除错误处理
        if ((rendition as any).__errorHandler) {
          window.removeEventListener('error', (rendition as any).__errorHandler, true);
        }
      };
      
    } catch (error: any) {
      console.error('EpubReader: 初始化失败', error);
      setError(`加载失败: ${error.message || '未知错误'}`);
      toast.error(`加载书籍失败: ${error.message || '未知错误'}`);
      setLoading(false);
    } finally {
      isInitializingRef.current = false;
    }
  }, [book, containerRef, initialPosition, settings, onTOCChange, onProgressChange]);
  
  const applySettings = useCallback((newSettings: any) => {
    const rendition = renditionRef.current;
    if (!rendition || !newSettings) return;
    
    // 直接使用 DOM 方法应用样式，完全避免 themes API
    applyThemeToDOM(rendition, newSettings);
  }, []);
  
  const goToChapter = useCallback(async (href: string) => {
    const rendition = renditionRef.current;
    if (!rendition) return false;
    
    try {
      await rendition.display(href);
      toast.success('已跳转');
      return true;
    } catch (error) {
      console.error('跳转失败', error);
      toast.error('跳转失败');
      return false;
    }
  }, []);
  
  const cleanup = useCallback(() => {
    if (renditionRef.current) {
      const cleanupFn = (renditionRef.current as any).__cleanup;
      if (cleanupFn) cleanupFn();
      
      if (typeof renditionRef.current.destroy === 'function') {
        renditionRef.current.destroy();
      }
      renditionRef.current = null;
    }
    
    if (bookRef.current) {
      if (typeof bookRef.current.destroy === 'function') {
        bookRef.current.destroy();
      }
      bookRef.current = null;
    }
    
    setIsReady(false);
    setToc([]);
  }, []);
  
  // 监听窗口大小变化
  useEffect(() => {
    const handleResize = () => {
      const rendition = renditionRef.current;
      const container = containerRef.current;
      if (!rendition || !container) return;
      
      const anchorCfi = progressManagerRef.current.getLastProgress().position?.currentLocation;
      progressManagerRef.current.setRestoringLayout(true);
      
      try {
        rendition.resize(container.offsetWidth, container.offsetHeight);
        
        if (anchorCfi) {
          setTimeout(async () => {
            try {
              await rendition.display(anchorCfi);
            } catch (e) {
              // 忽略定位失败
            } finally {
              setTimeout(() => {
                progressManagerRef.current.setRestoringLayout(false);
              }, 150);
            }
          }, 50);
        } else {
          setTimeout(() => {
            progressManagerRef.current.setRestoringLayout(false);
          }, 150);
        }
      } catch (e) {
        progressManagerRef.current.setRestoringLayout(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [containerRef]);
  
  // 页面隐藏时保存进度
  useEffect(() => {
    const flushProgress = () => {
      const { progress, position } = progressManagerRef.current.getLastProgress();
      if (position) {
        onProgressChange?.(progress, position);
      }
    };
    
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        flushProgress();
      }
    };
    
    const handlePageHide = () => flushProgress();
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('pagehide', handlePageHide);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('pagehide', handlePageHide);
      flushProgress();
    };
  }, [onProgressChange]);
  
  return {
    loading,
    error,
    toc,
    isReady,
    bookInstance: bookRef.current,
    rendition: renditionRef.current,
    initEpubjsReader,
    applySettings,
    goToChapter,
    cleanup,
  };
};
