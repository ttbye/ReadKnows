import { ReactNode } from 'react';

export interface BookData {
  id?: string;
  file_path?: string;
  file_name?: string;
  title?: string;
  author?: string;
  cover?: string;
  [key: string]: any;
}

export interface ReadingSettings {
  theme: 'light' | 'dark' | 'sepia' | 'green';
  fontSize: number;
  fontFamily: 'serif' | 'sans-serif' | 'monospace' | 'default';
  lineHeight: number;
  margin: number;
  textIndent: number;
  readerWidth: 'full' | 'centered';
  pageTurnMethod: 'swipe' | 'click';
  pageTurnMode: 'horizontal' | 'vertical';
  clickToTurn: boolean;
  keyboardShortcuts: {
    prev: string;
    next: string;
  };
}

export interface ReadingPosition {
  chapterIndex?: number;
  currentPage: number;
  totalPages: number;
  progress: number;
  currentLocation?: string;
  chapterTitle?: string;
}

export interface TOCItem {
  id: string;
  title: string;
  href: string;
  level: number;
  chapterIndex: number;
  children?: TOCItem[];
}

export interface ReaderEPUBProProps {
  book: BookData;
  settings: ReadingSettings;
  initialPosition?: ReadingPosition;
  onSettingsChange: (settings: ReadingSettings) => void;
  onProgressChange: (progress: number, position: ReadingPosition) => void;
  onTOCChange: (toc: TOCItem[]) => void;
  onClose: () => void;
}

// EPUB相关类型
export interface EpubInstance {
  book: any;
  rendition: any;
  destroy: () => void;
}

export interface EpubInitOptions {
  fileUrl: string;
  container: HTMLElement | null;
  initialPosition?: ReadingPosition;
  settings?: Partial<ReadingSettings>;
  onTOCLoaded?: (toc: TOCItem[]) => void;
  onProgress?: (progress: number, position: ReadingPosition) => void;
}

// 触摸导航相关
export interface TouchState {
  startX: number;
  startY: number;
  startTime: number;
  clientX: number;
  clientY: number;
}

export interface MoveState {
  maxMoveX: number;
  maxMoveY: number;
  lastX: number;
  lastY: number;
}

export interface PageTurnState {
  lastPageTurnTime: number;
  isTurningPage: boolean;
}

// 设备检测
export interface DeviceInfo {
  isMobile: boolean;
  isPWA: boolean;
  isDesktop: boolean;
  isTablet: boolean;
}

// 主题相关
export interface ThemeConfig {
  bg: string;
  text: string;
  border: string;
  gradient: string;
  shadow: string;
}

export interface LayoutStyles {
  readerWidth: string;
  maxWidth: string;
  margin: string;
  borderRadius: string;
  padding: string;
  background: string;
  boxShadow: string;
  border: string;
}