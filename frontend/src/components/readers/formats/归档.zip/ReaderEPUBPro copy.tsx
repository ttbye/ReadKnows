import React, { useEffect, useRef, useCallback } from 'react';
import { BookData, ReadingSettings, ReadingPosition, TOCItem } from '../../../types/reader';
import ReaderContainer from './compoents/ReaderContainer';
import ReaderView from './compoents/ReaderView';
import { useEpubReader } from './compoents/ReaderHooks/useEpubReader';
import { useTouchNavigation } from './compoents/ReaderHooks/useTouchNavigation';
import { useReaderEvents } from './compoents/ReaderHooks/useReaderEvents';
import { getFileUrl } from './compoents/ReaderUtils/epubUtils';

interface ReaderEPUBProProps {
  book: BookData;
  settings: ReadingSettings;
  initialPosition?: ReadingPosition;
  onSettingsChange: (settings: ReadingSettings) => void;
  onProgressChange: (progress: number, position: ReadingPosition) => void;
  onTOCChange: (toc: TOCItem[]) => void;
  onClose: () => void;
}

export default function ReaderEPUBPro({
  book,
  settings,
  initialPosition,
  onSettingsChange,
  onProgressChange,
  onTOCChange,
  onClose,
}: ReaderEPUBProProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const fileUrlRef = useRef<string | null>(null);
  
  // 使用自定义hooks分离逻辑
  const {
    loading,
    error,
    toc,
    isReady,
    rendition,
    bookInstance,
    initEpubjsReader,
    applySettings,
    goToChapter,
    cleanup,
  } = useEpubReader({
    book,
    containerRef,
    initialPosition,
    settings,
    onTOCChange,
    onProgressChange,
  });
  
  // 显示/隐藏导航栏
  const showBars = useCallback(() => {
    if ((window as any).__toggleReaderNavigation) {
      (window as any).__toggleReaderNavigation();
    }
  }, []);
  
  // 触摸导航
  const {
    handleTouchStart,
    handleTouchMove,
    handleTouchEnd,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleMouseLeave,
  } = useTouchNavigation({
    settings,
    loading,
    rendition,
    onShowBars: showBars,
  });
  
  // 阅读器事件
  const {
    handleResize,
    goToChapter: handleGoToChapterByIndex,
    setupKeyboardShortcuts,
    setupGlobalFunctions,
  } = useReaderEvents({
    settings,
    rendition,
    book: bookInstance,
  });
  
  // 将章节 href 转换为章节索引并跳转
  const handleGoToChapter = useCallback((href: string) => {
    if (!bookInstance || !rendition) return;
    
    try {
      // 尝试通过 href 直接跳转
      rendition.display(href);
    } catch (error) {
      console.error('跳转章节失败', error);
      // 如果失败，尝试通过章节索引跳转
      const spine = bookInstance.spine;
      if (spine) {
        let foundIndex = -1;
        spine.each((item: any, index: number) => {
          if (item && item.href === href) {
            foundIndex = index;
          }
        });
        if (foundIndex >= 0) {
          handleGoToChapterByIndex(foundIndex);
        }
      }
    }
  }, [bookInstance, rendition, handleGoToChapterByIndex]);
  
  // 包装 handleMouseUp 以匹配 ReaderContainer 的签名
  const handleMouseUpWrapper = useCallback(() => {
    handleMouseUp({} as React.MouseEvent);
  }, [handleMouseUp]);
  
  // 初始化阅读器
  useEffect(() => {
    const loadReader = async () => {
      if (!book.id && !book.file_path) return;
      
      try {
        fileUrlRef.current = await getFileUrl(book);
        await initEpubjsReader();
      } catch (err: any) {
        console.error('ReaderEPUBPro: 加载失败', err);
      }
    };
    
    loadReader();
    
    return () => {
      cleanup();
    };
  }, [book.id, book.file_path, initEpubjsReader, cleanup]);
  
  // 设置变化时更新阅读器
  useEffect(() => {
    if (isReady) {
      applySettings(settings);
    }
  }, [settings, isReady, applySettings]);
  
  // 处理窗口大小变化
  useEffect(() => {
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [handleResize]);
  
  // 设置键盘快捷键
  useEffect(() => {
    if (containerRef.current) {
      const cleanupKeyboard = setupKeyboardShortcuts(containerRef.current);
      return cleanupKeyboard;
    }
  }, [setupKeyboardShortcuts]);
  
  // 设置全局函数
  useEffect(() => {
    const cleanupGlobalFunctions = setupGlobalFunctions();
    return cleanupGlobalFunctions;
  }, [setupGlobalFunctions]);
  
  return (
    <ReaderContainer 
      settings={settings}
      containerRef={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUpWrapper}
      onMouseLeave={handleMouseLeave}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <ReaderView
        loading={loading}
        error={error}
        containerRef={containerRef}
        settings={settings}
        toc={toc}
        fileUrl={fileUrlRef.current || undefined}
        initialPosition={initialPosition}
        onChapterSelect={handleGoToChapter}
        onReady={(data) => {
          // 可以在这里做一些额外的初始化
          console.log('ReaderView ready', data);
        }}
      />
    </ReaderContainer>
  );
}