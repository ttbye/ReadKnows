/**
 * EPUB 阅读器核心 - 完整功能版本
 * 整合所有功能模块，提供完整的阅读体验
 */

import { EPUBBook, Chapter, BookInfo, TOCItem } from './EPUBBook';
import { EPUBPage, Page, PaginationOptions } from './EPUBPage';
import { EPUBView } from './EPUBView';

export interface ReaderSettings {
  fontSize: number;
  fontFamily: string;
  lineHeight: number;
  theme: string;
  margin: number;
}

export interface ReadingPosition {
  chapterIndex: number;
  pageIndex: number;
}

export interface Bookmark {
  id: string;
  chapterIndex: number;
  pageIndex: number;
  text: string;
  timestamp: number;
}

export interface Highlight {
  id: string;
  chapterIndex: number;
  pageIndex: number;
  text: string;
  color: string;
  note?: string;
  timestamp: number;
}

export interface Note {
  id: string;
  chapterIndex: number;
  pageIndex: number;
  text: string;
  content: string;
  timestamp: number;
}

export interface SearchResult {
  chapterIndex: number;
  pageIndex: number;
  text: string;
  context: string;
}

export class EPUBReader {
  private container: HTMLElement;
  private book: EPUBBook;
  private page: EPUBPage;
  private view: EPUBView;
  private settings: ReaderSettings;
  
  private currentChapterIndex: number = 0;
  private currentChapter: Chapter | null = null;
  private isPageTurning: boolean = false;
  
  // 高级功能
  private bookmarks: Map<string, Bookmark> = new Map();
  private highlights: Map<string, Highlight> = new Map();
  private notes: Map<string, Note> = new Map();
  private readingHistory: Array<{ chapterIndex: number; pageIndex: number; timestamp: number }> = [];
  
  // 事件回调
  private onProgressChange?: (progress: number, position: ReadingPosition) => void;
  private onPageChange?: (page: number, totalPages: number) => void;
  private onBookmarkChange?: (bookmarks: Bookmark[]) => void;
  private onHighlightChange?: (highlights: Highlight[]) => void;

  constructor(container: HTMLElement, settings: ReaderSettings) {
    this.container = container;
    this.settings = settings;
    
    this.book = new EPUBBook();
    
    // 计算初始容器高度（考虑安全区域和底部导航栏）
    let initialHeight = container.clientHeight;
    const safeAreaBottom = parseFloat(getComputedStyle(container).getPropertyValue('--safe-area-inset-bottom') || '0') || 0;
    const paddingBottom = parseFloat(getComputedStyle(container).getPropertyValue('padding-bottom') || '0') || 0;
    const bottomNavHeight = 42; // 底部导航栏高度
    initialHeight = initialHeight - bottomNavHeight - safeAreaBottom - paddingBottom;
    initialHeight = Math.max(100, initialHeight);
    
    this.page = new EPUBPage({
      containerHeight: initialHeight,
      containerWidth: container.clientWidth,
      fontSize: settings.fontSize,
      lineHeight: settings.lineHeight,
      margin: settings.margin,
    });
    this.view = new EPUBView(container, this.book);
    
    // 监听窗口大小变化
    this.setupResizeObserver();
  }

  /**
   * 设置事件回调
   */
  setCallbacks(callbacks: {
    onProgressChange?: (progress: number, position: ReadingPosition) => void;
    onPageChange?: (page: number, totalPages: number) => void;
    onBookmarkChange?: (bookmarks: Bookmark[]) => void;
    onHighlightChange?: (highlights: Highlight[]) => void;
  }): void {
    this.onProgressChange = callbacks.onProgressChange;
    this.onPageChange = callbacks.onPageChange;
    this.onBookmarkChange = callbacks.onBookmarkChange;
    this.onHighlightChange = callbacks.onHighlightChange;
  }

  /**
   * 设置窗口大小变化监听
   */
  private setupResizeObserver(): void {
    if (typeof ResizeObserver === 'undefined') return;

    let resizeTimeout: NodeJS.Timeout;
    
    const resizeObserver = new ResizeObserver(() => {
      // 防抖处理，避免频繁重新分页
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(async () => {
        const rect = this.container.getBoundingClientRect();
        const currentPageIndex = this.page.getCurrentPageIndex();
        
        // 计算实际可用高度（考虑安全区域和底部导航栏）
        let actualHeight = rect.height;
        const safeAreaBottom = parseFloat(getComputedStyle(this.container).getPropertyValue('--safe-area-inset-bottom') || '0') || 0;
        const paddingBottom = parseFloat(getComputedStyle(this.container).getPropertyValue('padding-bottom') || '0') || 0;
        const bottomNavHeight = 42; // 底部导航栏高度
        actualHeight = actualHeight - bottomNavHeight - safeAreaBottom - paddingBottom;
        actualHeight = Math.max(100, actualHeight);
        
        // 更新分页器选项
        this.page.updateOptions({
          containerHeight: actualHeight,
          containerWidth: rect.width,
        });
        
        // 如果当前有章节，重新分页
        if (this.currentChapter) {
          const contentElement = this.view.getContentElement();
          await this.page.paginate(this.currentChapter, contentElement);
          
          // 更新总页数到视图
          const totalPages = this.page.getTotalPages();
          this.view.setTotalPages(totalPages);
          
          // 尝试恢复到之前的页面位置（如果可能）
          const targetPageIndex = Math.min(currentPageIndex, Math.max(0, totalPages - 1));
          await this.page.goToPage(targetPageIndex);
          
          const currentPage = this.page.getCurrentPage();
          if (currentPage) {
            await this.view.renderPage(currentPage);
            this.updateProgress();
          }
        }
      }, 300); // 300ms 防抖
    });

    resizeObserver.observe(this.container);
  }

  /**
   * 初始化阅读器
   */
  async init(bookData: ArrayBuffer | Blob, position?: ReadingPosition): Promise<BookInfo> {
    // 加载书籍
    const bookInfo = await this.book.loadBook(bookData);
    
    // 加载初始章节
    const chapterIndex = position?.chapterIndex || 0;
    await this.loadChapter(chapterIndex);
    
    // 跳转到指定页
    if (position?.pageIndex !== undefined) {
      await this.page.goToPage(position.pageIndex);
      const page = this.page.getCurrentPage();
      if (page) {
        await this.view.renderPage(page);
      }
    }
    
    return bookInfo;
  }

  /**
   * 加载章节
   */
  async loadChapter(index: number): Promise<void> {
    if (index < 0 || index >= this.book.getTotalChapters()) {
      throw new Error('章节索引无效');
    }

    this.currentChapterIndex = index;
    this.currentChapter = await this.book.loadChapter(index);
    
    // 渲染章节（这会创建 chapter-wrapper 容器）
    await this.view.renderChapter(this.currentChapter);
    
    // 应用样式
    this.view.applyStyles(this.settings);
    
    // 等待DOM完全更新
    await new Promise(resolve => {
      requestAnimationFrame(() => {
        requestAnimationFrame(resolve);
      });
    });
    
    // 确保容器有正确的尺寸后再分页
    const contentElement = this.view.getContentElement();
    const containerRect = contentElement.getBoundingClientRect();
    const containerHeight = contentElement.clientHeight || containerRect.height;
    
    // 如果容器高度为0或太小，等待并重试
    if (containerHeight <= 0 || containerHeight < 100) {
      console.warn(`[EPUBReader] 容器高度异常: ${containerHeight}px, 等待并重试...`);
      
      // 等待容器尺寸稳定
      await new Promise(resolve => {
        let retryCount = 0;
        const checkSize = () => {
          const rect = contentElement.getBoundingClientRect();
          const height = contentElement.clientHeight || rect.height;
          
          if (height > 100 || retryCount >= 10) {
            console.log(`[EPUBReader] 容器高度: ${height}px (重试${retryCount}次)`);
            resolve(undefined);
          } else {
            retryCount++;
            setTimeout(checkSize, 100);
          }
        };
        checkSize();
      });
    }
    
    // 更新分页器选项（确保使用最新的容器尺寸）
    const finalRect = contentElement.getBoundingClientRect();
    const finalHeight = contentElement.clientHeight || finalRect.height;
    const finalWidth = finalRect.width || this.page.options.containerWidth;
    
    this.page.updateOptions({
      containerHeight: finalHeight,
      containerWidth: finalWidth,
    });
    
    // 分页（使用实际容器中的元素）
    const pages = await this.page.paginate(this.currentChapter, contentElement);
    
    // 更新总页数到视图
    const totalPages = this.page.getTotalPages();
    this.view.setTotalPages(totalPages);
    
    // 确保所有元素都有 data-pagination-index 属性
    const wrapper = contentElement.querySelector('.chapter-wrapper');
    if (wrapper) {
      const allElements = Array.from(wrapper.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, blockquote, img, table, pre, code, div, span, section, article, figure, dl, dt, dd, ul, ol')) as HTMLElement[];
      allElements.forEach((el, index) => {
        if (!el.hasAttribute('data-pagination-index')) {
          el.setAttribute('data-pagination-index', index.toString());
        }
      });
    }
    
    if (pages.length > 0) {
      await this.view.renderPage(pages[0]);
      this.updateProgress();
    } else {
      console.warn('[EPUBReader] 分页后没有页面，可能是容器尺寸问题');
    }
  }

  /**
   * 下一页
   */
  async nextPage(): Promise<boolean> {
    if (this.isPageTurning) {
      console.log('[EPUBReader] 正在翻页中，忽略重复请求');
      return false;
    }
    
    this.isPageTurning = true;
    try {
      const success = this.page.nextPage();
      
      if (success) {
        const currentPage = this.page.getCurrentPage();
        if (currentPage) {
          await this.view.renderPage(currentPage, 'forward');
          this.updateProgress();
          this.recordReadingHistory();
          return true;
        }
      } else {
        // 当前章节最后一页，尝试加载下一章
        if (this.currentChapterIndex < this.book.getTotalChapters() - 1) {
          await this.loadChapter(this.currentChapterIndex + 1);
          // loadChapter 会自动跳转到第一页，所以这里直接返回 true
          return true;
        }
      }
      
      return false;
    } finally {
      // 增加延迟时间，确保翻页动画完成
      setTimeout(() => {
        this.isPageTurning = false;
      }, 500);
    }
  }

  /**
   * 上一页
   */
  async prevPage(): Promise<boolean> {
    if (this.isPageTurning) {
      console.log('[EPUBReader] 正在翻页中，忽略重复请求');
      return false;
    }
    
    this.isPageTurning = true;
    try {
      const success = this.page.prevPage();
      
      if (success) {
        const currentPage = this.page.getCurrentPage();
        if (currentPage) {
          await this.view.renderPage(currentPage, 'backward');
          this.updateProgress();
          this.recordReadingHistory();
          return true;
        }
      } else {
        // 当前章节第一页，尝试加载上一章
        if (this.currentChapterIndex > 0) {
          await this.loadChapter(this.currentChapterIndex - 1);
          const totalPages = this.page.getTotalPages();
          if (totalPages > 0) {
            await this.page.goToPage(totalPages - 1);
            const lastPage = this.page.getCurrentPage();
            if (lastPage) {
              await this.view.renderPage(lastPage, 'backward');
              this.updateProgress();
            }
          }
          return true;
        }
      }
      
      return false;
    } finally {
      // 增加延迟时间，确保翻页动画完成
      setTimeout(() => {
        this.isPageTurning = false;
      }, 500);
    }
  }

  /**
   * 跳转到指定页
   */
  async goToPage(pageIndex: number): Promise<boolean> {
    const success = this.page.goToPage(pageIndex);
    if (success) {
      const page = this.page.getCurrentPage();
      if (page) {
        await this.view.renderPage(page);
        this.updateProgress();
        return true;
      }
    }
    return false;
  }

  /**
   * 跳转到指定章节
   */
  async goToChapter(chapterIndex: number, pageIndex: number = 0): Promise<boolean> {
    if (chapterIndex < 0 || chapterIndex >= this.book.getTotalChapters()) {
      return false;
    }

    try {
      await this.loadChapter(chapterIndex);
      if (pageIndex > 0) {
        await this.goToPage(pageIndex);
      }
      return true;
    } catch (error) {
      console.error('[EPUBReader] 跳转章节失败', error);
      return false;
    }
  }

  /**
   * 根据TOC项跳转
   */
  async goToTOCItem(tocItem: TOCItem): Promise<boolean> {
    const chapterIndex = this.book.findChapterIndexByHref(tocItem.href);
    if (chapterIndex >= 0) {
      return await this.goToChapter(chapterIndex);
    }
    return false;
  }

  /**
   * 更新设置
   */
  async updateSettings(settings: Partial<ReaderSettings>): Promise<void> {
    const needsRepagination = !!(settings.fontSize || settings.lineHeight || settings.margin);
    
    this.settings = { ...this.settings, ...settings };
    
    // 更新容器尺寸（考虑安全区域和底部导航栏）
    const rect = this.container.getBoundingClientRect();
    
    // 计算实际可用高度（考虑安全区域和底部导航栏）
    let actualHeight = rect.height;
    const safeAreaBottom = parseFloat(getComputedStyle(this.container).getPropertyValue('--safe-area-inset-bottom') || '0') || 0;
    const paddingBottom = parseFloat(getComputedStyle(this.container).getPropertyValue('padding-bottom') || '0') || 0;
    const bottomNavHeight = 42; // 底部导航栏高度
    actualHeight = actualHeight - bottomNavHeight - safeAreaBottom - paddingBottom;
    actualHeight = Math.max(100, actualHeight);
    
    // 更新分页器选项
    this.page.updateOptions({
      containerHeight: actualHeight,
      containerWidth: rect.width,
      fontSize: this.settings.fontSize,
      lineHeight: this.settings.lineHeight,
      margin: this.settings.margin,
    });
    
    // 应用样式
    this.view.applyStyles(this.settings);
    
    // 如果字体、行高、边距或容器大小改变，重新分页
    if (needsRepagination || settings.containerHeight || settings.containerWidth) {
      if (this.currentChapter) {
        const contentElement = this.view.getContentElement();
        const currentPageIndex = this.page.getCurrentPageIndex();
        
        // 重新分页
        await this.page.paginate(this.currentChapter, contentElement);
        
        // 更新总页数到视图
        const totalPages = this.page.getTotalPages();
        this.view.setTotalPages(totalPages);
        
        // 尝试恢复到之前的页面（如果可能）
        const targetPageIndex = Math.min(currentPageIndex, totalPages - 1);
        await this.page.goToPage(Math.max(0, targetPageIndex));
        
        const currentPage = this.page.getCurrentPage();
        if (currentPage) {
          await this.view.renderPage(currentPage);
          this.updateProgress();
        }
      }
    }
  }

  /**
   * 添加书签
   */
  addBookmark(): Bookmark | null {
    const currentPage = this.page.getCurrentPage();
    if (!currentPage) return null;

    const bookmark: Bookmark = {
      id: `bookmark-${Date.now()}`,
      chapterIndex: this.currentChapterIndex,
      pageIndex: this.page.getCurrentPageIndex(),
      text: this.getCurrentPageText().substring(0, 50),
      timestamp: Date.now(),
    };

    this.bookmarks.set(bookmark.id, bookmark);
    this.onBookmarkChange?.(Array.from(this.bookmarks.values()));
    
    return bookmark;
  }

  /**
   * 删除书签
   */
  removeBookmark(bookmarkId: string): boolean {
    const removed = this.bookmarks.delete(bookmarkId);
    if (removed) {
      this.onBookmarkChange?.(Array.from(this.bookmarks.values()));
    }
    return removed;
  }

  /**
   * 获取所有书签
   */
  getBookmarks(): Bookmark[] {
    return Array.from(this.bookmarks.values());
  }

  /**
   * 跳转到书签
   */
  async goToBookmark(bookmarkId: string): Promise<boolean> {
    const bookmark = this.bookmarks.get(bookmarkId);
    if (!bookmark) return false;

    return await this.goToChapter(bookmark.chapterIndex, bookmark.pageIndex);
  }

  /**
   * 添加高亮
   */
  addHighlight(text: string, color: string = '#ffff00', note?: string): Highlight | null {
    const currentPage = this.page.getCurrentPage();
    if (!currentPage) return null;

    const highlight: Highlight = {
      id: `highlight-${Date.now()}`,
      chapterIndex: this.currentChapterIndex,
      pageIndex: this.page.getCurrentPageIndex(),
      text: text.substring(0, 200),
      color,
      note,
      timestamp: Date.now(),
    };

    this.highlights.set(highlight.id, highlight);
    this.onHighlightChange?.(Array.from(this.highlights.values()));
    
    // 应用高亮样式
    this.applyHighlight(highlight);
    
    return highlight;
  }

  /**
   * 应用高亮样式
   */
  private applyHighlight(highlight: Highlight): void {
    const wrapper = this.view.getContentElement().querySelector('.chapter-wrapper');
    if (!wrapper) return;

    // 查找包含文本的元素并应用高亮
    const walker = document.createTreeWalker(
      wrapper,
      NodeFilter.SHOW_TEXT,
      null
    );

    let node;
    while (node = walker.nextNode()) {
      if (node.textContent && node.textContent.includes(highlight.text)) {
        const parent = node.parentElement;
        if (parent) {
          parent.style.backgroundColor = highlight.color;
          parent.style.opacity = '0.3';
          parent.setAttribute('data-highlight-id', highlight.id);
        }
        break;
      }
    }
  }

  /**
   * 删除高亮
   */
  removeHighlight(highlightId: string): boolean {
    const highlight = this.highlights.get(highlightId);
    if (highlight) {
      // 移除高亮样式
      const wrapper = this.view.getContentElement().querySelector('.chapter-wrapper');
      if (wrapper) {
        const element = wrapper.querySelector(`[data-highlight-id="${highlightId}"]`);
        if (element) {
          element.removeAttribute('data-highlight-id');
          (element as HTMLElement).style.backgroundColor = '';
          (element as HTMLElement).style.opacity = '';
        }
      }
    }

    const removed = this.highlights.delete(highlightId);
    if (removed) {
      this.onHighlightChange?.(Array.from(this.highlights.values()));
    }
    return removed;
  }

  /**
   * 获取所有高亮
   */
  getHighlights(): Highlight[] {
    return Array.from(this.highlights.values());
  }

  /**
   * 添加笔记
   */
  addNote(text: string, content: string): Note | null {
    const currentPage = this.page.getCurrentPage();
    if (!currentPage) return null;

    const note: Note = {
      id: `note-${Date.now()}`,
      chapterIndex: this.currentChapterIndex,
      pageIndex: this.page.getCurrentPageIndex(),
      text: text.substring(0, 200),
      content,
      timestamp: Date.now(),
    };

    this.notes.set(note.id, note);
    return note;
  }

  /**
   * 删除笔记
   */
  removeNote(noteId: string): boolean {
    return this.notes.delete(noteId);
  }

  /**
   * 获取所有笔记
   */
  getNotes(): Note[] {
    return Array.from(this.notes.values());
  }

  /**
   * 搜索文本
   */
  async search(query: string): Promise<SearchResult[]> {
    if (!query.trim()) return [];

    const results: SearchResult[] = [];
    const lowerQuery = query.toLowerCase();

    // 搜索当前章节
    if (this.currentChapter) {
      const text = this.currentChapter.document.body.textContent || '';
      if (text.toLowerCase().includes(lowerQuery)) {
        // 查找所有匹配的位置
        const regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
        let match;
        while ((match = regex.exec(text)) !== null) {
          const pageIndex = this.findPageForTextPosition(match.index);
          results.push({
            chapterIndex: this.currentChapterIndex,
            pageIndex,
            text: match[0],
            context: this.getContext(text, match.index, 50),
          });
        }
      }
    }

    return results;
  }

  /**
   * 查找文本位置对应的页码
   */
  private findPageForTextPosition(position: number): number {
    // 简化实现：返回当前页
    return this.page.getCurrentPageIndex();
  }

  /**
   * 获取上下文文本
   */
  private getContext(text: string, position: number, contextLength: number): string {
    const start = Math.max(0, position - contextLength);
    const end = Math.min(text.length, position + contextLength);
    return text.substring(start, end);
  }

  /**
   * 获取当前页文本
   */
  getCurrentPageText(): string {
    const currentPage = this.page.getCurrentPage();
    if (!currentPage) return '';

    return currentPage.elements
      .map(el => el.textContent || '')
      .join('\n');
  }

  /**
   * 记录阅读历史
   */
  private recordReadingHistory(): void {
    this.readingHistory.push({
      chapterIndex: this.currentChapterIndex,
      pageIndex: this.page.getCurrentPageIndex(),
      timestamp: Date.now(),
    });

    // 只保留最近100条记录
    if (this.readingHistory.length > 100) {
      this.readingHistory.shift();
    }
  }

  /**
   * 获取阅读统计
   */
  getReadingStats(): {
    totalReadingTime: number; // 秒
    pagesRead: number;
    chaptersRead: number;
    averageReadingSpeed: number; // 字/分钟
  } {
    const pagesRead = this.readingHistory.length;
    const chaptersRead = new Set(this.readingHistory.map(h => h.chapterIndex)).size;
    
    // 计算总阅读时间（基于页面预计阅读时间）
    let totalReadingTime = 0;
    const pageTimes = new Map<string, number>();
    
    this.readingHistory.forEach(history => {
      const key = `${history.chapterIndex}-${history.pageIndex}`;
      if (!pageTimes.has(key)) {
        const page = this.page.getPage(history.pageIndex);
        if (page && page.estimatedReadingTime) {
          pageTimes.set(key, page.estimatedReadingTime);
          totalReadingTime += page.estimatedReadingTime;
        }
      }
    });

    // 计算平均阅读速度
    const totalTextLength = this.readingHistory.reduce((sum, history) => {
      const page = this.page.getPage(history.pageIndex);
      if (page) {
        return sum + page.elements.reduce((s, el) => s + (el.textContent?.length || 0), 0);
      }
      return sum;
    }, 0);

    const averageReadingSpeed = totalReadingTime > 0 
      ? Math.round((totalTextLength / totalReadingTime) * 60)
      : 0;

    return {
      totalReadingTime,
      pagesRead,
      chaptersRead,
      averageReadingSpeed,
    };
  }

  /**
   * 更新进度
   */
  private updateProgress(): void {
    const position = this.getPosition();
    const progress = this.getProgress();
    const pageInfo = this.getCurrentPageInfo();
    
    this.onProgressChange?.(progress, position);
    this.onPageChange?.(pageInfo.currentPage, pageInfo.totalPages);
  }

  /**
   * 获取当前阅读位置
   */
  getPosition(): ReadingPosition {
    return {
      chapterIndex: this.currentChapterIndex,
      pageIndex: this.page.getCurrentPageIndex(),
    };
  }

  /**
   * 获取进度
   * 进度计算逻辑：
   * - 已完成章节数 = currentChapterIndex（如果索引是1，说明已完成第0章节）
   * - 当前章节进度 = 当前页索引 / 总页数
   * - 总进度 = (已完成章节数 + 当前章节进度) / 总章节数
   * - 确保进度在 0-100% 范围内
   */
  getProgress(): number {
    const totalChapters = this.book.getTotalChapters();
    if (totalChapters === 0) return 0;
    
    // 计算已完成章节数
    // 当前章节索引从0开始
    // 如果当前在第0章，已完成0章
    // 如果当前在第1章，已完成1章（第0章）
    // 所以已完成章节数 = currentChapterIndex
    const completedChapters = this.currentChapterIndex;
    
    // 计算当前章节的进度（0-1之间）
    const currentChapterPages = this.page.getTotalPages();
    let currentChapterProgress = 0;
    
    if (currentChapterPages > 0) {
      const currentPageIndex = this.page.getCurrentPageIndex();
      
      // 进度计算：当前页索引从0开始
      // 使用更合理的进度计算方式：
      // - 如果只有1页，当前页进度为1（已完成）
      // - 如果是最后一页，当前页进度为1（已完成）
      // - 否则，使用 (currentPageIndex + 0.5) / currentChapterPages 表示在页面中间
      if (currentChapterPages === 1) {
        // 只有一页，已完成
        currentChapterProgress = 1;
      } else if (currentPageIndex >= currentChapterPages - 1) {
        // 最后一页，当前章节进度为1（已完成）
        currentChapterProgress = 1;
      } else {
        // 不是最后一页，使用中间值表示在页面中间
        currentChapterProgress = Math.min(0.99, (currentPageIndex + 0.5) / currentChapterPages);
      }
    }
    
    // 总进度 = (已完成章节数 + 当前章节进度) / 总章节数
    // 例如：共20章，当前在第5章（索引5）的第10页（索引9），共50页
    // completedChapters = 5（已完成前5章）
    // currentChapterProgress = (9 + 0.5) / 50 = 0.19
    // totalProgress = (5 + 0.19) / 20 = 5.19 / 20 = 0.2595 = 25.95%
    let totalProgress = 0;
    if (completedChapters >= totalChapters) {
      totalProgress = 1; // 已读完
    } else {
      // 确保计算出的进度在合理范围内
      totalProgress = Math.min(1, Math.max(0, (completedChapters + currentChapterProgress) / totalChapters));
    }
    
    // 返回 0-1 之间的小数值（与其他阅读器保持一致）
    // ReaderContainer 会将此值乘以 100 转换为百分比
    const progressValue = Math.min(1, Math.max(0, totalProgress));
    
    // 调试日志
    console.log(`[EPUBReader] 进度计算: completedChapters=${completedChapters}, currentChapterIndex=${this.currentChapterIndex}, currentPageIndex=${this.page.getCurrentPageIndex()}, currentChapterPages=${currentChapterPages}, currentChapterProgress=${currentChapterProgress.toFixed(3)}, totalChapters=${totalChapters}, totalProgress=${totalProgress.toFixed(3)}, progressValue=${(progressValue * 100).toFixed(2)}%`);
    
    return progressValue;
  }

  /**
   * 获取当前页信息
   */
  getCurrentPageInfo(): { currentPage: number; totalPages: number } {
    return {
      currentPage: this.page.getCurrentPageIndex() + 1,
      totalPages: this.page.getTotalPages(),
    };
  }

  /**
   * 获取书籍信息
   */
  getBookInfo(): BookInfo | null {
    return this.book.getBookInfo();
  }

  /**
   * 获取目录
   */
  getTOC(): TOCItem[] {
    return this.book.getTOC();
  }

  /**
   * 导出阅读数据
   */
  exportReadingData(): {
    bookmarks: Bookmark[];
    highlights: Highlight[];
    notes: Note[];
    readingHistory: typeof this.readingHistory;
    readingStats: ReturnType<typeof this.getReadingStats>;
  } {
    return {
      bookmarks: Array.from(this.bookmarks.values()),
      highlights: Array.from(this.highlights.values()),
      notes: Array.from(this.notes.values()),
      readingHistory: [...this.readingHistory],
      readingStats: this.getReadingStats(),
    };
  }

  /**
   * 导入阅读数据
   */
  importReadingData(data: {
    bookmarks?: Bookmark[];
    highlights?: Highlight[];
    notes?: Note[];
  }): void {
    if (data.bookmarks) {
      data.bookmarks.forEach(bookmark => {
        this.bookmarks.set(bookmark.id, bookmark);
      });
      this.onBookmarkChange?.(Array.from(this.bookmarks.values()));
    }

    if (data.highlights) {
      data.highlights.forEach(highlight => {
        this.highlights.set(highlight.id, highlight);
        this.applyHighlight(highlight);
      });
      this.onHighlightChange?.(Array.from(this.highlights.values()));
    }

    if (data.notes) {
      data.notes.forEach(note => {
        this.notes.set(note.id, note);
      });
    }
  }

  /**
   * 销毁
   */
  destroy(): void {
    this.view.destroy();
    this.book.destroy();
    this.bookmarks.clear();
    this.highlights.clear();
    this.notes.clear();
    this.readingHistory = [];
  }
}
