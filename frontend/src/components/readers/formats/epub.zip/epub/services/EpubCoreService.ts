/**
 * EPUB 核心服务
 * 管理 EPUB.js 的初始化、主题应用、事件处理等核心逻辑
 */

import type { ReadingSettings, ReadingPosition, TOCItem } from '../../../../../types/reader';
import { buildEpubTheme, applyThemeToDocument, removeInvalidFonts, interceptFontLoading, getThemeStyles } from '../utils/epubUtils';
import { createSelectionListeners } from '../utils/textSelection';

export interface EpubCoreServiceConfig {
  container: HTMLElement;
  fileUrl: string;
  settings: ReadingSettings;
  initialPosition?: ReadingPosition;
  onProgressChange: (progress: number, position: ReadingPosition) => void;
  onTOCChange: (toc: TOCItem[]) => void;
  onSettingsRef: React.MutableRefObject<ReadingSettings>;
  onReadingStateRefs: {
    locationsReadyRef: React.MutableRefObject<boolean>;
    totalLocationsRef: React.MutableRefObject<number>;
    lastCfiRef: React.MutableRefObject<string | null>;
    isRestoringLayoutRef: React.MutableRefObject<boolean>;
    lastProgressRef: React.MutableRefObject<number>;
    lastPositionRef: React.MutableRefObject<ReadingPosition | null>;
    totalChaptersRef: React.MutableRefObject<number>;
  };
}

export interface EpubCoreServiceResult {
  book: any;
  rendition: any;
  cleanup: () => void;
}

/**
 * EPUB 核心服务类
 */
export class EpubCoreService {
  private book: any = null;
  private rendition: any = null;
  private spine: any = null; // 保存 spine 引用，避免在重试时丢失
  private spineItems: any[] = []; // 保存 spine.items 的副本，避免 items 被清空
  private cleanupFunctions: (() => void)[] = [];

  /**
   * 初始化 EPUB 阅读器
   */
  async initialize(config: EpubCoreServiceConfig): Promise<EpubCoreServiceResult> {
    const {
      container,
      fileUrl,
      settings,
      initialPosition,
      onProgressChange,
      onTOCChange,
      onSettingsRef,
      onReadingStateRefs,
    } = config;

    // 确保容器有尺寸
    if (container.offsetWidth === 0 || container.offsetHeight === 0) {
      container.style.width = '100%';
      container.style.height = '100%';
    }

    const containerWidth = container.offsetWidth || window.innerWidth;
    const containerHeight = container.offsetHeight || window.innerHeight;

    // 动态导入 epubjs
    const { default: ePub } = await import('epubjs');

    // 创建 book 实例
    // 注意：epubjs 在创建实例时可能会触发内部错误（如 replaceCss），但这些错误通常是非致命的
    // 我们使用全局错误处理来捕获这些错误，确保它们不会阻止初始化
    let bookInstance: any;
    
    // 设置全局错误处理器，捕获 epubjs 内部的非致命错误
    const originalConsoleError = console.error;
    const errorHandler = (error: any) => {
      // 如果是 replaceCss 错误，只警告不阻止
      if (error?.message?.includes('replaceCss') || error?.stack?.includes('replaceCss')) {
        console.warn('EpubCoreService: epubjs 内部 replaceCss 错误（非致命）', error);
        return;
      }
      // 其他错误正常处理
      originalConsoleError.call(console, error);
    };
    
    // 设置全面的错误捕获（包括异步错误和 Promise 错误）
    const originalWindowError = window.onerror;
    const originalUnhandledRejection = window.onunhandledrejection;
    
    // 捕获同步和异步错误
    window.onerror = (message, source, lineno, colno, error) => {
      if (message?.toString().includes('replaceCss') || error?.message?.includes('replaceCss')) {
        console.warn('EpubCoreService: 捕获到 replaceCss 错误（非致命，已忽略）', message);
        return true; // 阻止默认错误处理
      }
      if (originalWindowError) {
        return originalWindowError(message, source, lineno, colno, error);
      }
      return false;
    };
    
    // 捕获未处理的 Promise 错误
    window.onunhandledrejection = ((event: PromiseRejectionEvent) => {
      const reason = event.reason;
      if (reason?.message?.includes('replaceCss') || reason?.toString()?.includes('replaceCss')) {
        console.warn('EpubCoreService: 捕获到 replaceCss Promise 错误（非致命，已忽略）', reason);
        event.preventDefault(); // 阻止默认错误处理
        return;
      }
      if (originalUnhandledRejection) {
        originalUnhandledRejection.call(window, event);
      }
    }) as typeof window.onunhandledrejection;
    
    // 使用 addEventListener 作为额外保障（捕获异步错误）
    const errorListener = (event: ErrorEvent) => {
      if (event.message?.includes('replaceCss') || event.error?.message?.includes('replaceCss')) {
        console.warn('EpubCoreService: 通过 addEventListener 捕获到 replaceCss 错误（非致命，已忽略）', event.message);
        event.preventDefault();
        event.stopPropagation();
      }
    };
    window.addEventListener('error', errorListener, true);

    try {
      bookInstance = ePub(fileUrl, {
        openAs: 'epub',
      });
      
      // 等待一小段时间，让 epubjs 完成内部初始化（即使有 replaceCss 错误）
      await new Promise(resolve => setTimeout(resolve, 500));
      
    } catch (error: any) {
      console.error('EpubCoreService: 创建 book 实例失败', error);
      // 恢复错误处理
      window.onerror = originalWindowError;
      window.onunhandledrejection = originalUnhandledRejection;
      window.removeEventListener('error', errorListener, true);
      throw new Error(`创建 EPUB 实例失败: ${error.message || '未知错误'}`);
    }

    this.book = bookInstance;

    // 等待 book 加载完成
    // 使用 Promise.race 确保即使有错误也能继续
    try {
      await Promise.race([
        bookInstance.ready,
        new Promise((_, reject) => setTimeout(() => reject(new Error('ready 超时')), 10000))
      ]);
    } catch (error: any) {
      // epubjs 内部可能有一些非致命错误（如 replaceCss），继续执行
      console.warn('EpubCoreService: book.ready 过程中有错误，但继续执行', error);
      // 等待一段时间让 epubjs 完成内部处理
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    try {
      await Promise.race([
        bookInstance.loaded.navigation,
        new Promise((_, reject) => setTimeout(() => reject(new Error('navigation 超时')), 10000))
      ]);
    } catch (error: any) {
      // navigation 加载失败，尝试继续
      console.warn('EpubCoreService: navigation 加载过程中有错误，但继续执行', error);
      // 等待一段时间后继续
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // 恢复原始错误处理
    window.onerror = originalWindowError;
    window.onunhandledrejection = originalUnhandledRejection;
    window.removeEventListener('error', errorListener, true);

    // 获取目录和 spine
    const navigation = bookInstance.navigation;
    let spine = bookInstance.spine;
    
    // 等待 spine 初始化完成（因为 replaceCss 错误可能导致延迟）
    console.log('EpubCoreService: 检查 spine 是否已准备好...');
    let spineReady = false;
    let retryCount = 0;
    const maxRetries = 10;
    
    while (!spineReady && retryCount < maxRetries) {
      const spineItems = (spine as any).items || [];
      if (spineItems.length > 0) {
        console.log(`EpubCoreService: spine 已准备好，包含 ${spineItems.length} 个章节`);
        spineReady = true;
        break;
      }
      
      console.log(`EpubCoreService: spine 尚未准备好，等待中... (${retryCount + 1}/${maxRetries})`);
      await new Promise(resolve => setTimeout(resolve, 500));
      retryCount++;
      
      // 重新获取 spine（可能已经更新）
      spine = bookInstance.spine;
    }
    
    if (!spineReady) {
      console.warn('EpubCoreService: spine 等待超时，但继续执行');
    }
    
    // 保存 spine 引用和 items 副本到类成员变量，避免在重试时丢失
    // 关键：保存 items 的副本，因为 spine.items 可能被 epubjs 清空
    const spineItems = (spine as any).items || [];
    if (spineItems.length > 0) {
      this.spine = spine;
      // 保存 items 的深拷贝，避免被 epubjs 清空
      this.spineItems = spineItems.map((item: any) => ({ ...item }));
      console.log(`EpubCoreService: 保存 spine 引用和 ${this.spineItems.length} 个章节的副本`);
    } else {
      console.warn('EpubCoreService: spine items 为空，尝试从 bookInstance 重新获取');
      // 尝试从 bookInstance 重新获取
      try {
        const refreshedSpine = bookInstance.spine;
        if (refreshedSpine) {
          const refreshedItems = (refreshedSpine as any).items || [];
          if (refreshedItems.length > 0) {
            this.spine = refreshedSpine;
            this.spineItems = refreshedItems.map((item: any) => ({ ...item }));
            console.log(`EpubCoreService: 从 bookInstance 重新获取并保存 spine，items.length = ${this.spineItems.length}`);
          }
        }
      } catch (e) {
        console.error('EpubCoreService: 重新获取 spine 失败', e);
      }
    }

    const tocItems: TOCItem[] = (navigation?.toc || []).map((item: any, index: number) => {
      let spineIndex = -1;
      try {
        // 避免使用 spine.get()，改用遍历查找
        const spineItems = (spine as any).items || [];
        for (let i = 0; i < spineItems.length; i++) {
          const spineItem = spineItems[i];
          if (spineItem && spineItem.href === item.href) {
            spineIndex = spineItem.index !== undefined ? spineItem.index : i;
            break;
          }
        }
      } catch (e) {
        // 查找失败，使用默认索引
      }

      return {
        id: item.id || `toc-${index}`,
        title: item.label || `目录项 ${index + 1}`,
        href: item.href,
        level: item.level || 1,
        chapterIndex: spineIndex >= 0 ? spineIndex : index,
      };
    });

    onTOCChange(tocItems);

    // 计算并保存总章节数
    this.calculateTotalChapters(spine, tocItems, onReadingStateRefs.totalChaptersRef);

    // 创建 rendition 配置
    const renditionConfig: any = {
      width: containerWidth,
      height: containerHeight,
      flow: 'paginated',
      spread: 'none',
      allowScriptedContent: true,
    };

    // 创建 rendition
    const rendition = bookInstance.renderTo(container, renditionConfig);
    this.rendition = rendition;

    // 等待一小段时间，确保 rendition 已初始化
    await new Promise(resolve => setTimeout(resolve, 100));

    // 应用主题
    const theme = buildEpubTheme(settings);
    rendition.themes.default(theme);

    // 设置内容加载钩子（必须在 display 之前注册，但只使用事件，不使用 content hook）
    // 这样可以确保在内容加载时能处理，但不会干扰 epubjs 内部流程
    this.setupContentHook(rendition, onSettingsRef, onReadingStateRefs);

    // 恢复阅读位置或显示第一页
    // 注意：display 会触发 epubjs 内部的 content hook，我们的 hook 不应该干扰它
    console.log('EpubCoreService: 开始恢复位置...');
    
    // 获取第一页的辅助函数（完全避免使用 spine.get，因为它可能失败）
    // 注意：优先使用保存的 this.spine，如果不可用再尝试从 this.book.spine 获取
    const getFirstItem = async (): Promise<any> => {
      try {
        // 优先使用保存的 spine 引用
        let currentSpine = this.spine;
        
        // 如果保存的 spine 不可用，尝试从 book 获取
        if (!currentSpine) {
          const currentBook = this.book || bookInstance;
          if (currentBook) {
            currentSpine = currentBook.spine;
            // 如果获取成功，更新保存的引用
            if (currentSpine) {
              this.spine = currentSpine;
            }
          }
        }
        
        // 如果仍然不可用，等待并重试
        if (!currentSpine) {
          console.warn('EpubCoreService: spine 不存在，等待...');
          for (let i = 0; i < 5; i++) {
            await new Promise(resolve => setTimeout(resolve, 300));
            const currentBook = this.book || bookInstance;
            if (currentBook) {
              currentSpine = currentBook.spine;
              if (currentSpine) {
                this.spine = currentSpine; // 更新保存的引用
                console.log('EpubCoreService: 等待后获取到 spine');
                break;
              }
            }
          }
        }
        
        if (!currentSpine) {
          console.error('EpubCoreService: 无法获取 spine');
          return null;
        }
        
        // 方法1: 优先使用保存的 spineItems 副本（不会被清空）
        let spineItems = this.spineItems.length > 0 ? this.spineItems : [];
        
        // 如果副本为空，尝试从 currentSpine 获取
        if (spineItems.length === 0) {
          spineItems = (currentSpine as any).items || [];
          // 如果从 currentSpine 获取到 items，更新副本
          if (spineItems.length > 0) {
            this.spineItems = spineItems.map((item: any) => ({ ...item }));
            console.log(`EpubCoreService: 从 currentSpine 获取到 ${spineItems.length} 个章节并更新副本`);
          }
        }
        
        // 如果仍然为空，等待并重试
        if (spineItems.length === 0) {
          console.log('EpubCoreService: spine.items 为空，等待并重试...');
          for (let i = 0; i < 5; i++) {
            await new Promise(resolve => setTimeout(resolve, 300));
            const currentBook = this.book || bookInstance; // 重新获取 book
            if (currentBook) {
              const refreshedSpine = currentBook.spine; // 重新获取 spine
              if (refreshedSpine) {
                currentSpine = refreshedSpine; // 更新 currentSpine
                this.spine = refreshedSpine; // 更新保存的引用
                const refreshedItems = (refreshedSpine as any).items || [];
                if (refreshedItems.length > 0) {
                  spineItems = refreshedItems;
                  this.spineItems = refreshedItems.map((item: any) => ({ ...item })); // 更新副本
                  console.log(`EpubCoreService: 等待后获取到 ${spineItems.length} 个章节`);
                  break;
                }
              }
            }
          }
        }
        
        if (spineItems.length > 0) {
          for (let i = 0; i < spineItems.length; i++) {
            const item = spineItems[i];
            if (item && item.href && typeof item.href === 'string' && item.href.trim()) {
              console.log('EpubCoreService: 从 spine.items 获取第一页', item.href);
              return item;
            }
          }
        }
        
        // 方法2: 遍历 spine（如果 items 不可用）
        let foundItem: any = null;
        try {
          if (currentSpine && typeof currentSpine.each === 'function') {
            currentSpine.each((item: any) => {
              if (!foundItem && item && item.href && typeof item.href === 'string' && item.href.trim()) {
                foundItem = item;
                return false; // 停止遍历
              }
            });
          }
        } catch (e) {
          // 遍历失败，忽略
        }
        
        if (foundItem && foundItem.href) {
          console.log('EpubCoreService: 从遍历获取第一页', foundItem.href);
          return foundItem;
        }
        
        // 注意：不再使用 spine.get()，因为它会触发 isCfiString 错误
        
        console.warn('EpubCoreService: 无法获取第一页，spine.items.length =', spineItems.length);
        return null;
      } catch (e) {
        console.error('EpubCoreService: 获取第一页失败', e);
        return null;
      }
    };

    try {
      // 优先使用保存的 spineItems 副本（它不会被清空）
      // 如果保存的副本为空，尝试从参数 spine 或 bookInstance 获取
      let spineToUse = this.spine;
      let itemsToUse = this.spineItems;
      
      console.log(`EpubCoreService: 保存的 spineItems 副本长度 = ${itemsToUse.length}`);
      
      if (itemsToUse.length === 0) {
        console.warn('EpubCoreService: 保存的 spineItems 副本为空，尝试从参数 spine 获取');
        const paramSpineItems = (spine as any).items || [];
        if (paramSpineItems.length > 0) {
          console.log(`EpubCoreService: 参数 spine 有 ${paramSpineItems.length} 个章节，使用参数 spine`);
          spineToUse = spine;
          this.spine = spine;
          this.spineItems = paramSpineItems.map((item: any) => ({ ...item }));
          itemsToUse = this.spineItems;
        } else {
          // 如果参数 spine 也为空，尝试从 bookInstance 重新获取
          console.warn('EpubCoreService: 参数 spine items 也为空，尝试从 bookInstance 重新获取');
          try {
            const refreshedSpine = bookInstance?.spine;
            if (refreshedSpine) {
              const refreshedItems = (refreshedSpine as any).items || [];
              if (refreshedItems.length > 0) {
                console.log(`EpubCoreService: 从 bookInstance 获取到 ${refreshedItems.length} 个章节`);
                spineToUse = refreshedSpine;
                this.spine = refreshedSpine;
                this.spineItems = refreshedItems.map((item: any) => ({ ...item }));
                itemsToUse = this.spineItems;
              }
            }
          } catch (e) {
            console.error('EpubCoreService: 获取 bookInstance.spine 失败', e);
          }
        }
      }
      
      // 如果仍然没有 items，抛出错误
      if (itemsToUse.length === 0) {
        throw new Error('无法获取有效的 spine items');
      }
      
      // 创建一个临时的 spine 对象，包含保存的 items
      // 这样 restorePosition 可以使用它
      const spineWithItems = spineToUse || {};
      // 确保 spine 对象有 items 属性
      if (!spineWithItems.items || spineWithItems.items.length === 0) {
        // 如果 spine 对象的 items 为空，创建一个包含 items 的对象
        Object.defineProperty(spineWithItems, 'items', {
          value: itemsToUse,
          writable: true,
          enumerable: true,
          configurable: true
        });
      }
      
      await this.restorePosition(rendition, spineWithItems, container, initialPosition);
      console.log('EpubCoreService: 位置恢复成功');
    } catch (error) {
      console.error('EpubCoreService: 恢复位置失败', error);
      // 即使恢复失败，也继续初始化
      // 尝试强制显示第一页
      try {
        const firstItem = await getFirstItem();
        if (firstItem && firstItem.href) {
          console.log('EpubCoreService: 尝试强制显示第一页', firstItem.href);
          await Promise.race([
            rendition.display(firstItem.href),
            new Promise((_, reject) => setTimeout(() => reject(new Error('强制显示超时')), 10000))
          ]);
          await new Promise(resolve => setTimeout(resolve, 500));
          console.log('EpubCoreService: 强制显示完成');
        } else {
          console.warn('EpubCoreService: 无法获取第一页，跳过显示');
        }
      } catch (fallbackError) {
        console.error('EpubCoreService: 强制显示也失败', fallbackError);
        // 即使失败也继续，让初始化完成
      }
    }

    // 设置位置变化监听
    this.setupRelocatedListener(rendition, bookInstance, onProgressChange, onReadingStateRefs);

    // 设置键盘快捷键
    this.setupKeyboardShortcuts(rendition, settings);

    // 设置窗口大小变化监听
    const resizeCleanup = this.setupResizeHandler(rendition, container, onReadingStateRefs);
    this.cleanupFunctions.push(resizeCleanup);

    // 暴露全局函数
    this.exposeGlobalFunctions(rendition, bookInstance);

    // 检查内容是否已显示，如果没有，尝试强制显示
    console.log('EpubCoreService: 检查内容是否已显示...');
    
    // 辅助函数：查找 iframe
    const findIframe = (): HTMLIFrameElement | null => {
      try {
        // 方法1: 通过 rendition.manager.views() 获取
        if (rendition?.manager?.views) {
          const views = rendition.manager.views();
          if (views && views.length > 0) {
            const view = views[0];
            if (view?.iframe) {
              return view.iframe;
            }
          }
        }
        
        // 方法2: 通过 rendition.manager.current 获取
        if (rendition?.manager?.current?.iframe) {
          return rendition.manager.current.iframe;
        }
        
        // 方法3: 在 container 中查找
        const iframe = container.querySelector('iframe');
        if (iframe) {
          return iframe;
        }
        
        // 方法4: 在整个文档中查找（作为最后手段）
        const allIframes = document.querySelectorAll('iframe');
        for (let i = 0; i < allIframes.length; i++) {
          const iframe = allIframes[i];
          // 检查 iframe 是否在 container 内或其父元素
          let parent: HTMLElement | null = iframe.parentElement;
          while (parent) {
            if (parent === container) {
              return iframe;
            }
            parent = parent.parentElement;
          }
        }
      } catch (e) {
        console.warn('EpubCoreService: 查找 iframe 时出错', e);
      }
      return null;
    };
    
    // 辅助函数：检查 iframe 内容是否已加载
    const checkIframeContent = (iframe: HTMLIFrameElement): boolean => {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc && iframeDoc.body) {
          // 检查是否有内容（文本或子元素）
          const hasText = iframeDoc.body.textContent && iframeDoc.body.textContent.trim().length > 0;
          const hasChildren = iframeDoc.body.children.length > 0;
          const hasInnerHTML = iframeDoc.body.innerHTML && iframeDoc.body.innerHTML.trim().length > 0;
          
          if (hasText || hasChildren || hasInnerHTML) {
            console.log('EpubCoreService: iframe 内容已加载', {
              hasText,
              hasChildren,
              hasInnerHTML,
              childrenCount: iframeDoc.body.children.length
            });
            return true;
          }
        }
      } catch (e) {
        // 可能是跨域问题，但 iframe 存在也算成功
        console.warn('EpubCoreService: 无法访问 iframe 内容（可能是跨域）', e);
        // 如果 iframe 存在，即使无法访问内容，也认为可能已加载
        return true;
      }
      return false;
    };
    
    let contentDisplayed = false;
    let iframe: HTMLIFrameElement | null = null;
    
    // 第一次检查
    try {
      iframe = findIframe();
      if (iframe) {
        console.log('EpubCoreService: 找到 iframe');
        // 等待一小段时间确保内容开始渲染
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        if (checkIframeContent(iframe)) {
          contentDisplayed = true;
        } else {
          console.warn('EpubCoreService: iframe 存在但内容尚未加载');
        }
      } else {
        console.warn('EpubCoreService: 未找到 iframe，可能内容尚未渲染');
      }
    } catch (error) {
      console.warn('EpubCoreService: 检查内容时出错', error);
    }
    
    // 如果内容未显示，等待更长时间并重试
    if (!contentDisplayed) {
      console.log('EpubCoreService: 内容未显示，等待更长时间并重试...');
      
      // 监听 rendered 事件
      let renderedResolved = false;
      const renderedHandler = () => {
        console.log('EpubCoreService: rendered 事件触发（在检查阶段）');
        renderedResolved = true;
      };
      
      rendition.on('rendered', renderedHandler);
      
      // 等待最多 5 秒，检查 iframe 和内容
      for (let i = 0; i < 10; i++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (renderedResolved) {
          console.log('EpubCoreService: rendered 事件已触发，认为内容已显示');
          contentDisplayed = true;
          break;
        }
        
        iframe = findIframe();
        if (iframe && checkIframeContent(iframe)) {
          console.log('EpubCoreService: 等待后找到 iframe 且包含内容');
          contentDisplayed = true;
          break;
        }
      }
      
      rendition.off('rendered', renderedHandler);
      
      // 如果仍然未显示，尝试再次调用 display
      if (!contentDisplayed) {
        console.warn('EpubCoreService: 内容仍未显示，尝试再次调用 display...');
        try {
          const firstItem = await getFirstItem();
          if (firstItem && firstItem.href) {
            console.log('EpubCoreService: 重试显示第一页', firstItem.href);
            
            // 监听 rendered 事件
            let retryRendered = false;
            const retryRenderedHandler = () => {
              console.log('EpubCoreService: rendered 事件触发（重试阶段）');
              retryRendered = true;
            };
            
            rendition.on('rendered', retryRenderedHandler);
            
            try {
              await Promise.race([
                rendition.display(firstItem.href),
                new Promise((_, reject) => setTimeout(() => reject(new Error('重试 display 超时')), 8000))
              ]);
            } catch (e) {
              console.warn('EpubCoreService: 重试 display Promise 失败', e);
            }
            
            // 等待 rendered 事件或检查 iframe
            for (let i = 0; i < 10; i++) {
              await new Promise(resolve => setTimeout(resolve, 500));
              
              if (retryRendered) {
                console.log('EpubCoreService: 重试后 rendered 事件已触发');
                contentDisplayed = true;
                break;
              }
              
              iframe = findIframe();
              if (iframe && checkIframeContent(iframe)) {
                console.log('EpubCoreService: 重试后找到 iframe 且包含内容');
                contentDisplayed = true;
                break;
              }
            }
            
            rendition.off('rendered', retryRenderedHandler);
            
            if (contentDisplayed) {
              console.log('EpubCoreService: 重试 display 成功');
            } else {
              console.warn('EpubCoreService: 重试 display 后内容仍未显示');
            }
          }
        } catch (e) {
          console.warn('EpubCoreService: 重试 display 失败', e);
        }
      }
    }
    
    // 最终检查
    if (!contentDisplayed) {
      console.warn('EpubCoreService: 警告！内容可能未正确显示，但继续初始化');
      // 即使未检测到内容，也继续初始化，因为可能是检测逻辑的问题
    } else {
      console.log('EpubCoreService: 内容已确认显示');
    }

    console.log('EpubCoreService: 初始化完成');
    return {
      book: this.book,
      rendition: this.rendition,
      cleanup: () => this.cleanup(),
    };
  }

  /**
   * 计算总章节数
   */
  private calculateTotalChapters(
    spine: any,
    tocItems: TOCItem[],
    totalChaptersRef: React.MutableRefObject<number>
  ) {
    try {
      let totalChapters = 0;

      // 方法1：使用 spine.items 数组长度
      const spineItems = (spine as any).items || [];
      if (spineItems.length > 0) {
        totalChapters = spineItems.length;
      } else {
        // 方法2：遍历 spine 获取最大索引 + 1
        try {
          let maxIndex = -1;
          let itemCount = 0;
          spine.each((item: any) => {
            itemCount++;
            if (item.index !== undefined && item.index > maxIndex) {
              maxIndex = item.index;
            }
          });
          if (maxIndex >= 0) {
            totalChapters = maxIndex + 1;
          } else if (itemCount > 0) {
            totalChapters = itemCount;
          }
        } catch (e) {
          // 遍历失败
        }

        // 方法3：使用 TOC 项数量
        if (totalChapters === 0 && tocItems.length > 0) {
          totalChapters = tocItems.length;
        }
      }

      if (totalChapters > 0) {
        totalChaptersRef.current = totalChapters;
      } else {
        totalChaptersRef.current = 1;
      }
    } catch (e) {
      console.error('EpubCoreService: 获取总章节数失败', e);
      totalChaptersRef.current = 1;
    }
  }

  /**
   * 应用 epubjs Hook 兼容补丁
   * 注意：此补丁可能会破坏某些 epubjs 内部功能，如果遇到问题可以禁用
   */
  private patchEpubjsHooks(rendition: any) {
    try {
      const contentHook: any = rendition?.hooks?.content;
      if (!contentHook) return;

      // 更安全的方式：只在特定错误发生时才包装
      // 先尝试不包装，如果出现问题再考虑包装
      // 这里暂时禁用补丁，因为可能会破坏 replaceCss 等内部方法
      
      // 如果需要启用补丁，可以使用以下代码：
      /*
      const hookList: any[] =
        (contentHook && Array.isArray(contentHook.hooks) && contentHook.hooks) ||
        (contentHook && Array.isArray(contentHook.list) && contentHook.list) ||
        [];

      if (hookList.length > 0) {
        const wrapped = hookList.map((fn: any) => {
          if (typeof fn !== 'function') return fn;
          if ((fn as any).__rkWrapped) return fn;
          
          // 保留原始函数的所有属性
          const w = function (...args: any[]) {
            try {
              return fn.apply(this, args);
            } catch (e: any) {
              const first = args[0];
              const msg = String(e?.message || '');
              const isDocTypeError =
                msg.includes('getElementsByTagName is not a function') ||
                msg.includes('createElement is not a function') ||
                msg.includes("reading 'ownerDocument'");
              if (
                isDocTypeError &&
                first &&
                first.document &&
                typeof first.document.createElement === 'function'
              ) {
                try {
                  return fn.apply(this, [first.document, ...args.slice(1)]);
                } catch {
                  // fallthrough to rethrow original
                }
              }
              throw e;
            }
          };
          
          // 复制所有属性
          Object.keys(fn).forEach(key => {
            (w as any)[key] = (fn as any)[key];
          });
          
          (w as any).__rkWrapped = true;
          return w;
        });
        if (Array.isArray((contentHook as any).hooks)) (contentHook as any).hooks = wrapped;
        else if (Array.isArray((contentHook as any).list)) (contentHook as any).list = wrapped;
      }
      */
    } catch {
      // ignore
    }
  }

  /**
   * 设置内容加载钩子
   * 关键：使用 content hook 确保在内容加载时立即处理（就像原代码那样）
   * 注意：epubjs 的 content hook 传入的是 Contents 对象，需要从中获取 document
   */
  private setupContentHook(
    rendition: any,
    settingsRef: React.MutableRefObject<ReadingSettings>,
    readingStateRefs: EpubCoreServiceConfig['onReadingStateRefs']
  ) {
    // 处理内容的函数（就像原代码那样）
    const processContent = (doc: Document) => {
      if (!doc || typeof doc.createElement !== 'function') return;

      // 使用 setTimeout 确保在 epubjs 内部操作完成后执行（原代码使用 100ms）
      setTimeout(() => {
        try {
          // 拦截字体加载
          try {
            const iframeWindow = doc.defaultView || (doc as any).parentWindow;
            if (iframeWindow) {
              interceptFontLoading(iframeWindow);
            }
          } catch (e) {
            // 拦截失败，忽略
          }

          // 移除无效字体
          try {
            removeInvalidFonts(doc);
          } catch (e) {
            // 移除失败，忽略
          }

          // 应用主题
          try {
            const currentSettings = settingsRef.current;
            const themeStyles = getThemeStyles(currentSettings.theme);
            applyThemeToDocument(doc, currentSettings, themeStyles);
          } catch (e) {
            console.error('EpubCoreService: 应用主题失败', e);
          }

          // 设置文本选择监听
          try {
            const win = doc.defaultView;
            const iframeEl = (win?.frameElement as HTMLElement | null) || null;
            const cleanupSelection = createSelectionListeners(doc, win, iframeEl, rendition);
            this.cleanupFunctions.push(cleanupSelection);
          } catch (e) {
            console.error('EpubCoreService: 设置文本选择监听失败', e);
          }

          // 设置主题观察器
          try {
            const currentSettings = settingsRef.current;
            const themeStyles = getThemeStyles(currentSettings.theme);
            this.setupThemeObserver(doc, settingsRef, themeStyles);
          } catch (e) {
            console.error('EpubCoreService: 设置主题观察器失败', e);
          }
        } catch (error) {
          console.error('EpubCoreService: 处理内容出错', error);
        }
      }, 100); // 使用 100ms 延迟，与原代码一致
    };

    // 关键：使用 content hook（就像原代码那样）
    // epubjs 的 content hook 传入的是 Contents 对象：{ document, window, on(), addStylesheetRules(), ... }
    // 注意：某些场景下第1参会是 Document（见下方 trigger patch），第2参才是 Contents
    if (rendition?.hooks?.content && typeof rendition.hooks.content.register === 'function') {
      try {
        rendition.hooks.content.register((a0: any, a1?: any) => {
          // 兼容：某些场景下第1参会是 Document，第2参才是 Contents
          const contents = a1 && a1.document ? a1 : a0;
          const doc = contents?.document || a0;
          
          // 确保 doc 是一个有效的 Document 对象
          if (!doc || typeof doc.createElement !== 'function') {
            console.warn('EpubCoreService: contents.document 不是有效的 Document 对象', doc);
            return;
          }

          // 处理内容
          processContent(doc);
        });
      } catch (e) {
        console.warn('EpubCoreService: 无法注册 content hook', e);
      }
    }

    // 备用：使用 rendered 事件（作为补充）
    if (typeof rendition.on === 'function') {
      try {
        rendition.on('rendered', (view: any) => {
          try {
            if (view && view.document) {
              processContent(view.document);
            }
          } catch (error) {
            console.error('EpubCoreService: rendered 事件出错', error);
          }
        });
      } catch (e) {
        console.warn('EpubCoreService: 无法注册 rendered 事件', e);
      }
    }

    // 备用：使用 relocated 事件（当页面切换时也会触发）
    if (typeof rendition.on === 'function') {
      try {
        rendition.on('relocated', () => {
          // 延迟执行，确保内容已渲染
          setTimeout(() => {
            try {
              const views = rendition.views();
              if (views && views.length > 0) {
                views.forEach((view: any) => {
                  if (view && view.document) {
                    processContent(view.document);
                  }
                });
              }
            } catch (error) {
              console.error('EpubCoreService: relocated 事件处理出错', error);
            }
          }, 200);
        });
      } catch (e) {
        console.warn('EpubCoreService: 无法注册 relocated 事件', e);
      }
    }
  }

  /**
   * 设置主题观察器
   */
  private setupThemeObserver(
    doc: Document,
    settingsRef: React.MutableRefObject<ReadingSettings>,
    themeStyles: ReturnType<typeof import('../utils/epubUtils').getThemeStyles>
  ) {
    if ((doc as any).__epubThemeObserver) return;

    const applyTheme = () => {
      const latestSettings = settingsRef.current;
      const latestThemeStyles = getThemeStyles(latestSettings.theme);
      applyThemeToDocument(doc, latestSettings, latestThemeStyles);
    };

    const themeObserver = new MutationObserver(() => {
      applyTheme();
    });

    themeObserver.observe(doc.body || doc.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class'],
    });

    (doc as any).__epubThemeObserver = themeObserver;
    this.cleanupFunctions.push(() => {
      themeObserver.disconnect();
    });
  }

  /**
   * 恢复阅读位置
   */
  private async restorePosition(
    rendition: any,
    spine: any,
    container: HTMLElement,
    initialPosition?: ReadingPosition
  ) {
    let displayPromise: Promise<any> | null = null;
    let restoredByCFI = false;

    // 优先使用保存的 spineItems 副本（不会被清空）
    // 如果副本为空，尝试从 this.spine、this.book.spine 或参数 spine 获取
    let currentSpine = this.spine || spine;
    let itemsToUse = this.spineItems.length > 0 ? this.spineItems : [];
    
    console.log(`EpubCoreService: restorePosition 初始，保存的 spineItems 副本长度 = ${itemsToUse.length}`);
    
    // 如果副本为空，尝试从 currentSpine 获取
    if (itemsToUse.length === 0 && currentSpine) {
      const spineItems = (currentSpine as any).items || [];
      if (spineItems.length > 0) {
        itemsToUse = spineItems;
        this.spineItems = spineItems.map((item: any) => ({ ...item })); // 更新副本
        console.log(`EpubCoreService: 从 currentSpine 获取到 ${itemsToUse.length} 个章节并更新副本`);
      }
    }
    
    // 如果仍然为空，尝试从 this.book.spine 获取
    if (itemsToUse.length === 0) {
      console.warn('EpubCoreService: 副本为空，尝试从 this.book.spine 获取');
      if (this.book && this.book.spine) {
        const bookSpine = this.book.spine;
        const bookSpineItems = (bookSpine as any).items || [];
        if (bookSpineItems.length > 0) {
          console.log(`EpubCoreService: 从 this.book.spine 获取到 ${bookSpineItems.length} 个章节`);
          currentSpine = bookSpine;
          this.spine = bookSpine;
          this.spineItems = bookSpineItems.map((item: any) => ({ ...item }));
          itemsToUse = this.spineItems;
        }
      }
    }
    
    // 如果仍然为空，尝试使用参数 spine
    if (itemsToUse.length === 0 && spine && spine !== currentSpine) {
      const paramSpineItems = (spine as any).items || [];
      if (paramSpineItems.length > 0) {
        console.log(`EpubCoreService: 使用参数 spine（items 可用，${paramSpineItems.length} 个章节）`);
        currentSpine = spine;
        this.spine = spine;
        this.spineItems = paramSpineItems.map((item: any) => ({ ...item }));
        itemsToUse = this.spineItems;
      }
    }
    
    if (!currentSpine) {
      console.error('EpubCoreService: restorePosition 中无法获取 spine');
      throw new Error('无法获取 spine');
    }
    
    // 确保 currentSpine 有 items 属性（使用保存的副本）
    if (!currentSpine.items || currentSpine.items.length === 0) {
      Object.defineProperty(currentSpine, 'items', {
        value: itemsToUse,
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
    
    console.log(`EpubCoreService: restorePosition 最终使用 spine，items.length = ${itemsToUse.length}`);
    
    if (itemsToUse.length === 0) {
      console.error('EpubCoreService: 警告！spine items 仍然为空，可能导致无法显示内容');
      throw new Error('spine items 为空，无法恢复位置');
    }

    // 获取第一页的辅助函数（完全避免使用 spine.get，因为它可能失败）
    // 优先使用保存的 spineItems 副本
    const getFirstItem = async (): Promise<any> => {
      try {
        // 优先使用保存的 spineItems 副本（不会被清空）
        let spineItems = this.spineItems.length > 0 ? this.spineItems : [];
        
        // 如果副本为空，尝试从 currentSpine 获取
        if (spineItems.length === 0 && currentSpine) {
          const targetSpineItems = (currentSpine as any).items || [];
          if (targetSpineItems.length > 0) {
            spineItems = targetSpineItems;
            this.spineItems = targetSpineItems.map((item: any) => ({ ...item })); // 更新副本
            console.log(`EpubCoreService: 从 currentSpine 获取到 ${spineItems.length} 个章节并更新副本`);
          }
        }
        
        if (spineItems.length > 0) {
          for (let i = 0; i < spineItems.length; i++) {
            const item = spineItems[i];
            if (item && item.href && typeof item.href === 'string' && item.href.trim()) {
              return item;
            }
          }
        }
        
        // 方法2: 遍历 spine（如果 items 不可用）
        let foundItem: any = null;
        try {
          if (currentSpine && typeof currentSpine.each === 'function') {
            currentSpine.each((item: any) => {
              if (!foundItem && item && item.href && typeof item.href === 'string' && item.href.trim()) {
                foundItem = item;
                return false; // 停止遍历
              }
            });
          }
        } catch (e) {
          // 遍历失败，忽略
        }
        
        if (foundItem && foundItem.href) {
          return foundItem;
        }
        
        // 注意：不再使用 spine.get()，因为它会触发 isCfiString 错误
        
        console.warn('EpubCoreService: 无法获取第一页，spineItems.length =', spineItems.length);
        return null;
      } catch (e) {
        console.error('EpubCoreService: 获取第一页失败', e);
        return null;
      }
    };

    // 根据章节索引获取 spine item（完全避免使用 spine.get）
    const getSpineItemByIndex = (index: number) => {
      try {
        // 使用 currentSpine（已经在方法开始时确定）
        const targetSpine = currentSpine;
        if (!targetSpine) {
          console.warn('EpubCoreService: getSpineItemByIndex 中无法获取 spine');
          return null;
        }
        
        // 方法1: 优先使用保存的 spineItems 副本（不会被清空）
        let spineItems = this.spineItems.length > 0 ? this.spineItems : [];
        
        // 如果副本为空，尝试从 targetSpine 获取
        if (spineItems.length === 0 && targetSpine) {
          const targetSpineItems = (targetSpine as any).items || [];
          if (targetSpineItems.length > 0) {
            spineItems = targetSpineItems;
            this.spineItems = targetSpineItems.map((item: any) => ({ ...item })); // 更新副本
          }
        }
        
        if (spineItems.length > index && spineItems[index]) {
          const item = spineItems[index];
          if (item && item.href && typeof item.href === 'string' && item.href.trim()) {
            console.log('EpubCoreService: 从 spine.items 获取章节', index, item.href);
            return item;
          }
        }
        
        // 方法2: 遍历查找（如果 items 不可用）
        let foundItem: any = null;
        try {
          if (targetSpine && typeof targetSpine.each === 'function') {
            targetSpine.each((item: any) => {
              if (item.index === index && item.href && typeof item.href === 'string' && item.href.trim()) {
                foundItem = item;
                return false;
              }
            });
          }
        } catch (e) {
          // 遍历失败，忽略
        }
        
        if (foundItem && foundItem.href) {
          console.log('EpubCoreService: 从遍历获取章节', index, foundItem.href);
          return foundItem;
        }
        
        // 注意：不再使用 spine.get()，因为它会触发 isCfiString 错误
        
        console.warn('EpubCoreService: 无法根据索引获取章节', index);
        return null;
      } catch (e) {
        console.error('EpubCoreService: 根据索引获取 spine item 失败', e);
        return null;
      }
    };

    try {
      // 优先使用 CFI（但如果之前失败过，直接使用章节索引）
      if (initialPosition?.currentLocation && initialPosition.currentLocation.startsWith('epubcfi(')) {
        console.log('EpubCoreService: 尝试使用 CFI 恢复位置');
        try {
          // 先尝试 CFI，如果超时则回退
          const cfiPromise = Promise.race([
            rendition.display(initialPosition.currentLocation),
            new Promise((_, reject) => setTimeout(() => reject(new Error('CFI display 超时')), 3000))
          ]);
          
          // 等待 CFI 完成或超时
          try {
            await cfiPromise;
            displayPromise = cfiPromise;
            restoredByCFI = true;
            console.log('EpubCoreService: CFI 恢复成功');
          } catch (cfiError) {
            // CFI 超时或失败，回退到章节索引
            console.warn('EpubCoreService: CFI 恢复失败，回退到章节索引', cfiError);
            if (initialPosition.chapterIndex !== undefined) {
              const item = getSpineItemByIndex(initialPosition.chapterIndex);
              const firstItem = await getFirstItem();
              if (item && item.href) {
                displayPromise = rendition.display(item.href);
              } else if (firstItem && firstItem.href) {
                displayPromise = rendition.display(firstItem.href);
              } else {
                throw new Error('无法获取章节');
              }
            } else {
              const firstItem = await getFirstItem();
              if (firstItem && firstItem.href) {
                displayPromise = rendition.display(firstItem.href);
              } else {
                throw new Error('无法获取第一页');
              }
            }
          }
        } catch (error) {
          console.error('EpubCoreService: CFI 恢复异常，回退到章节索引', error);
          // 如果 CFI 调用本身失败，也回退
          if (initialPosition.chapterIndex !== undefined) {
            const item = getSpineItemByIndex(initialPosition.chapterIndex);
            const firstItem = await getFirstItem();
            if (item && item.href) {
              displayPromise = rendition.display(item.href);
            } else if (firstItem && firstItem.href) {
              displayPromise = rendition.display(firstItem.href);
            } else {
              throw new Error('无法获取章节');
            }
          } else {
            const firstItem = await getFirstItem();
            if (firstItem && firstItem.href) {
              displayPromise = rendition.display(firstItem.href);
            } else {
              throw new Error('无法获取第一页');
            }
          }
        }
      } else if (initialPosition?.chapterIndex !== undefined) {
        console.log('EpubCoreService: 使用章节索引恢复位置', initialPosition.chapterIndex);
        const item = getSpineItemByIndex(initialPosition.chapterIndex);
        if (item && item.href) {
          displayPromise = rendition.display(item.href);
        } else {
          const firstItem = await getFirstItem();
          if (firstItem && firstItem.href) {
            displayPromise = rendition.display(firstItem.href);
          } else {
            throw new Error('无法获取章节');
          }
        }
      } else {
        console.log('EpubCoreService: 显示第一页');
        const firstItem = await getFirstItem();
        if (!firstItem || !firstItem.href) {
          throw new Error('书籍没有可用的章节');
        }
        displayPromise = rendition.display(firstItem.href);
      }

      // 直接 await displayPromise（就像原代码那样），带超时保护
      if (displayPromise) {
        console.log('EpubCoreService: 等待 display 完成...');
        try {
          // 使用 Promise.race 添加超时保护，但优先等待 displayPromise
          await Promise.race([
            displayPromise,
            new Promise((_, reject) => 
              setTimeout(() => reject(new Error('display 超时')), 8000)
            )
          ]);
          console.log('EpubCoreService: display 完成');
        } catch (displayError: any) {
          // display 超时或失败，但不抛出错误，继续执行
          // epubjs 的 display Promise 可能不会 resolve，但内容可能已经渲染
          console.warn('EpubCoreService: display Promise 超时或失败，但继续执行', displayError);
        }
      }
      
      // 等待内容渲染（CFI 恢复可能需要更长时间）
      // 这是关键：即使 display Promise 超时，也要等待一段时间让内容渲染
      await new Promise(resolve => setTimeout(resolve, restoredByCFI ? 800 : 500));
      
      console.log('EpubCoreService: 位置恢复完成');
    } catch (error) {
      console.error('EpubCoreService: restorePosition 出错', error);
      // 尝试显示第一页作为后备
      try {
        console.log('EpubCoreService: 尝试显示第一页作为后备');
        const firstItem = await getFirstItem();
        if (firstItem && firstItem.href) {
          await Promise.race([
            rendition.display(firstItem.href),
            new Promise((_, reject) => setTimeout(() => reject(new Error('后备 display 超时')), 10000))
          ]);
          await new Promise(resolve => setTimeout(resolve, 500));
          console.log('EpubCoreService: 后备显示完成');
        } else {
          throw new Error('无法获取第一页');
        }
      } catch (fallbackError) {
        console.error('EpubCoreService: 后备显示也失败', fallbackError);
        // 即使失败也继续，不抛出错误，让初始化完成
        // 这样至少可以显示阅读器界面，用户可以看到错误信息
        console.warn('EpubCoreService: 无法显示内容，但继续初始化');
      }
    }
  }

  /**
   * 设置位置变化监听
   */
  private setupRelocatedListener(
    rendition: any,
    bookInstance: any,
    onProgressChange: (progress: number, position: ReadingPosition) => void,
    readingStateRefs: EpubCoreServiceConfig['onReadingStateRefs']
  ) {
    const { locationsReadyRef, totalLocationsRef, lastCfiRef, isRestoringLayoutRef, lastProgressRef, lastPositionRef, totalChaptersRef } = readingStateRefs;

    const relocatedHandler = (location: any) => {
      if (isRestoringLayoutRef.current) return;

      const spineIndex = location.start?.index ?? 0;
      const cfi = location.start?.cfi;
      const chapterCurrentPage = location.start?.displayed?.page || 1;
      const chapterTotalPages = location.start?.displayed?.total || 1;

      if (typeof cfi === 'string' && cfi.startsWith('epubcfi(')) {
        lastCfiRef.current = cfi;
      }

      // 计算进度
      const totalChapters = totalChaptersRef.current;
      const withinChapter = chapterTotalPages > 1 && chapterCurrentPage >= 1
        ? Math.min(1, Math.max(0, (chapterCurrentPage - 1) / chapterTotalPages))
        : 0;

      let progress = 0;
      const percentage = location.start?.percentage;
      if (percentage !== undefined && percentage !== null && !isNaN(percentage) && percentage > 0) {
        progress = Math.min(1, Math.max(0, percentage));
      } else if (totalChapters > 0 && spineIndex >= 0) {
        const denom = totalChapters > 0 ? totalChapters : Math.max(1, spineIndex + 1);
        progress = Math.min(1, Math.max(0, (spineIndex + withinChapter) / denom));
      } else {
        progress = Math.min(1, Math.max(0, withinChapter));
      }

      if (isNaN(progress) || progress < 0 || progress > 1) {
        progress = 0;
      }

      // 使用 locations 计算稳定的页码
      let finalCurrentPage = chapterCurrentPage;
      let finalTotalPages = chapterTotalPages;
      let finalProgress = progress;

      try {
        if (
          locationsReadyRef.current &&
          bookInstance?.locations &&
          typeof bookInstance.locations.locationFromCfi === 'function' &&
          typeof bookInstance.locations.length === 'function' &&
          typeof cfi === 'string' &&
          cfi.startsWith('epubcfi(')
        ) {
          const loc = bookInstance.locations.locationFromCfi(cfi);
          const total = bookInstance.locations.length();
          if (typeof loc === 'number' && loc >= 0 && typeof total === 'number' && total > 0) {
            finalCurrentPage = loc + 1;
            finalTotalPages = total;
            finalProgress = Math.min(1, Math.max(0, (loc + 1) / total));
          }
        }
      } catch (e) {
        // 忽略，回退到章节内页码
      }

      // 获取章节标题
      let chapterTitle = '';
      try {
        const navigation = bookInstance.navigation;
        const tocItems = navigation?.toc || [];
        const tocItem = tocItems.find((item: any) => {
          try {
            // 避免使用 spine.get()，改用遍历查找
            const spineItems = (bookInstance.spine as any).items || [];
            for (let i = 0; i < spineItems.length; i++) {
              const spineItem = spineItems[i];
              if (spineItem && spineItem.href === item.href) {
                const itemIndex = spineItem.index !== undefined ? spineItem.index : i;
                return itemIndex === spineIndex;
              }
            }
            return false;
          } catch (e) {
            return false;
          }
        });
        if (tocItem) {
          chapterTitle = tocItem.label || '';
        }
      } catch (e) {
        // 获取失败
      }

      const position: ReadingPosition = {
        chapterIndex: spineIndex,
        currentPage: finalCurrentPage,
        totalPages: finalTotalPages,
        progress: finalProgress,
        currentLocation: cfi,
        chapterTitle: chapterTitle,
      };

      lastProgressRef.current = finalProgress;
      lastPositionRef.current = position;
      onProgressChange(finalProgress, position);
    };

    rendition.on('relocated', relocatedHandler);
    this.cleanupFunctions.push(() => {
      if (typeof rendition.removeListener === 'function') {
        rendition.removeListener('relocated', relocatedHandler);
      } else if (typeof rendition.off === 'function') {
        rendition.off('relocated', relocatedHandler);
      }
    });
  }

  /**
   * 设置键盘快捷键
   */
  private setupKeyboardShortcuts(rendition: any, settings: ReadingSettings) {
    const keyupHandler = (e: KeyboardEvent) => {
      if (e.key === settings.keyboardShortcuts.prev || e.key === 'ArrowLeft') {
        e.preventDefault();
        rendition.prev();
      } else if (e.key === settings.keyboardShortcuts.next || e.key === 'ArrowRight') {
        e.preventDefault();
        rendition.next();
      }
    };

    rendition.on('keyup', keyupHandler);
    this.cleanupFunctions.push(() => {
      if (typeof rendition.removeListener === 'function') {
        rendition.removeListener('keyup', keyupHandler);
      } else if (typeof rendition.off === 'function') {
        rendition.off('keyup', keyupHandler);
      }
    });
  }

  /**
   * 设置窗口大小变化处理
   */
  private setupResizeHandler(
    rendition: any,
    container: HTMLElement,
    readingStateRefs: EpubCoreServiceConfig['onReadingStateRefs']
  ) {
    const { lastCfiRef, isRestoringLayoutRef } = readingStateRefs;

    const handleResize = () => {
      if (!rendition || !container) return;

      const width = container.offsetWidth || window.innerWidth;
      const height = container.offsetHeight || window.innerHeight;

      // 安全地获取当前 CFI
      let anchorCfi = lastCfiRef.current;
      if (!anchorCfi) {
        try {
          const currentLocation = rendition.currentLocation?.();
          if (currentLocation && currentLocation.start && currentLocation.start.cfi) {
            anchorCfi = currentLocation.start.cfi;
          }
        } catch (e) {
          // 忽略 currentLocation 错误
          console.warn('EpubCoreService: 获取 currentLocation 失败', e);
        }
      }

      isRestoringLayoutRef.current = true;

      try {
        rendition.resize(width, height);
      } catch (e) {
        // 忽略 resize 错误
      }

      if (anchorCfi && typeof rendition.display === 'function') {
        setTimeout(async () => {
          try {
            await rendition.display(anchorCfi);
          } catch (e) {
            // 忽略定位失败
          } finally {
            setTimeout(() => {
              isRestoringLayoutRef.current = false;
            }, 150);
          }
        }, 50);
      } else {
        setTimeout(() => {
          isRestoringLayoutRef.current = false;
        }, 150);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }

  /**
   * 暴露全局函数
   * 注意：使用 this.rendition 和 this.book 确保始终访问最新的实例
   */
  private exposeGlobalFunctions(rendition: any, bookInstance: any) {
    // 翻页函数
    (window as any).__readerPageTurn = async (direction: 'prev' | 'next') => {
      // 使用 this.rendition 确保访问最新的实例
      const currentRendition = this.rendition || rendition;
      if (!currentRendition) {
        console.warn('EpubCoreService: rendition 不存在，无法翻页');
        return;
      }
      
      // 检查 rendition.manager 是否存在
      if (!currentRendition.manager) {
        console.warn('EpubCoreService: rendition.manager 不存在，无法翻页');
        return;
      }
      
      try {
        if (direction === 'prev') {
          if (typeof currentRendition.prev === 'function') {
            await currentRendition.prev();
          } else {
            console.warn('EpubCoreService: rendition.prev 不是函数');
          }
        } else {
          if (typeof currentRendition.next === 'function') {
            await currentRendition.next();
          } else {
            console.warn('EpubCoreService: rendition.next 不是函数');
          }
        }
      } catch (error: any) {
        console.error('EpubCoreService: 翻页失败', error);
        // 如果翻页失败，尝试使用 display 方法
        try {
          const currentLocation = currentRendition.currentLocation?.();
          if (currentLocation && currentLocation.start) {
            const cfi = currentLocation.start.cfi;
            if (direction === 'prev' && currentRendition.location) {
              const prevCFI = currentRendition.location.prev(cfi);
              if (prevCFI) {
                await currentRendition.display(prevCFI);
              }
            } else if (direction === 'next' && currentRendition.location) {
              const nextCFI = currentRendition.location.next(cfi);
              if (nextCFI) {
                await currentRendition.display(nextCFI);
              }
            }
          }
        } catch (fallbackError) {
          console.error('EpubCoreService: 备用翻页方法也失败', fallbackError);
        }
      }
    };

    // 跳转函数
    (window as any).__readerGoToPosition = async (pos: any) => {
      const currentRendition = this.rendition || rendition;
      const currentBook = this.book || bookInstance;
      
      try {
        const cfi = pos?.currentLocation || pos?.currentPosition;
        if (typeof cfi === 'string' && cfi.startsWith('epubcfi(') && typeof currentRendition?.display === 'function') {
          await currentRendition.display(cfi);
          return true;
        }
        const chapterIndex = pos?.chapterIndex;
        if (typeof chapterIndex === 'number' && !isNaN(chapterIndex) && currentBook?.spine) {
          // 使用安全的方法获取章节，避免使用 spine.get()
          try {
            const spineItems = (currentBook.spine as any).items || this.spineItems || [];
            if (chapterIndex >= 0 && chapterIndex < spineItems.length) {
              const item = spineItems[chapterIndex];
              if (item?.href && currentRendition?.display) {
                await currentRendition.display(item.href);
                return true;
              }
            }
          } catch (e) {
            // 如果直接访问失败，尝试使用 spine.get()（作为后备）
            try {
              const item = currentBook.spine?.get?.(chapterIndex);
              if (item?.href && currentRendition?.display) {
                await currentRendition.display(item.href);
                return true;
              }
            } catch (e2) {
              // 忽略错误
            }
          }
        }
      } catch {
        // ignore
      }
      return false;
    };

    // TOC 跳转
    (window as any).__epubGoToChapter = async (href: string) => {
      const currentRendition = this.rendition || rendition;
      if (currentRendition) {
        try {
          await currentRendition.display(href);
        } catch (error) {
          console.error('EpubCoreService: 跳转失败', error);
        }
      }
    };

    // 高亮函数
    (window as any).__epubHighlight = (cfiRange: string) => {
      const currentRendition = this.rendition || rendition;
      try {
        if (!cfiRange || typeof cfiRange !== 'string') return;
        if (!currentRendition?.annotations?.highlight) return;
        currentRendition.annotations.highlight(
          cfiRange,
          {},
          () => {},
          'rk-note-highlight',
          {
            fill: 'rgba(255, 235, 59, 0.55)',
            'mix-blend-mode': 'multiply',
          }
        );
      } catch (e) {
        // ignore
      }
    };

    // 取消高亮函数
    (window as any).__epubUnhighlight = (cfiRange: string) => {
      const currentRendition = this.rendition || rendition;
      try {
        if (!cfiRange || typeof cfiRange !== 'string') return;
        const anyR: any = currentRendition;
        if (!anyR?.annotations) return;
        if (typeof anyR.annotations.remove === 'function') {
          try {
            anyR.annotations.remove(cfiRange, 'highlight');
            return;
          } catch (e) {
            // ignore
          }
          try {
            anyR.annotations.remove(cfiRange);
          } catch (e) {
            // ignore
          }
        }
      } catch (e) {
        // ignore
      }
    };
  }

  /**
   * 清理资源
   */
  cleanup() {
    // 执行所有清理函数
    this.cleanupFunctions.forEach(fn => {
      try {
        fn();
      } catch (e) {
        // 忽略清理错误
      }
    });
    this.cleanupFunctions = [];

    // 清理 rendition
    if (this.rendition) {
      try {
        if (typeof this.rendition.destroy === 'function') {
          this.rendition.destroy();
        }
      } catch (e) {
        // 忽略错误
      }
      this.rendition = null;
    }

    // 清理 book
    if (this.book) {
      try {
        if (typeof this.book.destroy === 'function') {
          this.book.destroy();
        }
      } catch (e) {
        // 忽略错误
      }
      this.book = null;
    }

    // 清理全局函数
    delete (window as any).__readerPageTurn;
    delete (window as any).__readerGoToPosition;
    delete (window as any).__epubGoToChapter;
    delete (window as any).__epubHighlight;
    delete (window as any).__epubUnhighlight;
  }

  /**
   * 更新主题
   */
  updateTheme(rendition: any, settings: ReadingSettings) {
    if (!rendition) return;

    const theme = buildEpubTheme(settings);
    try {
      rendition.themes.default(theme);

      // 对已经渲染的内容也应用样式
      rendition.views().forEach((view: any) => {
        if (view && view.document) {
          const doc = view.document;
          if (!doc || typeof doc.createElement !== 'function' || !doc.body) return;

          const themeStyles = getThemeStyles(settings.theme);
          applyThemeToDocument(doc, settings, themeStyles);
        }
      });
    } catch (error) {
      console.error('EpubCoreService: 更新主题失败', error);
    }
  }
}

