/**
 * EPUB.js 阅读器初始化 Hook
 */

import { useCallback, useRef } from 'react';
import { BookData, ReadingSettings, ReadingPosition, TOCItem } from '../../../../types/reader';
import { EpubCoreService, EpubCoreServiceConfig } from '../services/EpubCoreService';
import { useReadingState } from './useReadingState';

export interface UseEpubjsReaderResult {
  initialize: (fileUrl: string) => Promise<void>;
  updateTheme: (settings: ReadingSettings) => void;
  cleanup: () => void;
  book: any;
  rendition: any;
}

export function useEpubjsReader(
  containerRef: React.RefObject<HTMLDivElement>,
  book: BookData,
  settings: ReadingSettings,
  settingsRef: React.MutableRefObject<ReadingSettings>,
  initialPosition: ReadingPosition | undefined,
  onProgressChange: (progress: number, position: ReadingPosition) => void,
  onTOCChange: (toc: TOCItem[]) => void
): UseEpubjsReaderResult {
  const serviceRef = useRef<EpubCoreService | null>(null);
  const bookRef = useRef<any>(null);
  const renditionRef = useRef<any>(null);
  const isInitializingRef = useRef(false);
  const isInitializedRef = useRef(false);
  const readingState = useReadingState();

  const initialize = useCallback(async (fileUrl: string) => {
    if (isInitializingRef.current) return;
    if (!containerRef.current) {
      throw new Error('阅读器容器未准备好');
    }

    isInitializingRef.current = true;

    try {
      // 清理之前的实例
      if (serviceRef.current) {
        serviceRef.current.cleanup();
        serviceRef.current = null;
      }

      const service = new EpubCoreService();
      serviceRef.current = service;

      const config: EpubCoreServiceConfig = {
        container: containerRef.current,
        fileUrl,
        settings,
        initialPosition,
        onProgressChange,
        onTOCChange,
        onSettingsRef: settingsRef,
        onReadingStateRefs: readingState.refs,
      };

      const result = await service.initialize(config);
      bookRef.current = result.book;
      renditionRef.current = result.rendition;
      isInitializedRef.current = true;
    } catch (error: any) {
      console.error('useEpubjsReader: 初始化失败', error);
      throw error;
    } finally {
      isInitializingRef.current = false;
    }
  }, [containerRef, book, settings, settingsRef, initialPosition, onProgressChange, onTOCChange, readingState.refs]);

  const updateTheme = useCallback((newSettings: ReadingSettings) => {
    if (!serviceRef.current || !renditionRef.current) return;
    serviceRef.current.updateTheme(renditionRef.current, newSettings);
  }, []);

  const cleanup = useCallback(() => {
    if (serviceRef.current) {
      serviceRef.current.cleanup();
      serviceRef.current = null;
    }
    bookRef.current = null;
    renditionRef.current = null;
    isInitializedRef.current = false;
  }, []);

  return {
    initialize,
    updateTheme,
    cleanup,
    book: bookRef.current,
    rendition: renditionRef.current,
  };
}

