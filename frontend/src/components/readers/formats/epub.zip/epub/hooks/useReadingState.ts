/**
 * 阅读状态管理 Hook
 */

import { useRef, useCallback } from 'react';
import { ReadingPosition, ReadingSettings } from '../../../../types/reader';

export interface ReadingStateRefs {
  locationsReady: boolean;
  totalLocations: number;
  lastCfi: string | null;
  isRestoringLayout: boolean;
  lastProgress: number;
  lastPosition: ReadingPosition | null;
  totalChapters: number;
}

/**
 * 管理阅读状态的 Hook
 */
export function useReadingState() {
  const locationsReadyRef = useRef(false);
  const totalLocationsRef = useRef<number>(0);
  const lastCfiRef = useRef<string | null>(null);
  const isRestoringLayoutRef = useRef(false);
  const lastProgressRef = useRef<number>(0);
  const lastPositionRef = useRef<ReadingPosition | null>(null);
  const totalChaptersRef = useRef<number>(1);

  const getState = useCallback((): ReadingStateRefs => ({
    locationsReady: locationsReadyRef.current,
    totalLocations: totalLocationsRef.current,
    lastCfi: lastCfiRef.current,
    isRestoringLayout: isRestoringLayoutRef.current,
    lastProgress: lastProgressRef.current,
    lastPosition: lastPositionRef.current,
    totalChapters: totalChaptersRef.current,
  }), []);

  const setLocationsReady = useCallback((ready: boolean) => {
    locationsReadyRef.current = ready;
  }, []);

  const setTotalLocations = useCallback((total: number) => {
    totalLocationsRef.current = total;
  }, []);

  const setLastCfi = useCallback((cfi: string | null) => {
    lastCfiRef.current = cfi;
  }, []);

  const setIsRestoringLayout = useCallback((restoring: boolean) => {
    isRestoringLayoutRef.current = restoring;
  }, []);

  const setLastProgress = useCallback((progress: number) => {
    lastProgressRef.current = progress;
  }, []);

  const setLastPosition = useCallback((position: ReadingPosition | null) => {
    lastPositionRef.current = position;
  }, []);

  const setTotalChapters = useCallback((total: number) => {
    totalChaptersRef.current = total;
  }, []);

  return {
    refs: {
      locationsReadyRef,
      totalLocationsRef,
      lastCfiRef,
      isRestoringLayoutRef,
      lastProgressRef,
      lastPositionRef,
      totalChaptersRef,
    },
    getState,
    setLocationsReady,
    setTotalLocations,
    setLastCfi,
    setIsRestoringLayout,
    setLastProgress,
    setLastPosition,
    setTotalChapters,
  };
}

