/**
 * 手势处理工具函数
 */

export interface TouchState {
  x: number;
  y: number;
  time: number;
  clientX: number;
  clientY: number;
}

export interface TouchMoveState {
  maxMoveX: number;
  maxMoveY: number;
  lastX: number;
  lastY: number;
}

export interface SwipeDirection {
  direction: 'prev' | 'next' | null;
  isValid: boolean;
}

/**
 * 检测滑动方向
 */
export function detectSwipeDirection(
  touchStart: TouchState | null,
  touchMove: TouchMoveState,
  pageTurnMode: 'horizontal' | 'vertical'
): SwipeDirection {
  if (!touchStart) {
    return { direction: null, isValid: false };
  }

  const moveX = touchMove.maxMoveX;
  const moveY = touchMove.maxMoveY;
  const deltaX = touchMove.lastX - touchStart.clientX;
  const deltaY = touchMove.lastY - touchStart.clientY;

  const PRIMARY_THRESHOLD = 70; // 主方向最小滑动距离
  const DIRECTION_RATIO = 1.3;  // 主方向需要明显大于副方向
  const DIRECTION_MIN = 40;     // 方向判定最小 delta

  if (pageTurnMode === 'horizontal') {
    if (moveX > PRIMARY_THRESHOLD && moveX > moveY * DIRECTION_RATIO) {
      // 修正方向：右→左 下一页；左→右 上一页
      if (deltaX > DIRECTION_MIN) return { direction: 'prev', isValid: true };
      if (deltaX < -DIRECTION_MIN) return { direction: 'next', isValid: true };
    }
  } else {
    if (moveY > PRIMARY_THRESHOLD && moveY > moveX * DIRECTION_RATIO) {
      if (deltaY < -DIRECTION_MIN) return { direction: 'next', isValid: true };
      if (deltaY > DIRECTION_MIN) return { direction: 'prev', isValid: true };
    }
  }

  return { direction: null, isValid: false };
}

/**
 * 检测是否为有效点击（非滑动）
 */
export function isValidClick(
  touchStart: TouchState | null,
  touchMove: TouchMoveState,
  touchEndTime: number
): boolean {
  if (!touchStart) return false;

  const touchDuration = touchEndTime - touchStart.time;
  const moveDistance = Math.sqrt(
    Math.pow(touchMove.lastX - touchStart.clientX, 2) +
    Math.pow(touchMove.lastY - touchStart.clientY, 2)
  );

  // 判断是滑动还是点击
  const isSwipe = moveDistance > 50;

  // 检测误触条件：
  // 1. 触摸时间太短（< 80ms）- 可能是误触
  // 2. 触摸时间太长（> 800ms）- 可能是长按或选择文字
  // 3. 移动距离太大（> 15px）- 是移动而不是点击
  if (isSwipe) return false;
  if (touchDuration < 80) return false;
  if (touchDuration > 800) return false;
  if (moveDistance > 15) return false;

  return true;
}

/**
 * 检测是否在中心区域
 */
export function isInCenterArea(
  x: number,
  y: number,
  width: number,
  height: number,
  centerRatio: number = 0.3
): boolean {
  const centerXStart = width * centerRatio;
  const centerXEnd = width * (1 - centerRatio);
  const centerYStart = height * centerRatio;
  const centerYEnd = height * (1 - centerRatio);

  return x >= centerXStart && x <= centerXEnd &&
         y >= centerYStart && y <= centerYEnd;
}

/**
 * 计算点击翻页方向
 */
export function getClickDirection(
  x: number,
  y: number,
  width: number,
  height: number,
  pageTurnMode: 'horizontal' | 'vertical'
): 'prev' | 'next' {
  if (pageTurnMode === 'horizontal') {
    return x < width / 2 ? 'prev' : 'next';
  } else {
    return y < height / 2 ? 'prev' : 'next';
  }
}

