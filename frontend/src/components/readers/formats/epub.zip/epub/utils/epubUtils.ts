/**
 * EPUB 相关工具函数
 */

import { ReadingSettings } from '../../../../types/reader';

/**
 * 获取主题样式配置
 */
export function getThemeStyles(theme: ReadingSettings['theme']) {
  return {
    light: { bg: '#ffffff', text: '#000000' },
    dark: { bg: '#1a1a1a', text: '#ffffff' },
    sepia: { bg: '#f4e4bc', text: '#5c4b37' },
    green: { bg: '#c8e6c9', text: '#2e7d32' },
  }[theme];
}

/**
 * 获取字体族配置
 */
export function getFontFamily(fontFamily: ReadingSettings['fontFamily']): string {
  switch (fontFamily) {
    case 'serif':
      return '"Songti SC", "SimSun", "宋体", "STSong", serif';
    case 'sans-serif':
      return '-apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", "WenQuanYi Micro Hei", sans-serif';
    case 'monospace':
      return '"SF Mono", Monaco, "Cascadia Code", "Roboto Mono", Consolas, "Courier New", monospace';
    case 'default':
    default:
      return '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
  }
}

/**
 * 构建 EPUB.js 主题配置
 */
export function buildEpubTheme(settings: ReadingSettings) {
  const themeStyles = getThemeStyles(settings.theme);
  const fontFamily = getFontFamily(settings.fontFamily);

  return {
    body: {
      'font-size': `${settings.fontSize}px !important`,
      'line-height': `${settings.lineHeight} !important`,
      'font-family': fontFamily + ' !important',
      'padding': `${settings.margin}px !important`,
      'text-indent': `${settings.textIndent}em !important`,
      'background-color': themeStyles.bg + ' !important',
      'color': themeStyles.text + ' !important',
      'margin': '0 !important',
      'box-sizing': 'border-box !important',
    },
    'p': {
      'text-indent': `${settings.textIndent}em !important`,
      'margin-bottom': '0.8em !important',
      'color': themeStyles.text + ' !important',
    },
    'div': {
      'color': themeStyles.text + ' !important',
    },
    'span': {
      'color': themeStyles.text + ' !important',
    },
    'h1, h2, h3, h4, h5, h6': {
      'color': themeStyles.text + ' !important',
    },
    'li': {
      'color': themeStyles.text + ' !important',
    },
    'td, th': {
      'color': themeStyles.text + ' !important',
    },
    'a': {
      'color': themeStyles.text + ' !important',
    },
  };
}

/**
 * 应用主题到文档元素
 */
export function applyThemeToDocument(
  doc: Document,
  settings: ReadingSettings,
  themeStyles: ReturnType<typeof getThemeStyles>
) {
  if (!doc.body) return;

  // 应用基础样式
  doc.body.style.setProperty('background-color', themeStyles.bg, 'important');
  doc.body.style.setProperty('color', themeStyles.text, 'important');
  doc.body.style.setProperty('font-size', `${settings.fontSize}px`, 'important');
  doc.body.style.setProperty('line-height', `${settings.lineHeight}`, 'important');
  doc.body.style.setProperty('padding', `${settings.margin}px`, 'important');

  // 应用字体
  const fontFamily = getFontFamily(settings.fontFamily);
  doc.body.style.setProperty('font-family', fontFamily, 'important');

  // 应用文本缩进到段落
  const paragraphs = doc.querySelectorAll('p');
  paragraphs.forEach((p: HTMLElement) => {
    p.style.setProperty('text-indent', `${settings.textIndent}em`, 'important');
    p.style.setProperty('color', themeStyles.text, 'important');
  });

  // 强制应用颜色到所有文本元素
  const textElements = doc.querySelectorAll('p, div, span, h1, h2, h3, h4, h5, h6, li, td, th, a, em, strong, b, i, u, blockquote, pre, code');
  const iframeWindow = doc.defaultView || (doc as any).parentWindow;

  textElements.forEach((el: any) => {
    if (!el || typeof el.getElementsByTagName !== 'function' || !el.style) return;

    let currentColor = '';
    try {
      if (iframeWindow) {
        const computedStyle = iframeWindow.getComputedStyle(el);
        currentColor = computedStyle.color;
      }
    } catch (e) {
      // 无法获取计算样式
    }

    // 如果当前颜色与主题不匹配，强制应用主题色
    if (settings.theme === 'light' && (
      currentColor === 'rgb(255, 255, 255)' ||
      currentColor === '#ffffff' ||
      currentColor === 'white' ||
      currentColor.includes('rgb(255, 255, 255)')
    )) {
      el.style.setProperty('color', themeStyles.text, 'important');
    } else if (settings.theme === 'dark' && (
      currentColor === 'rgb(0, 0, 0)' ||
      currentColor === '#000000' ||
      currentColor === 'black' ||
      currentColor.includes('rgb(0, 0, 0)')
    )) {
      el.style.setProperty('color', themeStyles.text, 'important');
    } else if (
      currentColor === themeStyles.bg ||
      (settings.theme === 'dark' && (currentColor === 'rgb(26, 26, 26)' || currentColor.includes('rgb(26, 26, 26)'))) ||
      (settings.theme === 'light' && (currentColor === 'rgb(255, 255, 255)' || currentColor.includes('rgb(255, 255, 255)'))) ||
      !currentColor
    ) {
      el.style.setProperty('color', themeStyles.text, 'important');
    }
  });
}

/**
 * 移除无效字体引用
 */
export function removeInvalidFonts(doc: Document) {
  try {
    // 移除 <link> 标签中的无效字体引用
    const linkTags = doc.querySelectorAll('link[rel="stylesheet"], link[type="text/css"]');
    linkTags.forEach((link: any) => {
      const href = link.getAttribute('href') || link.href;
      if (href && (
        href.includes('res://') ||
        href.includes('file://') ||
        href.includes('res:///') ||
        href.includes('tt0011m') ||
        (href.includes('.ttf') && href.includes('res://'))
      )) {
        try {
          link.remove();
        } catch (e) {
          // 忽略移除错误
        }
      }
    });

    // 移除样式表中的无效字体引用
    const styleSheets = doc.styleSheets;
    for (let i = 0; i < styleSheets.length; i++) {
      try {
        const sheet = styleSheets[i];
        if (!sheet.cssRules) continue;

        for (let j = sheet.cssRules.length - 1; j >= 0; j--) {
          try {
            const rule = sheet.cssRules[j];
            if (rule.type === CSSRule.FONT_FACE_RULE) {
              const fontFaceRule = rule as CSSFontFaceRule;
              const src = fontFaceRule.style.getPropertyValue('src');
              if (src && (
                src.includes('res://') ||
                src.includes('file://') ||
                src.includes('res:///') ||
                src.includes('tt0011m')
              )) {
                sheet.deleteRule(j);
              }
            }
          } catch (e) {
            // 忽略无法访问的规则
          }
        }
      } catch (e) {
        // 忽略无法访问的样式表
      }
    }

    // 移除 <style> 标签中的无效字体引用
    const styleTags = doc.querySelectorAll('style');
    styleTags.forEach((styleTag: HTMLStyleElement) => {
      if (styleTag.textContent) {
        let cleanedCSS = styleTag.textContent;
        cleanedCSS = cleanedCSS.replace(/@font-face\s*\{[^}]*src\s*:[^}]*res:\/\/[^}]*\}/gi, '/* 已移除无效字体引用 */');
        cleanedCSS = cleanedCSS.replace(/@font-face\s*\{[^}]*src\s*:[^}]*tt0011m[^}]*\}/gi, '/* 已移除无效字体引用 */');
        cleanedCSS = cleanedCSS.replace(/url\([^)]*res:\/\/[^)]*\)/gi, '');
        cleanedCSS = cleanedCSS.replace(/url\([^)]*tt0011m[^)]*\)/gi, '');

        if (cleanedCSS !== styleTag.textContent) {
          styleTag.textContent = cleanedCSS;
        }
      }
    });
  } catch (e) {
    // 清理失败
  }
}

/**
 * 拦截 iframe 内的字体加载
 */
export function interceptFontLoading(iframeWindow: Window) {
  try {
    // 拦截 fetch 请求
    const originalFetch = iframeWindow.fetch;
    if (originalFetch) {
      iframeWindow.fetch = function (...args: any[]) {
        const url = args[0];
        if (typeof url === 'string' && (
          url.includes('res://') ||
          url.includes('tt0011m') ||
          (url.includes('.ttf') && url.includes('res://')) ||
          url.startsWith('res://')
        )) {
          return Promise.reject(new Error('Blocked invalid font'));
        }
        return originalFetch.apply(this, args);
      };
    }

    // 拦截 XMLHttpRequest
    const originalXHROpen = iframeWindow.XMLHttpRequest?.prototype?.open;
    if (originalXHROpen) {
      iframeWindow.XMLHttpRequest.prototype.open = function (method: string, url: string, ...args: any[]) {
        if (typeof url === 'string' && (
          url.includes('res://') ||
          url.includes('tt0011m') ||
          (url.includes('.ttf') && url.includes('res://')) ||
          url.startsWith('res://')
        )) {
          return;
        }
        return originalXHROpen.apply(this, [method, url, ...args]);
      };
    }

    // 拦截 CSS 字体加载
    try {
      const originalInsertRule = CSSStyleSheet.prototype.insertRule;
      CSSStyleSheet.prototype.insertRule = function (rule: string, index?: number) {
        if (rule.includes('@font-face') && (
          rule.includes('res://') ||
          rule.includes('tt0011m') ||
          rule.includes('res:///')
        )) {
          return -1;
        }
        return originalInsertRule.call(this, rule, index);
      };
    } catch (e) {
      // 忽略拦截失败
    }
  } catch (e) {
    // 拦截失败
  }
}

