/**
 * 加载遮罩组件
 */

import React from 'react';
// @ts-ignore
import { ReadingSettings } from '../../../../types/reader';
import { getThemeStyles } from '../utils/epubUtils';

interface LoadingOverlayProps {
  loading: boolean;
  theme: ReadingSettings['theme'];
}

export default function LoadingOverlay({ loading, theme }: LoadingOverlayProps) {
  if (!loading) return null;

  const themeStyles = getThemeStyles(theme);

  return (
    <div
      className="absolute inset-0 flex items-center justify-center z-50"
      style={{ backgroundColor: themeStyles.bg }}
    >
      <div className="text-center">
        <div
          className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4"
          style={{ borderColor: themeStyles.text }}
        />
        <p style={{ color: themeStyles.text }}>加载中...</p>
      </div>
    </div>
  );
}

