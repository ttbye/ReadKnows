/**
 * 触摸覆盖层组件
 * 处理点击和滑动翻页、长按显示导航栏
 */

import React, { useCallback, useRef } from 'react';
import { ReadingSettings } from '../../../../types/reader';
import { detectSwipeDirection, isValidClick, isInCenterArea, getClickDirection } from '../utils/gestureUtils';
import type { TouchState, TouchMoveState } from '../utils/gestureUtils';

interface TouchOverlayProps {
  loading: boolean;
  settings: ReadingSettings;
  isMobile: boolean;
  onPageTurn: (direction: 'prev' | 'next') => void;
  onShowBars: () => void;
}

export default function TouchOverlay({
  loading,
  settings,
  isMobile,
  onPageTurn,
  onShowBars,
}: TouchOverlayProps) {
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const longPressThreshold = 500; // 500ms长按阈值
  const mouseDownRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const touchStartRef = useRef<TouchState | null>(null);
  const touchMoveRef = useRef<TouchMoveState>({ maxMoveX: 0, maxMoveY: 0, lastX: 0, lastY: 0 });
  const pageTurnStateRef = useRef<{
    lastPageTurnTime: number;
    isTurningPage: boolean;
  }>({
    lastPageTurnTime: 0,
    isTurningPage: false,
  });

  // 清理长按定时器
  const clearLongPressTimer = useCallback(() => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  }, []);

  // 处理触摸开始
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (loading) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const touch = e.touches[0];
    if (!touch) return;

    const x = touch.clientX - rect.left;
    const y = touch.clientY - rect.top;
    const width = rect.width;
    const height = rect.height;

    // 检查是否在中心区域
    const isInCenter = isInCenterArea(x, y, width, height);

    // 记录触摸开始
    touchStartRef.current = {
      x: x,
      y: y,
      clientX: touch.clientX,
      clientY: touch.clientY,
      time: Date.now(),
    };

    // 重置移动记录
    touchMoveRef.current = {
      maxMoveX: 0,
      maxMoveY: 0,
      lastX: touch.clientX,
      lastY: touch.clientY,
    };

    // 移动端：在中心区域长按显示导航栏
    if (isMobile && isInCenter) {
      longPressTimerRef.current = setTimeout(() => {
        onShowBars();
        if (navigator.vibrate) {
          navigator.vibrate(50);
        }
      }, longPressThreshold);
    }
  }, [loading, isMobile, onShowBars]);

  // 处理触摸移动
  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!touchStartRef.current) {
      clearLongPressTimer();
      return;
    }

    const touch = e.touches[0];
    if (!touch) return;

    const moveX = Math.abs(touch.clientX - touchStartRef.current.clientX);
    const moveY = Math.abs(touch.clientY - touchStartRef.current.clientY);
    const totalDistance = Math.sqrt(moveX * moveX + moveY * moveY);

    // 如果移动距离超过阈值，取消长按检测
    if (totalDistance > 10) {
      clearLongPressTimer();
    }

    // 更新最大移动距离
    touchMoveRef.current.maxMoveX = Math.max(touchMoveRef.current.maxMoveX, moveX);
    touchMoveRef.current.maxMoveY = Math.max(touchMoveRef.current.maxMoveY, moveY);
    touchMoveRef.current.lastX = touch.clientX;
    touchMoveRef.current.lastY = touch.clientY;

    // 滑动翻页：阻止默认行为
    if (settings.pageTurnMethod === 'swipe') {
      if (settings.pageTurnMode === 'horizontal') {
        if (moveX > 10 && moveX > moveY * 1.2) e.preventDefault();
      } else {
        if (moveY > 10 && moveY > moveX * 1.2) e.preventDefault();
      }
    }
  }, [settings.pageTurnMethod, settings.pageTurnMode, clearLongPressTimer]);

  // 处理触摸结束
  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    clearLongPressTimer();

    if (loading) return;

    if (settings.pageTurnMethod === 'swipe') {
      const swipe = detectSwipeDirection(touchStartRef.current, touchMoveRef.current, settings.pageTurnMode);
      touchStartRef.current = null;
      if (swipe.isValid && swipe.direction) {
        const now = Date.now();
        const debounceTime = 300;
        if (now - pageTurnStateRef.current.lastPageTurnTime < debounceTime) return;
        if (pageTurnStateRef.current.isTurningPage) return;
        pageTurnStateRef.current.isTurningPage = true;
        pageTurnStateRef.current.lastPageTurnTime = now;
        onPageTurn(swipe.direction);
        setTimeout(() => {
          pageTurnStateRef.current.isTurningPage = false;
        }, debounceTime);
      }
    } else if (settings.pageTurnMethod === 'click' && settings.clickToTurn) {
      // 点击翻页模式
      if (touchStartRef.current && isValidClick(touchStartRef.current, touchMoveRef.current, Date.now())) {
        const rect = e.currentTarget.getBoundingClientRect();
        const touch = e.changedTouches[0];
        if (touch) {
          const x = touch.clientX - rect.left;
          const y = touch.clientY - rect.top;
          const direction = getClickDirection(x, y, rect.width, rect.height, settings.pageTurnMode);
          const now = Date.now();
          const debounceTime = 300;
          if (now - pageTurnStateRef.current.lastPageTurnTime < debounceTime) return;
          if (pageTurnStateRef.current.isTurningPage) return;
          pageTurnStateRef.current.isTurningPage = true;
          pageTurnStateRef.current.lastPageTurnTime = now;
          onPageTurn(direction);
          setTimeout(() => {
            pageTurnStateRef.current.isTurningPage = false;
          }, debounceTime);
        }
      }
    }

    touchStartRef.current = null;
  }, [loading, settings, onPageTurn, clearLongPressTimer]);

  // PC端鼠标按下
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('input')) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const width = rect.width;
    const height = rect.height;

    const isInCenter = isInCenterArea(x, y, width, height);

    mouseDownRef.current = { x, y, time: Date.now() };

    // PC端：在中心区域长按显示导航栏
    if (!isMobile && isInCenter) {
      longPressTimerRef.current = setTimeout(() => {
        onShowBars();
      }, longPressThreshold);
    }
  }, [isMobile, onShowBars]);

  // PC端鼠标移动
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (mouseDownRef.current && longPressTimerRef.current) {
      const rect = e.currentTarget.getBoundingClientRect();
      const currentX = e.clientX - rect.left;
      const currentY = e.clientY - rect.top;
      const deltaX = Math.abs(currentX - mouseDownRef.current.x);
      const deltaY = Math.abs(currentY - mouseDownRef.current.y);

      if (deltaX > 10 || deltaY > 10) {
        clearLongPressTimer();
      }
    }
  }, [clearLongPressTimer]);

  // PC端鼠标抬起
  const handleMouseUp = useCallback(() => {
    clearLongPressTimer();
    mouseDownRef.current = null;
  }, [clearLongPressTimer]);

  // 处理点击事件
  const handleClick = useCallback((e: React.MouseEvent) => {
    if (loading || settings.pageTurnMethod !== 'click' || !settings.clickToTurn) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const direction = getClickDirection(x, y, rect.width, rect.height, settings.pageTurnMode);
    const now = Date.now();
    const debounceTime = 300;
    if (now - pageTurnStateRef.current.lastPageTurnTime < debounceTime) return;
    if (pageTurnStateRef.current.isTurningPage) return;
    pageTurnStateRef.current.isTurningPage = true;
    pageTurnStateRef.current.lastPageTurnTime = now;
    onPageTurn(direction);
    setTimeout(() => {
      pageTurnStateRef.current.isTurningPage = false;
    }, debounceTime);
  }, [loading, settings, onPageTurn]);

  if (loading) return null;

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onClick={handleClick}
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 10,
        pointerEvents: 'none',
        touchAction: 'manipulation',
        cursor: 'pointer',
        backgroundColor: 'transparent',
      }}
      aria-label="点击或滑动翻页"
    />
  );
}

