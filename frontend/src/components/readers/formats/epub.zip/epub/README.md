# EPUB 阅读器重构说明

## 概述

`ReaderEPUBPro` 组件已从原来的 2800+ 行单文件重构为模块化架构，提高了代码的可维护性、可测试性和可扩展性。

## 目录结构

```
epub/
├── index.tsx                    # 主组件（精简版，约 400 行）
├── hooks/                       # 自定义 hooks
│   ├── useEpubjsReader.ts       # EPUB.js 阅读器初始化
│   └── useReadingState.ts      # 阅读状态管理
├── services/                    # 服务层
│   └── EpubCoreService.ts      # EPUB 核心服务（管理 EPUB.js 逻辑）
├── utils/                       # 工具函数
│   ├── epubUtils.ts            # EPUB 相关工具（主题、字体等）
│   ├── gestureUtils.ts         # 手势处理工具
│   └── textSelection.ts        # 文本选择工具
└── components/                  # 子组件
    ├── LoadingOverlay.tsx      # 加载遮罩
    └── TouchOverlay.tsx        # 触摸覆盖层（处理翻页手势）
```

## 主要改进

### 1. 职责分离

- **主组件** (`index.tsx`): 只负责组件组合和状态管理
- **Hooks**: 封装可复用的状态逻辑
- **Services**: 管理 EPUB.js 的核心业务逻辑
- **Utils**: 提供纯函数工具
- **Components**: 独立的 UI 组件

### 2. 代码复用

- 主题应用逻辑提取到 `epubUtils.ts`
- 手势检测逻辑提取到 `gestureUtils.ts`
- 文本选择逻辑提取到 `textSelection.ts`

### 3. 内存泄漏防护

- 所有事件监听器都有对应的清理函数
- 使用 `cleanup` 函数统一管理资源释放
- 在 `EpubCoreService` 中集中管理清理逻辑

### 4. 可测试性

- 纯函数工具易于单元测试
- 服务类可以独立测试
- Hooks 可以单独测试

## 使用方式

重构后的组件保持与原组件相同的 API，无需修改调用代码：

```tsx
<ReaderEPUBPro
  book={book}
  settings={settings}
  initialPosition={position}
  onSettingsChange={handleSettingsChange}
  onProgressChange={handleProgressChange}
  onTOCChange={handleTOCChange}
  onClose={handleClose}
/>
```

## 后续优化建议

1. **进一步拆分事件处理**: 可以将 iframe 内的事件处理逻辑提取到独立的 hook 中
2. **添加单元测试**: 为工具函数和服务类添加测试
3. **性能优化**: 使用 `useMemo` 和 `useCallback` 进一步优化性能
4. **类型安全**: 为 EPUB.js 的类型添加更完整的类型定义

## 迁移说明

原有的 `ReaderEPUBPro.tsx` 文件已更新为导出新版本：

```tsx
// ReaderEPUBPro.tsx
export { default } from './epub';
```

这样可以保持向后兼容，同时使用新的模块化实现。

