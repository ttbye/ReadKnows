/**
 * @author ttbye
 * 专业级 EPUB 电子书阅读器（重构版）
 * 
 * 重构说明：
 * - 将原来的 2800+ 行代码拆分成多个模块
 * - 使用自定义 hooks 管理状态和逻辑
 * - 使用服务类管理 EPUB.js 核心功能
 * - 使用工具函数处理通用逻辑
 * - 使用子组件处理 UI 渲染
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import type { BookData, ReadingSettings, ReadingPosition, TOCItem } from '../../../../types/reader';
import toast from 'react-hot-toast';
import { useEpubjsReader } from './hooks/useEpubjsReader';
import { useReadingState } from './hooks/useReadingState';
import LoadingOverlay from './components/LoadingOverlay';

import TouchOverlay from './components/TouchOverlay';
import { getThemeStyles } from './utils/epubUtils';

interface ReaderEPUBProProps {
  book: BookData;
  settings: ReadingSettings;
  initialPosition?: ReadingPosition;
  onSettingsChange: (settings: ReadingSettings) => void;
  onProgressChange: (progress: number, position: ReadingPosition) => void;
  onTOCChange: (toc: TOCItem[]) => void;
  onClose: () => void;
}

export default function ReaderEPUBPro({
  book,
  settings,
  initialPosition,
  onSettingsChange,
  onProgressChange,
  onTOCChange,
  onClose,
}: ReaderEPUBProProps) {
  // 核心引用
  const containerRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 使用 ref 存储最新的 settings
  const settingsRef = useRef<ReadingSettings>(settings);
  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  // 阅读状态管理
  const readingState = useReadingState();

  // EPUB.js 阅读器
  const epubReader = useEpubjsReader(
    containerRef,
    book,
    settings,
    settingsRef,
    initialPosition,
    onProgressChange,
    onTOCChange
  );

  // 设备检测
  const [isMobile, setIsMobile] = useState(false);
  const [isPWA, setIsPWA] = useState(false);

  useEffect(() => {
    const checkDevice = () => {
      const userAgent = navigator.userAgent.toLowerCase();
      const mobileKeywords = ['android', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone'];
      const isMobileDevice = mobileKeywords.some(keyword => userAgent.includes(keyword)) || window.innerWidth <= 768;
      setIsMobile(isMobileDevice);

      const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
      const isFullscreen = (window.navigator as any).standalone === true;
      setIsPWA(isStandalone || isFullscreen);
    };

    checkDevice();
    window.addEventListener('resize', checkDevice);
    const mediaQuery = window.matchMedia('(display-mode: standalone)');
    mediaQuery.addEventListener('change', checkDevice);

    return () => {
      window.removeEventListener('resize', checkDevice);
      mediaQuery.removeEventListener('change', checkDevice);
    };
  }, []);

  // 获取文件URL（优先使用缓存，无缓存时后台下载）
  const getFileUrl = useCallback(async (): Promise<string | null> => {
    if (!book.file_path && !book.file_name && !book.id) return null;

    const ext = book.file_name?.split('.').pop()?.toLowerCase() || 'epub';
    let serverUrl: string;

    if (book.id) {
      serverUrl = `/books/${book.id}.${ext}`;
    } else if (book.file_path) {
      if (book.file_path.startsWith('http://') || book.file_path.startsWith('https://') || book.file_path.startsWith('/')) {
        serverUrl = book.file_path;
      } else {
        serverUrl = `/books/${book.file_path}`;
      }
    } else {
      return null;
    }

    // 尝试使用离线存储
    try {
      const { offlineStorage } = await import('../../../../utils/offlineStorage');
      if (book.id) {
        // 先检查缓存，如果有就立即返回（快速打开）
        const cachedBlob = await offlineStorage.getBook(book.id);
        if (cachedBlob) {
          console.log('ReaderEPUBPro: 使用本地缓存，快速打开');
          return offlineStorage.createBlobURL(cachedBlob);
        }
        
        // 如果没有缓存，先返回服务器URL（立即打开），然后在后台下载缓存
        console.log('ReaderEPUBPro: 未找到缓存，使用服务器URL，后台下载缓存...');
        
        // 后台异步下载并缓存（不阻塞打开）
        offlineStorage.downloadBook(book.id, ext, serverUrl).then((blob) => {
          console.log('ReaderEPUBPro: 后台缓存下载完成，下次打开将使用缓存');
        }).catch((error) => {
          console.warn('ReaderEPUBPro: 后台缓存下载失败', error);
          // 静默失败，不影响当前阅读
        });
        
        // 立即返回服务器URL，不等待下载完成
        return serverUrl;
      }
    } catch (error) {
      console.warn('ReaderEPUBPro: 离线存储不可用，使用服务器URL', error);
    }

    return serverUrl;
  }, [book.id, book.file_path, book.file_name]);

  // 加载阅读器
  useEffect(() => {
    const loadReader = async () => {
      if (!book.id && !book.file_path) {
        setError('书籍信息不完整');
        setLoading(false);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const fileUrl = await getFileUrl();
        if (!fileUrl) {
          throw new Error('无法获取书籍文件URL');
        }

        console.log('ReaderEPUBPro: 开始初始化阅读器...');
        await epubReader.initialize(fileUrl);
        console.log('ReaderEPUBPro: 阅读器初始化完成');
        
        // 确保加载状态被更新
        setLoading(false);
        
        // 额外检查：如果 2 秒后还在加载，强制设置为完成
        setTimeout(() => {
          setLoading(false);
        }, 2000);
      } catch (error: any) {
        console.error('ReaderEPUBPro: 加载失败', error);
        const errorMessage = error?.message || error?.toString() || '未知错误';
        setError(`加载失败: ${errorMessage}`);
        setLoading(false);
        toast.error(`加载书籍失败: ${error.message || '未知错误'}`);
      }
    };

    const timer = setTimeout(() => {
      loadReader();
    }, 100);

    return () => {
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [book.id, book.file_path]);

  // 实时更新主题和字体设置
  useEffect(() => {
    if (!epubReader.rendition) return;
    epubReader.updateTheme(settings);
  }, [settings.theme, settings.fontSize, settings.fontFamily, settings.lineHeight, settings.margin, settings.textIndent, epubReader]);

  // 在切后台/关闭页面时，强制 flush 一次最新位置
  useEffect(() => {
    const flushNow = () => {
      try {
        if (readingState.refs.isRestoringLayoutRef.current) return;
        const rendition = epubReader.rendition;
        const bookInstance = epubReader.book;
        const cfi =
          readingState.refs.lastCfiRef.current ||
          rendition?.currentLocation?.()?.start?.cfi ||
          null;

        if (readingState.refs.lastPositionRef.current && readingState.refs.lastPositionRef.current.currentLocation) {
          onProgressChange(
            readingState.refs.lastProgressRef.current || readingState.refs.lastPositionRef.current.progress || 0,
            readingState.refs.lastPositionRef.current
          );
          return;
        }

        if (typeof cfi !== 'string' || !cfi.startsWith('epubcfi(')) return;

        let currentPage = 1;
        let totalPages = 1;
        let progress = 0;
        try {
          if (
            readingState.refs.locationsReadyRef.current &&
            bookInstance?.locations &&
            typeof bookInstance.locations.locationFromCfi === 'function' &&
            typeof bookInstance.locations.length === 'function'
          ) {
            const loc = bookInstance.locations.locationFromCfi(cfi);
            const total = bookInstance.locations.length();
            if (typeof loc === 'number' && loc >= 0 && typeof total === 'number' && total > 0) {
              currentPage = loc + 1;
              totalPages = total;
              progress = Math.min(1, Math.max(0, (loc + 1) / total));
            }
          }
        } catch {
          // ignore
        }

        const spineIndex = rendition?.currentLocation?.()?.start?.index ?? 0;
        const pos: ReadingPosition = {
          chapterIndex: spineIndex,
          currentPage,
          totalPages,
          progress,
          currentLocation: cfi,
        };
        readingState.setLastProgress(progress);
        readingState.setLastPosition(pos);
        onProgressChange(progress, pos);
      } catch {
        // ignore
      }
    };

    const onVis = () => {
      if (document.visibilityState === 'hidden') flushNow();
    };
    const onPageHide = () => flushNow();
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('pagehide', onPageHide);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('pagehide', onPageHide);
      flushNow();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [book.id, onProgressChange, epubReader, readingState]);

  // 组件卸载时清理
  useEffect(() => {
    return () => {
      epubReader.cleanup();
    };
  }, [epubReader]);

  // 翻页处理
  const handlePageTurn = useCallback((direction: 'prev' | 'next') => {
    if (!epubReader.rendition) return;
    if (direction === 'prev') {
      epubReader.rendition.prev();
    } else {
      epubReader.rendition.next();
    }
  }, [epubReader]);

  // 显示导航栏
  const showBars = useCallback(() => {
    if ((window as any).__toggleReaderNavigation) {
      (window as any).__toggleReaderNavigation();
    }
  }, []);

  // 主题样式
  const themeStyles = getThemeStyles(settings.theme);

  // 错误处理
  if (error) {
    return (
      <div className="flex items-center justify-center h-full" style={{ backgroundColor: themeStyles.bg }}>
        <div className="text-center">
          <p style={{ color: themeStyles.text }} className="mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 rounded-lg"
            style={{ backgroundColor: themeStyles.bg, color: themeStyles.text, border: `1px solid ${themeStyles.text}` }}
          >
            重新加载
          </button>
        </div>
      </div>
    );
  }

  // 判断是否为PC端
  const isDesktop = typeof window !== 'undefined' && window.innerWidth >= 1024;

  // 获取阅读区域宽度样式
  const getReaderWidthStyle = () => {
    if (!isDesktop) {
      return { width: '100%', maxWidth: '100%', margin: '0' };
    }

    if (settings.readerWidth === 'centered') {
      return {
        width: '980px',
        maxWidth: '980px',
        margin: '0 auto',
      };
    } else {
      return {
        width: '100%',
        maxWidth: '100%',
        margin: '0',
      };
    }
  };

  // 获取背景样式
  const getBackgroundStyle = () => {
    const isCentered = isDesktop && settings.readerWidth === 'centered';

    const themeConfig = {
      light: {
        gradient: 'linear-gradient(145deg, rgba(255, 255, 255, 0.938) 0%, rgba(248, 250, 252, 0.5) 50%, rgba(241, 245, 249, 0.7) 100%)',
        shadow: isCentered
          ? '0 20px 60px rgba(0, 0, 0, 0.08), 0 8px 24px rgba(0, 0, 0, 0.05), 0 2px 8px rgba(0, 0, 0, 0.03), inset 0 1px 0 rgba(255, 255, 255, 0.9), inset 0 -1px 0 rgba(0, 0, 0, 0.02)'
          : 'inset 0 0 40px rgba(0, 0, 0, 0.02), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
        border: isCentered ? '1px solid rgba(226, 232, 240, 0.8)' : 'none',
        innerPadding: isCentered ? '24px' : '16px',
      },
      dark: {
        gradient: 'linear-gradient(145deg, rgba(28, 30, 34, 0.3) 0%, rgba(23, 25, 28, 0.5) 50%, rgba(18, 20, 23, 0.7) 100%)',
        shadow: isCentered
          ? '0 20px 60px rgba(0, 0, 0, 0.35), 0 8px 24px rgba(0, 0, 0, 0.25), 0 2px 8px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.08), inset 0 -1px 0 rgba(0, 0, 0, 0.4)'
          : 'inset 0 0 40px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.05)',
        border: isCentered ? '1px solid rgba(255, 255, 255, 0.08)' : 'none',
        innerPadding: isCentered ? '24px' : '16px',
      },
      sepia: {
        gradient: 'linear-gradient(145deg, rgba(250, 247, 240, 0.3) 0%, rgba(245, 238, 225, 0.5) 50%, rgba(240, 232, 215, 0.7) 100%)',
        shadow: isCentered
          ? '0 20px 60px rgba(92, 75, 55, 0.12), 0 8px 24px rgba(92, 75, 55, 0.08), 0 2px 8px rgba(92, 75, 55, 0.05), inset 0 1px 0 rgba(255, 248, 230, 0.9), inset 0 -1px 0 rgba(92, 75, 55, 0.05)'
          : 'inset 0 0 40px rgba(92, 75, 55, 0.03), inset 0 1px 0 rgba(255, 248, 230, 0.5)',
        border: isCentered ? '1px solid rgba(212, 196, 156, 0.4)' : 'none',
        innerPadding: isCentered ? '24px' : '16px',
      },
      green: {
        gradient: 'linear-gradient(145deg, rgba(245, 252, 245, 0.3) 0%, rgba(237, 247, 237, 0.5) 50%, rgba(232, 245, 233, 0.7) 100%)',
        shadow: isCentered
          ? '0 20px 60px rgba(46, 125, 50, 0.08), 0 8px 24px rgba(46, 125, 50, 0.05), 0 2px 8px rgba(46, 125, 50, 0.03), inset 0 1px 0 rgba(240, 255, 240, 0.9), inset 0 -1px 0 rgba(46, 125, 50, 0.03)'
          : 'inset 0 0 40px rgba(46, 125, 50, 0.02), inset 0 1px 0 rgba(240, 255, 240, 0.4)',
        border: isCentered ? '1px solid rgba(165, 214, 167, 0.4)' : 'none',
        innerPadding: isCentered ? '24px' : '16px',
      },
    }[settings.theme];

    return {
      background: themeConfig.gradient,
      boxShadow: themeConfig.shadow,
      borderRadius: isCentered ? '16px' : '0',
      border: themeConfig.border,
      padding: themeConfig.innerPadding,
    };
  };

  const readerWidthStyle = getReaderWidthStyle();
  const backgroundStyle = getBackgroundStyle();

  return (
    <div
      className="relative h-full w-full overflow-hidden"
      onContextMenu={(e) => {
        e.preventDefault();
      }}
      style={{
        backgroundColor: themeStyles.bg,
        touchAction: 'manipulation',
        WebkitTouchCallout: 'none',
        WebkitUserSelect: 'text',
        userSelect: 'text',
        paddingLeft: 'env(safe-area-inset-left, 0px)',
        paddingRight: 'env(safe-area-inset-right, 0px)',
        boxSizing: 'border-box',
        display: 'flex',
        alignItems: 'stretch',
        justifyContent: 'center',
      } as React.CSSProperties}
    >
      {/* 阅读内容背景容器 */}
      <div
        className="reader-background-texture relative h-full overflow-hidden"
        data-theme={settings.theme}
        style={{
          ...readerWidthStyle,
          ...backgroundStyle,
          transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
          backdropFilter: 'blur(12px) saturate(1.08)',
          WebkitBackdropFilter: 'blur(12px) saturate(1.08)',
          boxSizing: 'border-box',
          overflow: 'hidden',
          position: 'relative',
        }}
      >
        {/* 内部容器：epubjs 渲染区域 */}
        <div
          ref={containerRef}
          className="reader-content-wrapper relative h-full w-full overflow-hidden"
          style={{
            borderRadius: isDesktop && settings.readerWidth === 'centered' ? '12px' : '0',
          }}
          suppressHydrationWarning
        >
          <LoadingOverlay loading={loading} theme={settings.theme} />

          <TouchOverlay
            loading={loading}
            settings={settings}
            isMobile={isMobile}
            onPageTurn={handlePageTurn}
            onShowBars={showBars}
          />

          {/* epubjs 会直接渲染到 containerRef 中 */}
        </div>
      </div>
    </div>
  );
}

