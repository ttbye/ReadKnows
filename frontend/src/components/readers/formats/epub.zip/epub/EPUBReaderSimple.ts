/**
 * EPUB 阅读器 - 基于 epubjs 的简单实现
 * 使用 epubjs 的默认 next/pre 分页方式，避免复杂的分页逻辑
 */

// 导入 epubjs
// @ts-ignore - epubjs 类型定义可能不完整
import ePub from 'epubjs';

export interface SimpleReaderSettings {
  fontSize?: number;
  fontFamily?: string;
  lineHeight?: number;
  theme?: 'light' | 'dark' | 'sepia' | 'green';
  margin?: number;
}

export interface SimpleReadingPosition {
  cfi?: string; // epubjs 使用的 CFI 位置
  chapterIndex?: number;
}

export class EPUBReaderSimple {
  private container: HTMLElement;
  private book: any; // ePub.Book
  private rendition: any; // ePub.Rendition
  private settings: SimpleReaderSettings;
  private currentCFI: string = '';
  private onProgressChange?: (progress: number, position: any) => void;
  private onPageChange?: (current: number, total: number) => void;

  constructor(container: HTMLElement, settings: SimpleReaderSettings = {}) {
    this.container = container;
    this.settings = {
      fontSize: 16,
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      lineHeight: 1.6,
      theme: 'light',
      margin: 20,
      ...settings,
    };
  }

  /**
   * 初始化书籍
   */
  async init(bookData: ArrayBuffer | Blob | string): Promise<any> {
    try {
      console.log('[EPUBReaderSimple] 开始初始化，bookData 类型:', typeof bookData, bookData instanceof ArrayBuffer, bookData instanceof Blob);
      
      // 确保容器有正确的尺寸
      if (!this.container || this.container.clientWidth === 0 || this.container.clientHeight === 0) {
        console.warn('[EPUBReaderSimple] 容器尺寸异常，等待容器准备好...');
        await new Promise(resolve => {
          let retryCount = 0;
          const checkSize = () => {
            if (this.container && this.container.clientWidth > 0 && this.container.clientHeight > 0) {
              console.log('[EPUBReaderSimple] 容器已准备好，尺寸:', this.container.clientWidth, 'x', this.container.clientHeight);
              resolve(undefined);
            } else if (retryCount >= 20) {
              console.warn('[EPUBReaderSimple] 容器等待超时，继续初始化');
              resolve(undefined);
            } else {
              retryCount++;
              setTimeout(checkSize, 100);
            }
          };
          checkSize();
        });
      }
      
      // 创建 epubjs Book 实例
      // 优先使用全局变量（如果通过 script 标签引入），否则使用模块导入
      const ePubInstance = (typeof window !== 'undefined' && (window as any).ePub) || ePub;
      
      if (!ePubInstance) {
        throw new Error('无法加载 epubjs 库，请确保已正确安装或引入');
      }
      
      console.log('[EPUBReaderSimple] 创建 epubjs Book 实例...');
      console.log('[EPUBReaderSimple] bookData 大小:', bookData instanceof ArrayBuffer ? bookData.byteLength : 'unknown');
      
      // epubjs 对 ArrayBuffer 的支持可能有问题，直接转换为 Blob URL（更可靠）
      let blobUrl: string | null = null;
      let bookSource: string | ArrayBuffer | Blob = bookData;
      
      if (bookData instanceof ArrayBuffer) {
        console.log('[EPUBReaderSimple] 将 ArrayBuffer 转换为 Blob URL（epubjs 推荐方式）...');
        const blob = new Blob([bookData], { type: 'application/epub+zip' });
        blobUrl = URL.createObjectURL(blob);
        bookSource = blobUrl;
        console.log('[EPUBReaderSimple] Blob URL 已创建');
      }
      
      try {
        this.book = new ePubInstance(bookSource, {
          openAs: 'epub',
        });
        console.log('[EPUBReaderSimple] Book 实例已创建');
        
        // 检查 book 是否有效
        if (!this.book) {
          throw new Error('Book 实例创建失败，返回 null');
        }
      } catch (e: any) {
        // 清理 Blob URL
        if (blobUrl) {
          URL.revokeObjectURL(blobUrl);
        }
        console.error('[EPUBReaderSimple] 创建 Book 实例失败:', e);
        throw new Error(`创建 epubjs Book 实例失败: ${e?.message || e}`);
      }
      
      // 等待书籍加载完成（添加超时保护）
      console.log('[EPUBReaderSimple] 等待书籍加载完成...');
      console.log('[EPUBReaderSimple] book.ready 类型:', typeof this.book.ready, this.book.ready instanceof Promise);
      
      // epubjs 的 ready 应该是一个 Promise
      // 使用 Promise.resolve 确保它是一个 Promise
      const readyPromise = Promise.resolve(this.book.ready).catch((err) => {
        console.warn('[EPUBReaderSimple] book.ready Promise 被 reject:', err);
        // 如果 ready Promise 被 reject，尝试继续
        return Promise.resolve();
      });
      
      try {
        await Promise.race([
          readyPromise,
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('书籍加载超时（15秒）')), 15000)
          )
        ]);
        console.log('[EPUBReaderSimple] book.ready 已完成');
      } catch (timeoutError) {
        // 如果超时，检查 book 是否已经可用
        console.warn('[EPUBReaderSimple] 等待 ready 超时，检查 book 状态...');
        if (!this.book) {
          // 清理 Blob URL
          if (blobUrl) {
            URL.revokeObjectURL(blobUrl);
          }
          throw new Error('Book 实例为 null，无法继续');
        }
        
        // 检查 book 的属性是否可用
        const hasPackage = this.book.package !== null && this.book.package !== undefined;
        const hasSpine = this.book.spine !== null && this.book.spine !== undefined;
        console.log('[EPUBReaderSimple] book 状态检查:', { hasPackage, hasSpine });
        
        if (hasPackage && hasSpine) {
          console.warn('[EPUBReaderSimple] book 似乎已经可用，继续初始化...');
        } else {
          // 清理 Blob URL
          if (blobUrl) {
            URL.revokeObjectURL(blobUrl);
          }
          throw new Error(`书籍加载超时，book 状态不完整: package=${hasPackage}, spine=${hasSpine}`);
        }
      }
      
      // 清理 Blob URL（如果使用了）- 延迟清理，确保 epubjs 已经使用完
      if (blobUrl) {
        // 保存 blobUrl 到实例，在 destroy 时清理
        (this as any)._blobUrl = blobUrl;
        // 也可以延迟清理
        setTimeout(() => {
          if ((this as any)._blobUrl === blobUrl) {
            URL.revokeObjectURL(blobUrl);
            console.log('[EPUBReaderSimple] Blob URL 已清理');
            (this as any)._blobUrl = null;
          }
        }, 5000);
      }
      
      console.log('[EPUBReaderSimple] 书籍加载完成，创建渲染器...');
      
      // 确保容器仍然有效
      if (!this.container || this.container.clientWidth === 0 || this.container.clientHeight === 0) {
        console.warn('[EPUBReaderSimple] 容器尺寸仍然异常，使用默认尺寸');
        this.container.style.width = '100%';
        this.container.style.height = '100%';
      }
      
      // 创建渲染器
      this.rendition = this.book.renderTo(this.container, {
        width: '100%',
        height: '100%',
        spread: 'none', // 单页模式
        flow: 'paginated', // 分页模式
      });
      
      // 确保分页已启用
      if (this.rendition.manager) {
        console.log('[EPUBReaderSimple] 分页管理器已启用');
      } else {
        console.warn('[EPUBReaderSimple] 分页管理器未启用，可能需要手动启用');
      }

      console.log('[EPUBReaderSimple] 渲染器创建完成，应用样式...');

      // 应用初始样式
      this.applySettings();

      // 监听位置变化
      this.rendition.on('relocated', (location: any) => {
        if (location && location.start) {
          this.currentCFI = location.start.cfi;
          this.updateProgress();
        }
      });

      // 显示第一页（添加超时保护）
      console.log('[EPUBReaderSimple] 显示第一页...');
      await Promise.race([
        this.rendition.display(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('显示页面超时（5秒）')), 5000)
        )
      ]);

      console.log('[EPUBReaderSimple] 初始化完成');

      return {
        title: this.book.package?.metadata?.title || '未知标题',
        author: this.book.package?.metadata?.creator || '未知作者',
        totalChapters: this.book.spine?.length || 0,
      };
    } catch (error) {
      console.error('[EPUBReaderSimple] 初始化失败:', error);
      throw error;
    }
  }

  /**
   * 应用设置
   */
  applySettings(settings?: Partial<SimpleReaderSettings>): void {
    if (settings) {
      this.settings = { ...this.settings, ...settings };
    }

    if (!this.rendition) return;

    // 应用字体大小
    if (this.settings.fontSize) {
      this.rendition.themes.fontSize(`${this.settings.fontSize}px`);
    }

    // 应用字体
    if (this.settings.fontFamily) {
      this.rendition.themes.font(this.settings.fontFamily);
    }

    // 应用主题
    if (this.settings.theme) {
      const themes: Record<string, any> = {
        light: {
          body: {
            background: '#ffffff !important',
            color: '#333333 !important',
          },
        },
        dark: {
          body: {
            background: '#1a1a1a !important',
            color: '#e0e0e0 !important',
          },
        },
        sepia: {
          body: {
            background: '#f4e8d0 !important',
            color: '#5c4b37 !important',
          },
        },
        green: {
          body: {
            background: '#e8f5e9 !important',
            color: '#2e7d32 !important',
          },
        },
      };

      this.rendition.themes.register('theme', themes[this.settings.theme] || themes.light);
      this.rendition.themes.select('theme');
    }

    // 应用行高
    if (this.settings.lineHeight) {
      this.rendition.themes.override('line-height', `${this.settings.lineHeight}`);
    }

    // 应用边距
    if (this.settings.margin) {
      this.rendition.themes.override('padding', `${this.settings.margin}px`);
    }

    // 图片居中
    this.rendition.themes.override(`
      img, figure {
        display: block !important;
        margin-left: auto !important;
        margin-right: auto !important;
        max-width: 100% !important;
        height: auto !important;
        object-fit: contain !important;
      }
    `);
  }

  /**
   * 下一页
   */
  async nextPage(): Promise<boolean> {
    if (!this.rendition) {
      console.warn('[EPUBReaderSimple] rendition 不存在，无法翻页');
      return false;
    }
    
    try {
      console.log('[EPUBReaderSimple] 尝试翻到下一页...');
      
      // epubjs 的 next() 返回一个 Promise
      const result = await this.rendition.next();
      console.log('[EPUBReaderSimple] next() 返回:', result);
      
      // 等待一下确保渲染完成
      await new Promise(resolve => setTimeout(resolve, 100));
      
      return true;
    } catch (error: any) {
      console.warn('[EPUBReaderSimple] 无法翻到下一页:', error);
      
      // 如果 next() 失败，可能是已经到最后一页
      // 检查是否还有下一页
      try {
        const currentLocation = this.rendition.currentLocation();
        console.log('[EPUBReaderSimple] 当前位置:', currentLocation);
        
        if (currentLocation && currentLocation.start) {
          // 尝试获取下一个 CFI
          const nextCFI = this.rendition.location.next(currentLocation.start.cfi);
          if (nextCFI) {
            console.log('[EPUBReaderSimple] 使用 CFI 跳转到下一页:', nextCFI);
            await this.rendition.display(nextCFI);
            return true;
          } else {
            console.log('[EPUBReaderSimple] 已经是最后一页');
            return false;
          }
        }
      } catch (fallbackError) {
        console.warn('[EPUBReaderSimple] 备用翻页方法也失败:', fallbackError);
      }
      return false;
    }
  }

  /**
   * 上一页
   */
  async prevPage(): Promise<boolean> {
    if (!this.rendition) {
      console.warn('[EPUBReaderSimple] rendition 不存在，无法翻页');
      return false;
    }
    
    try {
      console.log('[EPUBReaderSimple] 尝试翻到上一页...');
      
      // epubjs 的 prev() 返回一个 Promise
      const result = await this.rendition.prev();
      console.log('[EPUBReaderSimple] prev() 返回:', result);
      
      // 等待一下确保渲染完成
      await new Promise(resolve => setTimeout(resolve, 100));
      
      return true;
    } catch (error: any) {
      console.warn('[EPUBReaderSimple] 无法翻到上一页:', error);
      
      // 如果 prev() 失败，可能是已经到第一页
      // 检查是否还有上一页
      try {
        const currentLocation = this.rendition.currentLocation();
        console.log('[EPUBReaderSimple] 当前位置:', currentLocation);
        
        if (currentLocation && currentLocation.start) {
          // 尝试获取上一个 CFI
          const prevCFI = this.rendition.location.prev(currentLocation.start.cfi);
          if (prevCFI) {
            console.log('[EPUBReaderSimple] 使用 CFI 跳转到上一页:', prevCFI);
            await this.rendition.display(prevCFI);
            return true;
          } else {
            console.log('[EPUBReaderSimple] 已经是第一页');
            return false;
          }
        }
      } catch (fallbackError) {
        console.warn('[EPUBReaderSimple] 备用翻页方法也失败:', fallbackError);
      }
      return false;
    }
  }

  /**
   * 跳转到指定位置
   */
  async goToCFI(cfi: string): Promise<void> {
    if (!this.rendition) return;
    
    try {
      await this.rendition.display(cfi);
    } catch (error) {
      console.error('[EPUBReaderSimple] 跳转失败:', error);
    }
  }

  /**
   * 跳转到指定章节
   */
  async goToChapter(index: number): Promise<void> {
    if (!this.book || !this.rendition) return;
    
    try {
      const spineItem = this.book.spine.get(index);
      if (spineItem) {
        await this.rendition.display(spineItem.href);
      }
    } catch (error) {
      console.error('[EPUBReaderSimple] 跳转章节失败:', error);
    }
  }

  /**
   * 获取当前位置
   */
  getPosition(): SimpleReadingPosition {
    return {
      cfi: this.currentCFI,
    };
  }

  /**
   * 获取进度
   */
  getProgress(): number {
    if (!this.book) return 0;
    
    try {
      return this.book.locations.percentageFromCfi(this.currentCFI) || 0;
    } catch (error) {
      return 0;
    }
  }

  /**
   * 获取当前页信息
   */
  getCurrentPageInfo(): { currentPage: number; totalPages: number } {
    // epubjs 不提供精确的页码，使用章节和位置估算
    if (!this.book) {
      return { currentPage: 1, totalPages: 1 };
    }

    try {
      const percentage = this.getProgress();
      const totalChapters = this.book.spine.length;
      const estimatedPage = Math.ceil(percentage * totalChapters * 10); // 估算每章10页
      const estimatedTotal = totalChapters * 10;
      
      return {
        currentPage: Math.max(1, estimatedPage),
        totalPages: Math.max(1, estimatedTotal),
      };
    } catch (error) {
      return { currentPage: 1, totalPages: 1 };
    }
  }

  /**
   * 设置回调
   */
  setCallbacks(callbacks: {
    onProgressChange?: (progress: number, position: any) => void;
    onPageChange?: (current: number, total: number) => void;
  }): void {
    this.onProgressChange = callbacks.onProgressChange;
    this.onPageChange = callbacks.onPageChange;
  }

  /**
   * 更新进度
   */
  private updateProgress(): void {
    if (!this.onProgressChange) return;

    const progress = this.getProgress();
    const pageInfo = this.getCurrentPageInfo();
    
    this.onProgressChange(progress, {
      cfi: this.currentCFI,
      currentPage: pageInfo.currentPage,
      totalPages: pageInfo.totalPages,
      progress,
    });

    if (this.onPageChange) {
      this.onPageChange(pageInfo.currentPage, pageInfo.totalPages);
    }
  }

  /**
   * 更新设置
   */
  updateSettings(settings: Partial<SimpleReaderSettings>): void {
    this.applySettings(settings);
  }

  /**
   * 跳转到指定页面（epubjs 不支持精确页码，使用估算）
   */
  async goToPage(pageIndex: number): Promise<void> {
    if (!this.book || !this.rendition) return;
    
    try {
      // epubjs 不支持精确页码，使用章节和位置估算
      const totalChapters = this.book.spine.length;
      const estimatedChapter = Math.floor((pageIndex / (totalChapters * 10)) * totalChapters);
      const chapterIndex = Math.max(0, Math.min(totalChapters - 1, estimatedChapter));
      
      await this.goToChapter(chapterIndex);
    } catch (error) {
      console.error('[EPUBReaderSimple] 跳转页面失败:', error);
    }
  }

  /**
   * 添加书签
   */
  addBookmark(): void {
    if (!this.book || !this.currentCFI) {
      console.warn('[EPUBReaderSimple] 无法添加书签：没有当前位置');
      return;
    }
    // epubjs 的书签功能需要额外实现
    console.log('[EPUBReaderSimple] 添加书签:', this.currentCFI);
  }

  /**
   * 获取 TOC（通过 book 对象）
   */
  getTOC(): any[] {
    if (!this.book || !this.book.navigation) {
      return [];
    }
    return this.book.navigation.toc || [];
  }

  /**
   * 获取 book 对象（用于访问 epubjs 的原始功能）
   */
  getBook(): any {
    return this.book;
  }

  /**
   * 销毁
   */
  destroy(): void {
    // 清理 Blob URL
    if ((this as any)._blobUrl) {
      try {
        URL.revokeObjectURL((this as any)._blobUrl);
        console.log('[EPUBReaderSimple] 清理 Blob URL');
      } catch (error) {
        console.warn('[EPUBReaderSimple] 清理 Blob URL 失败:', error);
      }
      (this as any)._blobUrl = null;
    }
    
    if (this.rendition) {
      try {
        this.rendition.destroy();
      } catch (error) {
        console.warn('[EPUBReaderSimple] 销毁 rendition 失败:', error);
      }
      this.rendition = null;
    }
    if (this.book) {
      try {
        this.book.destroy();
      } catch (error) {
        console.warn('[EPUBReaderSimple] 销毁 book 失败:', error);
      }
      this.book = null;
    }
  }
}

