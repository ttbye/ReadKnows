/**
 * @author ttbye
 * 专业级 EPUB 电子书阅读器（重构版）
 * 
 * 此文件已重构为使用模块化架构
 * 新的实现在 epub/ 目录下，包含：
 * - hooks/ 自定义 hooks
 * - services/ 服务层
 * - utils/ 工具函数
 * - components/ 子组件
 * 
 * 为了保持向后兼容，此文件导出新的实现
 */

// 导出新的重构版本
export { default } from './epub';
