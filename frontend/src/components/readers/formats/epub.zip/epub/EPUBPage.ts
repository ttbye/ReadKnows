/**
 * EPUB 分页器 - 基于实际DOM渲染的精确分页
 * 
 * 核心方法：
 * 1. 将内容渲染到隐藏容器中
 * 2. 使用 Range API 获取每一行的实际位置
 * 3. 根据行的 Y 坐标来分页
 * 4. 确保不丢失任何内容
 */

import { Chapter } from './EPUBBook';

export interface Page {
  index: number;
  startElementIndex: number;
  endElementIndex: number;
  elements: HTMLElement[];
  startLine: number;
  endLine: number;
  lines: LineInfo[];
}

export interface PaginationOptions {
  containerHeight: number;
  containerWidth: number;
  fontSize: number;
  lineHeight: number;
  margin: number;
}

/**
 * 行信息（基于实际渲染）
 */
export interface LineInfo {
  element: HTMLElement;
  elementIndex: number;
  lineNumber: number;
  text: string;
  top: number;  // 行的实际 Y 坐标
  height: number;
  isFirstLineOfElement?: boolean;
  isLastLineOfElement?: boolean;
  isImage?: boolean; // 是否是图片元素
  imageHeight?: number; // 图片的实际高度（如果超过页面高度，需要特殊处理）
}

export class EPUBPage {
  private pages: Page[] = [];
  private currentPageIndex: number = 0;
  private options: PaginationOptions;
  private allLines: LineInfo[] = [];
  private pageHeight: number = 0;

  constructor(options: PaginationOptions) {
    this.options = options;
  }

  updateOptions(options: Partial<PaginationOptions>): void {
    this.options = { ...this.options, ...options };
    this.pages = [];
    this.allLines = [];
  }

  /**
   * 分页 - 使用实际DOM渲染方法
   */
  async paginate(chapter: Chapter, container: HTMLElement): Promise<Page[]> {
    try {
      this.pages = [];
      this.currentPageIndex = 0;
      this.allLines = [];

      console.log('[EPUBPage] 开始基于实际DOM渲染的分页');

      // 获取容器尺寸
      let { actualWidth, actualHeight } = this.getContainerDimensions(container);

      // 检查容器尺寸是否有效
      if (actualHeight <= 0 || actualHeight < 100) {
        console.error(`[EPUBPage] 容器高度无效: ${actualHeight}px, 无法进行分页`);
        return [];
      }

      if (actualWidth <= 0) {
        console.error(`[EPUBPage] 容器宽度无效: ${actualWidth}px, 无法进行分页`);
        return [];
      }

      // 查找 chapter-wrapper
      const wrapper = container.querySelector('.chapter-wrapper') as HTMLElement;
      if (!wrapper) {
        console.error('[EPUBPage] 未找到 .chapter-wrapper');
        return [];
      }

      // 检查 chapter-wrapper 的 padding，需要从可用高度中减去
      const wrapperStyle = window.getComputedStyle(wrapper);
      const wrapperPaddingTop = parseFloat(wrapperStyle.paddingTop) || 0;
      const wrapperPaddingBottom = parseFloat(wrapperStyle.paddingBottom) || 0;
      
      // chapter-wrapper 的 padding 会占用空间，需要从可用高度中减去
      if (wrapperPaddingTop > 0 || wrapperPaddingBottom > 0) {
        actualHeight = actualHeight - wrapperPaddingTop - wrapperPaddingBottom;
        console.log(`[EPUBPage] chapter-wrapper 有 padding: top=${wrapperPaddingTop}px, bottom=${wrapperPaddingBottom}px, 调整后可用高度=${actualHeight}px`);
      }

      // 更新 pageHeight（用于分页计算）
      this.pageHeight = actualHeight;

      // 获取所有文本元素
      const elements = this.getTextElements(wrapper);
      if (elements.length === 0) {
        console.warn('[EPUBPage] 未找到可分页元素');
        return [];
      }

      console.log(`[EPUBPage] 找到 ${elements.length} 个元素`);

      // 使用实际DOM渲染来获取每一行的位置
      await this.measureLinesWithDOM(elements, wrapper, actualWidth, actualHeight);

      if (this.allLines.length === 0) {
        console.warn('[EPUBPage] 未生成任何行');
        return [];
      }

      console.log(`[EPUBPage] 共生成 ${this.allLines.length} 行`);

      // 根据行的实际位置来分页
      this.calculatePagesByPosition();

      console.log(`[EPUBPage] 分页完成: ${this.pages.length} 页`);
      return this.pages;
    } catch (error) {
      console.error('[EPUBPage] 分页出错:', error);
      return [];
    }
  }

  /**
   * 获取容器尺寸
   * 重新设计：确保正确计算可用高度，不受导航栏影响
   */
  private getContainerDimensions(container: HTMLElement): {
    actualWidth: number;
    actualHeight: number;
  } {
    const containerRect = container.getBoundingClientRect();
    const actualWidth = containerRect.width || this.options.containerWidth;
    const computedStyle = window.getComputedStyle(container);
    
    // 方法1：使用 clientHeight（最准确，不包含 padding）
    // clientHeight 已经自动排除了 padding，是容器内实际可用的高度
    let actualHeight = container.clientHeight;
    
    // 如果 clientHeight 不可用，使用 getBoundingClientRect 减去 padding
    if (!actualHeight || actualHeight <= 0) {
      const paddingTop = parseFloat(computedStyle.paddingTop) || 0;
      const paddingBottom = this.parseComputedValue(computedStyle.paddingBottom);
      actualHeight = containerRect.height - paddingTop - paddingBottom;
    }
    
    // 额外安全边距：确保上下内容不被遮挡
    // 上边距：预留 4px，防止顶部内容被遮挡
    // 下边距：预留 12px，防止底部内容被遮挡（考虑导航栏等）
    const topSafetyMargin = 4;
    const bottomSafetyMargin = 12;
    actualHeight = actualHeight - topSafetyMargin - bottomSafetyMargin;
    
    // 确保最小高度
    actualHeight = Math.max(100, actualHeight);
    
    console.log(`[EPUBPage] 容器尺寸计算: 
      - 容器高度=${containerRect.height}px
      - clientHeight=${container.clientHeight}px
      - paddingTop=${parseFloat(computedStyle.paddingTop) || 0}px
      - paddingBottom=${this.parseComputedValue(computedStyle.paddingBottom)}px (原始值: ${computedStyle.paddingBottom})
      - 上安全边距=${topSafetyMargin}px
      - 下安全边距=${bottomSafetyMargin}px
      - 实际可用高度=${actualHeight}px`);
    
    return { actualWidth, actualHeight };
  }

  /**
   * 解析计算后的 CSS 值（支持 calc、clamp、env 等）
   */
  private parseComputedValue(value: string): number {
    if (!value || value === '0px') {
      return 0;
    }
    
    // 如果是 calc/clamp/env 表达式，使用实际测量
    if (value.includes('calc') || value.includes('clamp') || value.includes('env')) {
      const tempEl = document.createElement('div');
      tempEl.style.position = 'absolute';
      tempEl.style.visibility = 'hidden';
      tempEl.style.width = '1px';
      tempEl.style.height = '1px';
      tempEl.style.paddingBottom = value;
      document.body.appendChild(tempEl);
      
      const computed = getComputedStyle(tempEl).paddingBottom;
      const result = parseFloat(computed) || 0;
      
      document.body.removeChild(tempEl);
      return result;
    }
    
    // 普通数值，直接解析
    return parseFloat(value) || 0;
  }

  /**
   * 获取所有文本元素和图片元素
   */
  private getTextElements(wrapper: HTMLElement): HTMLElement[] {
    const selectors = [
      'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
      'li', 'blockquote', 'pre', 'code',
      'div', 'span', 'section', 'article',
      'img', 'figure', // 添加图片相关元素
    ];

    const allElements: HTMLElement[] = [];
    for (const selector of selectors) {
      const elements = Array.from(wrapper.querySelectorAll(selector)) as HTMLElement[];
      allElements.push(...elements);
    }

    // 过滤：只保留有文本内容或图片的顶级元素
    const elementSet = new Set(allElements);
    const topLevelElements: HTMLElement[] = [];
    
    for (const el of allElements) {
      let isNested = false;
      let parent = el.parentElement;
      while (parent && parent !== wrapper) {
        if (elementSet.has(parent)) {
          isNested = true;
          break;
        }
        parent = parent.parentElement;
      }
      
      if (!isNested) {
        // 检查是否是图片元素
        const isImage = el.tagName.toLowerCase() === 'img' || 
                       el.tagName.toLowerCase() === 'figure' ||
                       el.querySelector('img') !== null;
        
        // 检查是否有文本内容
        const textContent = el.textContent?.trim() || '';
        const hasText = textContent.length > 0;
        
        // 如果是图片元素或有文本内容，则包含
        if (isImage || hasText) {
          topLevelElements.push(el);
        }
      }
    }

    return topLevelElements;
  }

  /**
   * 使用实际DOM渲染来测量每一行的位置
   * 这是核心方法：使用 Range API 获取每一行的实际位置
   */
  private async measureLinesWithDOM(
    elements: HTMLElement[],
    wrapper: HTMLElement,
    containerWidth: number,
    containerHeight: number
  ): Promise<void> {
    // 确保元素可见并应用样式
    elements.forEach((el, index) => {
      el.style.display = '';
      el.style.visibility = 'visible';
      el.style.opacity = '1';
      el.setAttribute('data-pagination-index', index.toString());
    });

    // 等待图片加载完成
    await this.waitForImages(elements);

    // 等待布局稳定
    await new Promise(resolve => {
      requestAnimationFrame(() => {
        requestAnimationFrame(resolve);
      });
    });

    const wrapperRect = wrapper.getBoundingClientRect();
    const wrapperTop = wrapperRect.top;
    const margin = this.options.margin;

    // 遍历每个元素，使用 Range API 获取每一行的位置
    for (let i = 0; i < elements.length; i++) {
      const element = elements[i];
      const tagName = element.tagName.toLowerCase();
      
      // 检查是否是图片元素
      const isImage = tagName === 'img' || tagName === 'figure' || element.querySelector('img') !== null;
      
      if (isImage) {
        // 处理图片元素
        const imageLines = await this.getLinesFromImage(element, wrapperTop, margin);
        if (imageLines.length > 0) {
          imageLines[0].isFirstLineOfElement = true;
          imageLines[imageLines.length - 1].isLastLineOfElement = true;
          this.allLines.push(...imageLines);
        }
      } else {
        // 处理文本元素
        // 获取元素的所有文本节点
        const textNodes = this.getTextNodes(element);
        
        if (textNodes.length === 0) {
          continue;
        }

        // 使用 Range API 来获取每一行的位置
        const elementLines = this.getLinesFromElement(element, textNodes, wrapperTop, margin);
        
        // 标记第一行和最后一行
        if (elementLines.length > 0) {
          elementLines[0].isFirstLineOfElement = true;
          elementLines[elementLines.length - 1].isLastLineOfElement = true;
        }
        
        this.allLines.push(...elementLines);
      }
    }

    // 按 top 位置排序，但保持元素顺序
    // 重要：先按 elementIndex 分组，再按 top 排序，确保同一元素的行的顺序正确
    this.allLines.sort((a, b) => {
      // 首先按 elementIndex 排序（保持元素顺序）
      if (a.elementIndex !== b.elementIndex) {
        return a.elementIndex - b.elementIndex;
      }
      // 同一元素内，按 top 位置排序
      if (a.top !== b.top) {
        return a.top - b.top;
      }
      // 如果都相同，按文本内容排序（避免完全重复）
      return a.text.localeCompare(b.text);
    });
    
    // 去重：移除重复的行（相同的 top、elementIndex 和文本）
    const uniqueLines: LineInfo[] = [];
    const seenKeys = new Set<string>();
    
    for (const line of this.allLines) {
      // 创建唯一键：top + elementIndex + text（前50个字符）
      const key = `${Math.round(line.top * 10) / 10}_${line.elementIndex}_${line.text.substring(0, 50)}`;
      
      if (!seenKeys.has(key)) {
        seenKeys.add(key);
        uniqueLines.push(line);
      } else {
        console.warn(`[EPUBPage] 检测到重复行，已移除: top=${line.top}, elementIndex=${line.elementIndex}, text=${line.text.substring(0, 30)}...`);
      }
    }
    
    this.allLines = uniqueLines;
    
    // 重新分配行号
    this.allLines.forEach((line, index) => {
      line.lineNumber = index;
    });
  }

  /**
   * 等待图片加载完成
   */
  private async waitForImages(elements: HTMLElement[]): Promise<void> {
    const images: HTMLImageElement[] = [];
    
    for (const el of elements) {
      const tagName = el.tagName.toLowerCase();
      if (tagName === 'img') {
        images.push(el as HTMLImageElement);
      } else {
        const img = el.querySelector('img') as HTMLImageElement;
        if (img) {
          images.push(img);
        }
      }
    }
    
    if (images.length === 0) {
      return;
    }
    
    // 等待所有图片加载完成（最多等待 3 秒）
    await Promise.all(images.map(img => {
      return new Promise<void>((resolve) => {
        if (img.complete && img.naturalWidth > 0) {
          resolve();
          return;
        }
        
        const timeout = setTimeout(() => {
          console.warn(`[EPUBPage] 图片加载超时: ${img.src}`);
          resolve();
        }, 3000);
        
        img.onload = () => {
          clearTimeout(timeout);
          resolve();
        };
        
        img.onerror = () => {
          clearTimeout(timeout);
          console.warn(`[EPUBPage] 图片加载失败: ${img.src}`);
          resolve();
        };
      });
    }));
  }

  /**
   * 获取元素的所有文本节点
   */
  private getTextNodes(element: HTMLElement): Node[] {
    const textNodes: Node[] = [];
    const walker = document.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT,
      null
    );

    let node;
    while (node = walker.nextNode()) {
      if (node.textContent && node.textContent.trim().length > 0) {
        textNodes.push(node);
      }
    }

    return textNodes;
  }

  /**
   * 从图片元素中获取位置信息
   */
  private async getLinesFromImage(
    element: HTMLElement,
    wrapperTop: number,
    margin: number
  ): Promise<LineInfo[]> {
    const lines: LineInfo[] = [];
    const elementIndex = parseInt(element.getAttribute('data-pagination-index') || '0');
    
    // 确保图片元素可见，以便正确测量
    const originalDisplay = element.style.display;
    const originalVisibility = element.style.visibility;
    const originalOpacity = element.style.opacity;
    
    element.style.display = '';
    element.style.visibility = 'visible';
    element.style.opacity = '1';
    
    // 等待布局更新
    // 获取图片元素（可能是 img 标签本身，或者在 figure 中的 img）
    const imgElement = element.tagName.toLowerCase() === 'img' 
      ? element as HTMLImageElement 
      : element.querySelector('img') as HTMLImageElement;
    
    // 获取元素的实际位置和尺寸
    const elementRect = element.getBoundingClientRect();
    
    if (!imgElement) {
      // 如果没有找到图片，使用元素本身的位置
      if (elementRect.height > 0) {
        lines.push({
          element,
          elementIndex,
          lineNumber: this.allLines.length,
          text: '', // 图片没有文本
          top: elementRect.top - wrapperTop - margin,
          height: elementRect.height,
          isFirstLineOfElement: true,
          isLastLineOfElement: true,
        });
      }
      // 恢复原始样式
      element.style.display = originalDisplay;
      element.style.visibility = originalVisibility;
      element.style.opacity = originalOpacity;
      return lines;
    }
    
    // 确保图片元素也可见，并保持宽高比，根据页面尺寸适当缩小
    imgElement.style.display = 'block';
    imgElement.style.visibility = 'visible';
    imgElement.style.opacity = '1';
    
    // 计算最大尺寸限制
    const containerWidth = this.options.containerWidth - (this.options.margin * 2);
    const availablePageHeight = this.pageHeight - (this.options.margin * 2) - 12;
    
    // 设置最大尺寸，确保图片不会超出页面
    imgElement.style.maxWidth = `${containerWidth}px`;
    imgElement.style.maxHeight = `${availablePageHeight}px`;
    imgElement.style.width = 'auto';
    imgElement.style.height = 'auto';
    imgElement.style.objectFit = 'contain'; // 保持宽高比，不变形
    imgElement.style.objectPosition = 'center';
    
    // 等待一帧，确保布局更新
    await new Promise(resolve => requestAnimationFrame(resolve));
    
    // 重新获取元素位置（布局可能已更新）
    const updatedElementRect = element.getBoundingClientRect();
    const imgRect = imgElement.getBoundingClientRect();
    
    // 计算图片的实际显示尺寸（保持宽高比，根据页面尺寸适当缩小）
    // containerWidth 和 availablePageHeight 已在上面声明
    let imgWidth = 0;
    let imgHeight = 0;
    
    if (imgElement.complete && imgElement.naturalWidth > 0 && imgElement.naturalHeight > 0) {
      // 图片已加载，使用原始尺寸计算显示尺寸
      const naturalWidth = imgElement.naturalWidth;
      const naturalHeight = imgElement.naturalHeight;
      const aspectRatio = naturalWidth / naturalHeight;
      
      // 根据容器宽度和高度计算显示尺寸（保持宽高比）
      // 先按宽度计算
      let calculatedWidth = naturalWidth;
      let calculatedHeight = naturalHeight;
      
      if (naturalWidth > containerWidth) {
        // 图片宽度超过容器，按宽度缩放
        calculatedWidth = containerWidth;
        calculatedHeight = containerWidth / aspectRatio;
      }
      
      // 再检查高度是否超过可用页面高度
      if (calculatedHeight > availablePageHeight) {
        // 图片高度超过可用页面高度，按高度缩放
        calculatedHeight = availablePageHeight;
        calculatedWidth = availablePageHeight * aspectRatio;
        
        // 如果按高度缩放后宽度超过容器，再次按宽度缩放
        if (calculatedWidth > containerWidth) {
          calculatedWidth = containerWidth;
          calculatedHeight = containerWidth / aspectRatio;
        }
      }
      
      imgWidth = calculatedWidth;
      imgHeight = calculatedHeight;
      
      // 使用实际渲染尺寸验证（可能受CSS影响）
      const renderedHeight = Math.max(updatedElementRect.height, imgRect.height);
      if (renderedHeight > 0 && Math.abs(renderedHeight - imgHeight) / imgHeight < 0.2) {
        // 渲染尺寸与计算尺寸接近（允许20%误差），使用渲染尺寸
        imgHeight = renderedHeight;
        imgWidth = renderedHeight * aspectRatio;
      }
    } else {
      // 图片未加载，使用当前渲染尺寸或估算
      imgHeight = Math.max(updatedElementRect.height, imgRect.height);
      if (imgHeight <= 0) {
        // 如果还没有尺寸，使用默认估算（不超过页面尺寸）
        imgHeight = Math.min(containerWidth, availablePageHeight, 400);
      } else {
        // 如果渲染高度超过可用页面高度，需要缩小
        if (imgHeight > availablePageHeight) {
          imgHeight = availablePageHeight;
        }
      }
    }
    
    // 确保图片尺寸不超过容器限制
    if (imgWidth > containerWidth) {
      const scale = containerWidth / imgWidth;
      imgWidth = containerWidth;
      imgHeight = imgHeight * scale;
    }
    if (imgHeight > availablePageHeight) {
      const scale = availablePageHeight / imgHeight;
      imgHeight = availablePageHeight;
      imgWidth = imgWidth * scale;
    }
    
    // 计算最终位置
    const finalTop = updatedElementRect.top - wrapperTop - margin;
    
    if (imgHeight > 0) {
      lines.push({
        element,
        elementIndex,
        lineNumber: this.allLines.length,
        text: '', // 图片没有文本
        top: finalTop,
        height: imgHeight,
        isFirstLineOfElement: true,
        isLastLineOfElement: true,
        isImage: true, // 标记为图片
        imageHeight: imgHeight, // 保存图片高度
      });
    }
    
    // 恢复原始样式
    element.style.display = originalDisplay;
    element.style.visibility = originalVisibility;
    element.style.opacity = originalOpacity;
    
    return lines;
  }

  /**
   * 从元素中获取所有行的位置信息
   * 使用 Range API 和 getClientRects 来精确测量每一行
   */
  private getLinesFromElement(
    element: HTMLElement,
    textNodes: Node[],
    wrapperTop: number,
    margin: number
  ): LineInfo[] {
    const lines: LineInfo[] = [];
    const elementIndex = parseInt(element.getAttribute('data-pagination-index') || '0');

    if (textNodes.length === 0) {
      return lines;
    }

    // 创建 Range 来选择整个元素的内容
    const range = document.createRange();
    range.selectNodeContents(element);
    
    // 获取所有行的 rects
    const rects = range.getClientRects();
    
    if (rects.length === 0) {
      // 如果没有 rects，使用元素的整体信息
      const text = element.textContent || '';
      if (text.trim().length > 0) {
        const elementRect = element.getBoundingClientRect();
        lines.push({
          element,
          elementIndex,
          lineNumber: this.allLines.length,
          text: text.trim(),
          top: elementRect.top - wrapperTop - margin,
          height: elementRect.height || (this.options.fontSize * this.options.lineHeight),
          isFirstLineOfElement: true,
          isLastLineOfElement: true,
        });
      }
      return lines;
    }

    // 按 Y 坐标分组 rects（同一行的 rects 有相同的 top）
    const lineMap = new Map<number, { rects: DOMRect[] }>();
    
    if (rects.length === 0) {
      return lines;
    }
    
    for (let i = 0; i < rects.length; i++) {
      const rect = rects[i];
      const top = Math.round(rect.top * 10) / 10; // 保留一位小数，避免浮点误差
      
      if (!lineMap.has(top)) {
        lineMap.set(top, { rects: [] });
      }
      lineMap.get(top)!.rects.push(rect);
    }
    
    // 使用 Range API 精确获取每一行的文本
    // 方法：逐字符遍历，检测换行，然后为每一行创建 Range 获取实际文本
    const sortedTops = Array.from(lineMap.keys()).sort((a, b) => a - b);
    
    // 为每一行创建 Range 来获取实际文本
    let currentCharIndex = 0;
    const fullText = element.textContent || '';
    
    for (let i = 0; i < sortedTops.length; i++) {
      const top = sortedTops[i];
      const lineData = lineMap.get(top)!;
      const firstRect = lineData.rects[0];
      
      // 找到这一行的起始和结束字符位置
      let lineStartIndex = currentCharIndex;
      let lineEndIndex = currentCharIndex;
      
      // 从当前位置开始，逐字符检测，找到这一行的结束位置
      for (let charIdx = currentCharIndex; charIdx < fullText.length; charIdx++) {
        // 找到包含这个字符的文本节点
        let nodeOffset = 0;
        let foundNode: Node | null = null;
        let nodeCharIndex = 0;
        
        for (const textNode of textNodes) {
          const nodeText = textNode.textContent || '';
          if (charIdx >= nodeOffset && charIdx < nodeOffset + nodeText.length) {
            foundNode = textNode;
            nodeCharIndex = charIdx - nodeOffset;
            break;
          }
          nodeOffset += nodeText.length;
        }
        
        if (!foundNode) break;
        
        // 创建 Range 到这个字符
        const charRange = document.createRange();
        charRange.setStart(foundNode, nodeCharIndex);
        charRange.setEnd(foundNode, nodeCharIndex + 1);
        
        const charRects = charRange.getClientRects();
        if (charRects.length === 0) {
          lineEndIndex = charIdx + 1;
          continue;
        }
        
        const charTop = Math.round(charRects[0].top * 10) / 10;
        
        // 如果字符的 top 不等于当前行的 top，说明换行了
        if (charTop !== top) {
          break;
        }
        
        lineEndIndex = charIdx + 1;
      }
      
      // 获取这一行的文本（保留原始格式，不 trim）
      const lineText = fullText.substring(lineStartIndex, lineEndIndex);
      
      if (lineText.trim().length > 0) {
        lines.push({
          element,
          elementIndex,
          lineNumber: this.allLines.length + lines.length,
          text: lineText, // 保留原始文本，包括可能的空格
          top: firstRect.top - wrapperTop - margin,
          height: firstRect.height,
          isFirstLineOfElement: i === 0,
          isLastLineOfElement: i === sortedTops.length - 1,
        });
      }
      
      // 移动到下一行的起始位置
      currentCharIndex = lineEndIndex;
    }


    return lines;
  }

  /**
   * 根据行的实际位置来分页
   * 确保底部内容不被遮挡，并保证每页有足够的内容
   */
  private calculatePagesByPosition(): void {
    if (this.allLines.length === 0) {
      return;
    }

    const pages: Page[] = [];
    const margin = this.options.margin;
    
    // 使用实际页面高度（已经减去了所有 padding 和安全边距）
    // 再减去上下边距，得到内容区域的实际高度
    const contentHeight = this.pageHeight - (margin * 2);
    
    // 额外行安全边距：确保最后一行不被遮挡
    // 上边距：2px，防止第一行被遮挡
    // 下边距：6px，防止最后一行被遮挡（考虑行高变化）
    const topLineSafetyMargin = 2;
    const bottomLineSafetyMargin = 10; // 增加底部安全边距，确保内容不被遮挡
    const availableHeight = contentHeight - topLineSafetyMargin - bottomLineSafetyMargin;
    
    // 最小行数：确保每页至少有3行内容（避免页面内容过少）
    const minLinesPerPage = 3;
    
    // 起始位置考虑上安全边距
    let currentPageTop = margin + topLineSafetyMargin;
    let currentPageLines: LineInfo[] = [];
    let pageIndex = 0;

    console.log(`[EPUBPage] 分页计算: 页面高度=${this.pageHeight}px, 边距=${margin * 2}px, 内容高度=${contentHeight}px, 上行安全边距=${topLineSafetyMargin}px, 下行安全边距=${bottomLineSafetyMargin}px, 可用高度=${availableHeight}px, 最小行数=${minLinesPerPage}`);

    for (let i = 0; i < this.allLines.length; i++) {
      const line = this.allLines[i];
      const lineBottom = line.top + line.height;
      // 页面底部位置 = 当前页顶部 + 可用高度（已包含安全边距）
      const pageBottom = currentPageTop + availableHeight;

      // 检查是否是图片元素
      const isImage = line.isImage || false;
      
      // 图片特殊处理：图片作为不可分割单元
      if (isImage) {
        const imageHeight = line.height;
        const imageTop = line.top;
        const imageBottom = lineBottom;
        
        // 计算图片在当前页的剩余空间
        const remainingSpace = pageBottom - imageTop;
        
        // 检查图片是否超过页面高度
        if (imageHeight > availableHeight) {
          // 大图片独占一页
          // 先保存当前页（如果有内容）
          if (currentPageLines.length > 0) {
            const startElementIndex = currentPageLines[0]?.elementIndex ?? 0;
            const endElementIndex = currentPageLines[currentPageLines.length - 1]?.elementIndex ?? 0;

            pages.push({
              index: pageIndex++,
              startElementIndex,
              endElementIndex,
              elements: this.getUniqueElements(currentPageLines),
              startLine: currentPageLines[0]?.lineNumber ?? 0,
              endLine: currentPageLines[currentPageLines.length - 1]?.lineNumber ?? 0,
              lines: [...currentPageLines]
            });
          }
          
          // 大图片独占一页
          pages.push({
            index: pageIndex++,
            startElementIndex: line.elementIndex,
            endElementIndex: line.elementIndex,
            elements: [line.element],
            startLine: line.lineNumber,
            endLine: line.lineNumber,
            lines: [line]
          });
          
          // 开始新页
          currentPageTop = imageBottom;
          currentPageLines = [];
          continue;
        }
        
        // 检查图片是否能完整放在当前页
        // 条件：图片顶部在当前页范围内，且图片底部不超过页面底部
        const imageStartsInPage = imageTop >= currentPageTop && imageTop < pageBottom;
        const imageFitsInPage = imageStartsInPage && imageBottom <= pageBottom;
        
        if (!imageFitsInPage) {
          // 图片在当前页放不下，移到下一页
          // 先保存当前页（如果有内容）
          if (currentPageLines.length > 0) {
            const startElementIndex = currentPageLines[0]?.elementIndex ?? 0;
            const endElementIndex = currentPageLines[currentPageLines.length - 1]?.elementIndex ?? 0;

            pages.push({
              index: pageIndex++,
              startElementIndex,
              endElementIndex,
              elements: this.getUniqueElements(currentPageLines),
              startLine: currentPageLines[0]?.lineNumber ?? 0,
              endLine: currentPageLines[currentPageLines.length - 1]?.lineNumber ?? 0,
              lines: [...currentPageLines]
            });
          }
          
          // 图片作为新页的第一行
          currentPageTop = imageTop;
          currentPageLines = [line];
          continue;
        }
        
        // 图片可以放在当前页，继续处理
      }

      // 检查这一行是否会超出当前页
      // 使用 lineBottom 而不是 line.top，确保整行都在页面内
      const wouldExceedPage = lineBottom > pageBottom;
      
      // 如果这一行会超出当前页，且当前页已经有足够的内容，则创建新页
      // 如果当前页行数少于最小行数，尝试继续添加（除非是最后一行）
      const hasEnoughLines = currentPageLines.length >= minLinesPerPage;
      const isLastLine = i === this.allLines.length - 1;
      
      if (wouldExceedPage && hasEnoughLines && currentPageLines.length > 0) {
        // 创建当前页
        const startElementIndex = currentPageLines[0]?.elementIndex ?? 0;
        const endElementIndex = currentPageLines[currentPageLines.length - 1]?.elementIndex ?? 0;

        pages.push({
          index: pageIndex++,
          startElementIndex,
          endElementIndex,
          elements: this.getUniqueElements(currentPageLines),
          startLine: currentPageLines[0]?.lineNumber ?? 0,
          endLine: currentPageLines[currentPageLines.length - 1]?.lineNumber ?? 0,
          lines: [...currentPageLines]
        });

        // 开始新页（当前行作为新页的第一行）
        currentPageTop = line.top;
        currentPageLines = [line];
      } else if (wouldExceedPage && !hasEnoughLines && !isLastLine) {
        // 当前页行数不足，但这一行会超出页面
        // 检查是否可以调整：如果下一行不会超出太多，可以继续添加
        const nextLine = i < this.allLines.length - 1 ? this.allLines[i + 1] : null;
        const canFitMore = nextLine && (nextLine.top - currentPageTop) < availableHeight * 1.1; // 允许10%的溢出
        
        if (canFitMore) {
          // 继续添加到当前页（允许轻微溢出）
          const isDuplicate = currentPageLines.some(l => 
            l.lineNumber === line.lineNumber && 
            l.elementIndex === line.elementIndex &&
            l.top === line.top
          );
          
          if (!isDuplicate) {
            currentPageLines.push(line);
          }
        } else {
          // 无法继续添加，创建新页
          if (currentPageLines.length > 0) {
            const startElementIndex = currentPageLines[0]?.elementIndex ?? 0;
            const endElementIndex = currentPageLines[currentPageLines.length - 1]?.elementIndex ?? 0;

            pages.push({
              index: pageIndex++,
              startElementIndex,
              endElementIndex,
              elements: this.getUniqueElements(currentPageLines),
              startLine: currentPageLines[0]?.lineNumber ?? 0,
              endLine: currentPageLines[currentPageLines.length - 1]?.lineNumber ?? 0,
              lines: [...currentPageLines]
            });
          }
          
          // 开始新页
          currentPageTop = line.top;
          currentPageLines = [line];
        }
      } else {
        // 添加到当前页
        // 检查是否已经添加过（防止重复）
        const isDuplicate = currentPageLines.some(l => 
          l.lineNumber === line.lineNumber && 
          l.elementIndex === line.elementIndex &&
          l.top === line.top
        );
        
        if (!isDuplicate) {
          currentPageLines.push(line);
        } else {
          console.warn(`[EPUBPage] 检测到重复行，跳过: lineNumber=${line.lineNumber}, elementIndex=${line.elementIndex}, top=${line.top}`);
        }
      }
    }

    // 添加最后一页
    if (currentPageLines.length > 0) {
      const startElementIndex = currentPageLines[0]?.elementIndex ?? 0;
      const endElementIndex = currentPageLines[currentPageLines.length - 1]?.elementIndex ?? 0;

      pages.push({
        index: pageIndex,
        startElementIndex,
        endElementIndex,
        elements: this.getUniqueElements(currentPageLines),
        startLine: currentPageLines[0]?.lineNumber ?? 0,
        endLine: currentPageLines[currentPageLines.length - 1]?.lineNumber ?? 0,
        lines: [...currentPageLines]
      });
    }

    // 验证：确保所有行都被分页
    let totalLinesInPages = 0;
    for (const page of pages) {
      totalLinesInPages += page.lines.length;
    }

    if (totalLinesInPages !== this.allLines.length) {
      console.error(`[EPUBPage] 分页验证失败: 总行数=${this.allLines.length}, 分页后=${totalLinesInPages}`);
    } else {
      console.log(`[EPUBPage] 分页验证通过: 总行数=${this.allLines.length}, 共${pages.length}页`);
    }

    this.pages = pages;
  }

  /**
   * 从行信息中获取唯一的元素列表
   */
  private getUniqueElements(lines: LineInfo[]): HTMLElement[] {
    const elementMap = new Map<number, HTMLElement>();
    for (const line of lines) {
      if (!elementMap.has(line.elementIndex)) {
        elementMap.set(line.elementIndex, line.element);
      }
    }
    return Array.from(elementMap.values());
  }

  getCurrentPage(): Page | null {
    if (this.pages.length === 0) return null;
    return this.pages[this.currentPageIndex] || null;
  }

  getTotalPages(): number {
    return this.pages.length;
  }

  getCurrentPageIndex(): number {
    return this.currentPageIndex;
  }

  setCurrentPageIndex(index: number): void {
    if (index >= 0 && index < this.pages.length) {
      this.currentPageIndex = index;
    }
  }

  /**
   * 跳转到指定页面
   */
  goToPage(pageIndex: number): boolean {
    if (pageIndex >= 0 && pageIndex < this.pages.length) {
      this.currentPageIndex = pageIndex;
      return true;
    }
    return false;
  }

  /**
   * 获取指定索引的页面
   */
  getPage(pageIndex: number): Page | null {
    if (pageIndex >= 0 && pageIndex < this.pages.length) {
      return this.pages[pageIndex];
    }
    return null;
  }

  /**
   * 下一页
   */
  nextPage(): boolean {
    if (this.currentPageIndex < this.pages.length - 1) {
      this.currentPageIndex++;
      return true;
    }
    return false;
  }

  /**
   * 上一页
   */
  prevPage(): boolean {
    if (this.currentPageIndex > 0) {
      this.currentPageIndex--;
      return true;
    }
    return false;
  }
}

