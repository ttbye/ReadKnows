/**
 * EPUB 视图渲染器 - 完整功能版本
 * 支持CSS、字体、主题、响应式布局、动画效果
 */

import { Chapter } from './EPUBBook';
import { Page } from './EPUBPaginator';

export class EPUBView {
  private container: HTMLElement;
  private contentElement: HTMLElement;
  private book: any; // EPUBBook引用
  private currentTheme: string = 'light';
  private totalPages: number = 0; // 总页数

  constructor(container: HTMLElement, book: any) {
    this.container = container;
    this.book = book;
    
    // 检查是否已存在 epub-view 容器，避免重复创建
    let existingView = container.querySelector('.epub-view') as HTMLElement;
    if (existingView) {
      console.warn('[EPUBView] 发现已存在的 epub-view 容器，复用它');
      this.contentElement = existingView;
    } else {
      // 创建内容容器
      this.contentElement = document.createElement('div');
      this.contentElement.className = 'epub-view';
      this.contentElement.style.cssText = `
        width: 100%;
        height: 100%;
        overflow: hidden;
        position: relative;
        background: #fff;
        color: #333;
      `;
      
      container.appendChild(this.contentElement);
    }
  }

  /**
   * 渲染章节
   */
  async renderChapter(chapter: Chapter): Promise<void> {
    // 清空内容（避免重复容器）
    // 先移除所有已存在的 chapter-wrapper
    const existingWrappers = this.contentElement.querySelectorAll('.chapter-wrapper');
    existingWrappers.forEach(wrapper => wrapper.remove());
    
    // 清空内容元素（但保留样式元素）
    const styleElements = this.contentElement.querySelectorAll('style');
    this.contentElement.innerHTML = '';
    
    // 恢复样式元素
    styleElements.forEach(style => {
      this.contentElement.appendChild(style);
    });

    // 创建章节包装器
    const wrapper = document.createElement('div');
    wrapper.className = 'chapter-wrapper';
    wrapper.style.cssText = `
      width: 100%;
      min-height: 100%;
      padding: 20px;
      box-sizing: border-box;
      position: relative;
    `;

    // 注入CSS
    let html = chapter.html;
    
    // 添加外部CSS
    if (chapter.cssLinks.length > 0) {
      const cssLinksHtml = chapter.cssLinks
        .map(href => {
          const blobUrl = this.book.getCSSBlobURL(href);
          return blobUrl ? `<link rel="stylesheet" href="${blobUrl}">` : '';
        })
        .filter(Boolean)
        .join('\n');
      
      if (cssLinksHtml) {
        if (!html.includes('<head>')) {
          html = `<head>${cssLinksHtml}</head><body>${html}</body>`;
        } else {
          html = html.replace(/<head[^>]*>/i, `<head>${cssLinksHtml}`);
        }
      }
    }

    // 添加内联样式
    if (chapter.inlineStyles.length > 0) {
      const inlineStylesHtml = `<style>${chapter.inlineStyles.join('\n')}</style>`;
      if (html.includes('<head>')) {
        html = html.replace(/<head[^>]*>/i, `<head>${inlineStylesHtml}`);
      } else {
        html = `<head>${inlineStylesHtml}</head><body>${html}</body>`;
      }
    }

    // 添加图片居中样式
    const imageCenterStyle = `
      <style>
        /* 图片居中显示 */
        /* 图片居中显示，保持宽高比不变形，根据页面尺寸适当缩小 */
        .chapter-wrapper img,
        .chapter-wrapper figure {
          display: block !important;
          margin-left: auto !important;
          margin-right: auto !important;
          max-width: 100% !important;
          width: auto !important;
          height: auto !important;
          object-fit: contain !important;
          object-position: center !important;
        }
        .chapter-wrapper figure {
          text-align: center !important;
        }
        .chapter-wrapper figure img {
          display: block !important;
          margin-left: auto !important;
          margin-right: auto !important;
          max-width: 100% !important;
          width: auto !important;
          height: auto !important;
          object-fit: contain !important;
          object-position: center !important;
        }
      </style>
    `;
    
    if (html.includes('<head>')) {
      html = html.replace(/<head[^>]*>/i, `<head>${imageCenterStyle}`);
    } else {
      html = `<head>${imageCenterStyle}</head><body>${html}</body>`;
    }

    wrapper.innerHTML = html;
    this.contentElement.appendChild(wrapper);

    // 等待DOM更新
    await new Promise(resolve => {
      requestAnimationFrame(() => {
        requestAnimationFrame(resolve);
      });
    });
  }

  /**
   * 设置总页数
   */
  setTotalPages(totalPages: number): void {
    this.totalPages = totalPages;
  }

  /**
   * 获取总页数
   */
  getTotalPages(): number {
    return this.totalPages;
  }

  /**
   * 渲染页面（带动画效果）
   */
  async renderPage(page: Page, direction: 'forward' | 'backward' = 'forward'): Promise<void> {
    // 确保只有一个 chapter-wrapper
    const wrappers = this.contentElement.querySelectorAll('.chapter-wrapper');
    if (wrappers.length > 1) {
      console.warn(`[EPUBView] 发现 ${wrappers.length} 个 chapter-wrapper，移除多余的`);
      // 保留第一个，移除其他的
      for (let i = 1; i < wrappers.length; i++) {
        wrappers[i].remove();
      }
    }
    
    const wrapper = this.contentElement.querySelector('.chapter-wrapper') as HTMLElement;
    if (!wrapper) {
      console.warn('[EPUBView] 未找到 chapter-wrapper');
      return;
    }

    // 清理之前创建的片段元素（只删除片段，不删除原始元素）
    const oldFragments = wrapper.querySelectorAll('[data-page-fragment="true"]');
    oldFragments.forEach(fragment => {
      // 确保只删除片段元素，不删除原始元素
      if (fragment.hasAttribute('data-page-fragment')) {
        fragment.remove();
      }
    });

    // 获取所有带分页索引的原始元素（不包括片段）
    // 按索引排序，确保顺序正确
    const allElements = Array.from(
      wrapper.querySelectorAll('[data-pagination-index]:not([data-page-fragment])')
    ) as HTMLElement[];
    
    // 按分页索引排序，确保元素顺序正确
    allElements.sort((a, b) => {
      const indexA = parseInt(a.getAttribute('data-pagination-index') || '0', 10);
      const indexB = parseInt(b.getAttribute('data-pagination-index') || '0', 10);
      return indexA - indexB;
    });
    
    // 恢复所有原始元素的显示状态（清除之前的隐藏状态）
    allElements.forEach(el => {
      // 只处理原始元素，不处理片段
      if (!el.hasAttribute('data-page-fragment')) {
        // 清除之前的样式，让元素恢复默认状态
        el.style.removeProperty('display');
        el.style.removeProperty('visibility');
        el.style.removeProperty('opacity');
      }
    });

    // 先获取要显示的元素列表，然后再隐藏其他元素
    // 这样可以避免先隐藏后显示导致的闪烁问题

    // 显示当前页的元素
    // 如果有行信息，使用行信息精确渲染（支持段落跨页）
    let elementsToShow: HTMLElement[] = [];
    
    if ((page as any).lines && Array.isArray((page as any).lines) && (page as any).lines.length > 0) {
      // 使用行信息渲染（支持段落跨页）
      elementsToShow = this.renderPageByLines(page, wrapper, allElements);
    } else if (page.elements.length > 0) {
      // 使用元素引用（向后兼容）
      elementsToShow = page.elements.filter(el => {
        return el.parentElement && wrapper.contains(el);
      });
      
      if (elementsToShow.length === 0) {
        console.warn('[EPUBView] page.elements 引用失效，使用索引查找');
        if (page.startElementIndex !== undefined && page.endElementIndex !== undefined && 
            page.startElementIndex >= 0 && page.endElementIndex >= 0) {
          const startIdx = Math.max(0, page.startElementIndex);
          const endIdx = Math.min(allElements.length - 1, page.endElementIndex);
          elementsToShow = allElements.slice(startIdx, endIdx + 1);
        }
      }
    } else if (page.startElementIndex !== undefined && page.endElementIndex !== undefined && 
               page.startElementIndex >= 0 && page.endElementIndex >= 0) {
      const startIdx = Math.max(0, page.startElementIndex);
      const endIdx = Math.min(allElements.length - 1, page.endElementIndex);
      elementsToShow = allElements.slice(startIdx, endIdx + 1);
    } else {
      console.warn('[EPUBView] 没有可用的元素信息，显示所有元素');
      elementsToShow = allElements;
    }

    if (elementsToShow.length === 0) {
      console.error('[EPUBView] 未找到要显示的元素！', {
        pageIndex: page.index,
        startElementIndex: page.startElementIndex,
        endElementIndex: page.endElementIndex,
        elementsCount: page.elements.length,
        allElementsCount: allElements.length,
      });
      return;
    }

    // 创建要显示元素的 Set，用于快速查找
    const elementsToShowSet = new Set<HTMLElement>(elementsToShow);
    
    // 隐藏所有不在当前页的元素（只隐藏原始元素，不隐藏片段）
    allElements.forEach(el => {
      // 确保只隐藏原始元素，不隐藏片段
      if (!el.hasAttribute('data-page-fragment') && !elementsToShowSet.has(el)) {
        el.style.setProperty('display', 'none', 'important');
        el.style.setProperty('visibility', 'hidden', 'important');
        el.style.setProperty('opacity', '0', 'important');
      }
    });

    // 收集并输出当前页面的所有文字内容
    this.logPageTextContentDirect(page, elementsToShow);

    console.log(`[EPUBView] 准备显示 ${elementsToShow.length} 个元素`);

    // 应用淡入动画
    for (const element of elementsToShow) {
      // 检查是否是分片元素（可能还没有插入到 DOM）
      const isFragment = element.hasAttribute('data-page-fragment');
      
      // 如果是分片元素且还没有插入到 DOM，需要插入
      if (isFragment && !element.parentElement) {
        const originalIndex = parseInt(element.getAttribute('data-original-element-index') || '-1', 10);
        let insertAfter: Node | null = null;
        
        // 找到原始元素的位置
        if (originalIndex >= 0 && originalIndex < allOriginalElements.length) {
          const originalElement = allOriginalElements[originalIndex];
          insertAfter = originalElement;
        } else {
          // 如果找不到原始元素，找到最后一个已插入的元素
          const existingElements = wrapper.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, blockquote, [data-page-fragment="true"]');
          if (existingElements.length > 0) {
            insertAfter = existingElements[existingElements.length - 1];
          } else {
            insertAfter = wrapper.firstChild;
          }
        }
        
        // 插入分片元素
        if (insertAfter && insertAfter.parentElement) {
          insertAfter.parentElement.insertBefore(element, insertAfter.nextSibling);
        } else if (wrapper) {
          wrapper.appendChild(element);
        }
      }
      
      if (!element.parentElement && !isFragment) {
        console.warn('[EPUBView] 元素没有父元素，跳过', element);
        continue;
      }

      // 确保父元素可见（使用 important 确保优先级）
      let parent = element.parentElement;
      while (parent && parent !== wrapper) {
        const parentStyle = window.getComputedStyle(parent);
        if (parentStyle.display === 'none' || parentStyle.visibility === 'hidden') {
          parent.style.setProperty('display', 'block', 'important');
          parent.style.setProperty('visibility', 'visible', 'important');
          parent.style.setProperty('opacity', '1', 'important');
        }
        parent = parent.parentElement;
      }
      
      // 确保 wrapper 本身也是可见的
      if (wrapper) {
        const wrapperStyle = window.getComputedStyle(wrapper);
        if (wrapperStyle.display === 'none' || wrapperStyle.visibility === 'hidden') {
          wrapper.style.setProperty('display', 'block', 'important');
          wrapper.style.setProperty('visibility', 'visible', 'important');
        }
      }

      // 显示元素 - 使用 setProperty 和 important 确保样式优先级
      const tagName = element.tagName.toLowerCase();
      const isImage = tagName === 'img' || tagName === 'figure' || element.querySelector('img') !== null;
      
      let display = 'block';
      if (['span', 'em', 'strong', 'i', 'b', 'u', 'a'].includes(tagName)) {
        display = 'inline';
      } else if (isImage) {
        // 图片元素：确保正确显示并居中
        display = 'block';
        
        // 图片容器居中
        element.style.setProperty('text-align', 'center', 'important');
        element.style.setProperty('margin-left', 'auto', 'important');
        element.style.setProperty('margin-right', 'auto', 'important');
        
        // 确保图片本身也可见
        const img = tagName === 'img' 
          ? element as HTMLImageElement 
          : element.querySelector('img') as HTMLImageElement;
        if (img) {
          img.style.setProperty('display', 'block', 'important');
          img.style.setProperty('visibility', 'visible', 'important');
          img.style.setProperty('opacity', '1', 'important');
          img.style.setProperty('max-width', '100%', 'important');
          img.style.setProperty('height', 'auto', 'important');
          img.style.setProperty('object-fit', 'contain', 'important');
          img.style.setProperty('margin-left', 'auto', 'important');
          img.style.setProperty('margin-right', 'auto', 'important');
        }
      }

      // 使用 setProperty 和 important 确保样式优先级最高
      element.style.setProperty('display', display, 'important');
      element.style.setProperty('visibility', 'visible', 'important');
      
      // 对于可能超过页面高度的文本元素，确保内容完整显示
      if (['p', 'div', 'pre', 'blockquote', 'li'].includes(tagName)) {
        element.style.setProperty('overflow', 'visible', 'important');
        element.style.setProperty('max-height', 'none', 'important');
        element.style.setProperty('height', 'auto', 'important');
        element.style.setProperty('text-overflow', 'clip', 'important');
        element.style.setProperty('white-space', 'normal', 'important');
      }
      
      // 图片元素特殊处理：确保完整显示并居中
      if (isImage) {
        element.style.setProperty('overflow', 'visible', 'important');
        element.style.setProperty('max-height', 'none', 'important');
        element.style.setProperty('text-align', 'center', 'important');
        element.style.setProperty('margin-left', 'auto', 'important');
        element.style.setProperty('margin-right', 'auto', 'important');
        
        // 确保图片容器也正确显示
        const img = tagName === 'img' 
          ? element as HTMLImageElement 
          : element.querySelector('img') as HTMLImageElement;
        if (img) {
          // 获取容器尺寸，计算最大显示尺寸
          const container = this.contentElement;
          const containerWidth = container.clientWidth || container.getBoundingClientRect().width;
          const containerHeight = container.clientHeight || container.getBoundingClientRect().height;
          const margin = 20; // 边距
          const maxWidth = containerWidth - (margin * 2);
          const maxHeight = containerHeight - (margin * 2) - 12; // 减去安全边距
          
          img.style.setProperty('display', 'block', 'important');
          img.style.setProperty('max-width', `${maxWidth}px`, 'important');
          img.style.setProperty('max-height', `${maxHeight}px`, 'important');
          img.style.setProperty('width', 'auto', 'important');
          img.style.setProperty('height', 'auto', 'important');
          img.style.setProperty('object-fit', 'contain', 'important');
          img.style.setProperty('object-position', 'center', 'important');
          img.style.setProperty('margin-left', 'auto', 'important');
          img.style.setProperty('margin-right', 'auto', 'important');
        }
      }
      
      // 淡入动画（使用双重 requestAnimationFrame 确保动画执行）
      // 先立即设置 opacity 为 0，然后通过动画过渡到 1
      element.style.setProperty('opacity', '0', 'important');
      element.style.setProperty('transition', 'opacity 0.2s ease-in', 'important');
      
      // 使用 setTimeout 确保在下一帧设置 opacity 为 1
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          // 确保元素最终可见
          element.style.setProperty('opacity', '1', 'important');
          
          // 双重保险：如果动画失败，300ms 后强制设置为可见
          setTimeout(() => {
            const computedOpacity = window.getComputedStyle(element).opacity;
            if (computedOpacity !== '1' && parseFloat(computedOpacity) < 0.9) {
              console.warn(`[EPUBView] 元素淡入动画可能失败，强制设置为可见: opacity=${computedOpacity}, element=`, element);
              element.style.setProperty('opacity', '1', 'important');
              element.style.setProperty('visibility', 'visible', 'important');
              element.style.setProperty('display', display, 'important');
            }
          }, 300);
        });
      });
    }

    // 滚动到顶部
    this.contentElement.scrollTop = 0;
  }

  /**
   * 按行信息渲染页面（支持段落跨页）
   * 这是核心渲染方法：根据行的信息，为每个元素创建对应的片段
   */
  private renderPageByLines(page: Page, wrapper: HTMLElement, allElements: HTMLElement[]): HTMLElement[] {
    const lines = (page as any).lines as Array<{
      element: HTMLElement;
      elementIndex: number;
      lineNumber: number;
      text: string;
      height: number;
      isFirstLineOfElement?: boolean;
      isLastLineOfElement?: boolean;
    }>;
    
    if (!lines || lines.length === 0) {
      console.warn('[EPUBView] 页面没有行信息');
      return [];
    }
    
    // 按元素分组行信息，并保持原始顺序（按elementIndex排序）
    const elementLinesMap = new Map<number, typeof lines>();
    
    for (const line of lines) {
      if (!elementLinesMap.has(line.elementIndex)) {
        elementLinesMap.set(line.elementIndex, []);
      }
      elementLinesMap.get(line.elementIndex)!.push(line);
    }
    
    // 按elementIndex排序，确保元素顺序正确
    const elementOrder = Array.from(elementLinesMap.keys()).sort((a, b) => a - b);
    
    const elementsToShow: HTMLElement[] = [];
    
    // 按原始顺序处理每个元素
    for (const elementIndex of elementOrder) {
      const elementLines = elementLinesMap.get(elementIndex);
      if (!elementLines || elementLines.length === 0) continue;
      
      // 对同一元素的行按lineNumber排序，确保顺序正确
      elementLines.sort((a, b) => a.lineNumber - b.lineNumber);
      let originalElement = elementLines[0].element;
      
      // 检查元素是否还在DOM中，如果不在，尝试通过索引查找
      if (!originalElement.parentElement || !wrapper.contains(originalElement)) {
        // 元素引用失效，尝试通过索引从 allElements 中查找
        if (elementIndex >= 0 && elementIndex < allElements.length) {
          const foundElement = allElements[elementIndex];
          if (foundElement && foundElement.parentElement && wrapper.contains(foundElement)) {
            originalElement = foundElement;
            // 更新行信息中的元素引用
            elementLines.forEach(line => {
              line.element = foundElement;
            });
          } else {
            console.warn(`[EPUBView] 元素 ${elementIndex} 不在DOM中，且无法通过索引找到`);
            continue;
          }
        } else {
          console.warn(`[EPUBView] 元素 ${elementIndex} 不在DOM中，索引无效`);
          continue;
        }
      }
      
      // 检查是否是图片元素
      const tagName = originalElement.tagName.toLowerCase();
      const isImage = tagName === 'img' || tagName === 'figure' || originalElement.querySelector('img') !== null;
      
      if (isImage) {
        // 图片元素直接显示原元素，不创建片段
        // 确保图片元素可见（可能在之前的渲染中被隐藏了）
        originalElement.style.setProperty('display', 'block', 'important');
        originalElement.style.setProperty('visibility', 'visible', 'important');
        originalElement.style.setProperty('opacity', '1', 'important');
        originalElement.style.setProperty('text-align', 'center', 'important');
        originalElement.style.setProperty('margin-left', 'auto', 'important');
        originalElement.style.setProperty('margin-right', 'auto', 'important');
        
        // 确保图片本身也可见并居中
        const img = originalElement.tagName.toLowerCase() === 'img' 
          ? originalElement as HTMLImageElement 
          : originalElement.querySelector('img') as HTMLImageElement;
        if (img) {
          img.style.setProperty('display', 'block', 'important');
          img.style.setProperty('visibility', 'visible', 'important');
          img.style.setProperty('opacity', '1', 'important');
          img.style.setProperty('max-width', '100%', 'important');
          img.style.setProperty('height', 'auto', 'important');
          img.style.setProperty('object-fit', 'contain', 'important');
          img.style.setProperty('margin-left', 'auto', 'important');
          img.style.setProperty('margin-right', 'auto', 'important');
        }
        
        elementsToShow.push(originalElement);
      } else {
        // 文本元素：获取原元素的完整文本
        const originalText = (originalElement.textContent || '').trim();
        
        // 组合当前页应该显示的行文本（保持行的顺序）
        const pageText = elementLines
          .map(l => l.text.trim())
          .filter(t => t.length > 0)
          .join(' ');
        
        // 判断是否需要创建片段
        // 如果当前页显示的是元素的完整内容，直接显示原元素
        const isComplete = pageText === originalText && 
                           elementLines[0]?.isFirstLineOfElement && 
                           elementLines[elementLines.length - 1]?.isLastLineOfElement;
        
        if (isComplete) {
          // 完整显示原元素
          // 确保原元素没有被隐藏（可能在之前的渲染中被隐藏了）
          elementsToShow.push(originalElement);
        } else {
          // 需要创建片段，只显示部分内容
          // 先检查是否已经存在该元素的片段，如果存在则先删除
          const existingFragment = wrapper.querySelector(
            `[data-page-fragment="true"][data-original-element-index="${elementIndex}"]`
          ) as HTMLElement;
          if (existingFragment) {
            existingFragment.remove();
          }
          
          const fragmentElement = this.createElementFragment(originalElement, elementLines);
          if (fragmentElement) {
            // 隐藏原元素（但保留在DOM中）
            originalElement.style.setProperty('display', 'none', 'important');
            originalElement.style.setProperty('visibility', 'hidden', 'important');
            originalElement.style.setProperty('opacity', '0', 'important');
            
            // 插入片段元素（在原元素之后，确保顺序正确）
            // 找到原元素在DOM中的位置
            const parent = originalElement.parentElement;
            if (parent) {
              // 在原元素之后插入
              if (originalElement.nextSibling) {
                parent.insertBefore(fragmentElement, originalElement.nextSibling);
              } else {
                parent.appendChild(fragmentElement);
              }
            } else {
              console.warn(`[EPUBView] 原元素没有父元素，无法插入片段 ${elementIndex}`);
              elementsToShow.push(originalElement);
              continue;
            }
            
            elementsToShow.push(fragmentElement);
          } else {
            // 如果创建片段失败，显示原元素
            console.warn(`[EPUBView] 创建片段失败，显示原元素 ${elementIndex}`);
            elementsToShow.push(originalElement);
          }
        }
      }
    }
    
    console.log(`[EPUBView] 按行渲染: ${elementsToShow.length} 个元素/片段`);
    return elementsToShow;
  }

  /**
   * 创建元素片段（只包含指定行的内容）
   */
  private createElementFragment(
    originalElement: HTMLElement, 
    lines: Array<{ text: string; isFirstLineOfElement?: boolean; isLastLineOfElement?: boolean }>
  ): HTMLElement | null {
    try {
      // 克隆原元素
      const fragment = originalElement.cloneNode(false) as HTMLElement;
      
      // 设置片段标识
      fragment.setAttribute('data-page-fragment', 'true');
      fragment.setAttribute('data-original-element-index', originalElement.getAttribute('data-pagination-index') || '');
      
      // 组合所有行的文本
      // 保持段落内文本的连续性，用空格连接同一段落内的行
      // 但保留行尾原有的空格（如果有），避免丢失格式
      let fragmentText = lines
        .map((l, idx) => {
          const text = l.text;
          if (text.trim().length === 0) return '';
          
          // 如果是最后一行，直接返回（保留原始格式）
          if (idx === lines.length - 1) {
            return text;
          }
          
          // 检查行尾是否有空格
          const endsWithSpace = /\s$/.test(text);
          
          // 如果行尾有空格，直接返回（不添加额外空格）
          if (endsWithSpace) {
            return text;
          }
          
          // 否则，添加一个空格连接下一行（保持段落内文本连续性）
          return text + ' ';
        })
        .filter(t => t.trim().length > 0)
        .join(''); // 直接连接，因为已经在每行末尾处理了空格
      
      // 复制样式
      const computedStyle = window.getComputedStyle(originalElement);
      fragment.style.fontSize = computedStyle.fontSize;
      fragment.style.fontFamily = computedStyle.fontFamily;
      fragment.style.lineHeight = computedStyle.lineHeight;
      fragment.style.color = computedStyle.color;
      fragment.style.margin = computedStyle.margin;
      fragment.style.padding = computedStyle.padding;
      fragment.style.textAlign = computedStyle.textAlign;
      fragment.style.display = computedStyle.display || 'block';
      
      // 处理首行缩进：如果第一行不是元素的第一行，移除首行缩进
      const isFirstLine = lines[0]?.isFirstLineOfElement ?? false;
      const originalTextIndent = computedStyle.textIndent;
      
      if (!isFirstLine && originalTextIndent && originalTextIndent !== '0px') {
        // 不是元素的第一行，移除首行缩进
        fragment.style.textIndent = '0';
      } else {
        // 是元素的第一行，保留原首行缩进
        fragment.style.textIndent = originalTextIndent;
      }
      
      // 设置文本内容
      fragment.textContent = fragmentText;
      
      return fragment;
    } catch (error) {
      console.error('[EPUBView] 创建元素片段失败:', error);
      return null;
    }
  }

  /**
   * 输出当前页面的所有文字内容到控制台
   */
  private logPageTextContent(page: Page, elementsToShow: HTMLElement[]): void {
    this.logPageTextContentDirect(page, elementsToShow);
  }

  /**
   * 直接输出页面文本内容（内部实现）
   */
  private logPageTextContentDirect(page: Page, elementsToShow: HTMLElement[]): void {
    try {
      // 收集所有文本内容
      const textParts: string[] = [];
      
      // 如果有行信息，使用行信息收集文本（更准确）
      if ((page as any).lines && Array.isArray((page as any).lines) && (page as any).lines.length > 0) {
        const lines = (page as any).lines as Array<{ text: string }>;
        for (const line of lines) {
          if (line.text && line.text.trim().length > 0) {
            textParts.push(line.text.trim());
          }
        }
      } else {
        // 从显示的元素中收集文本
        for (const element of elementsToShow) {
          // 跳过片段元素，只收集原始元素或片段的文本
          const text = element.textContent || '';
          if (text.trim().length > 0) {
            textParts.push(text.trim());
          }
        }
      }
      
      // 组合所有文本
      const fullText = textParts.join('\n').trim();
      
      // 输出到控制台
      const totalPages = this.totalPages || (page as any).totalPages || '?';
      console.log(`\n========== 第 ${page.index + 1} 页内容 ==========`);
      console.log(`页码: ${page.index + 1} / ${totalPages}`);
      console.log(`文本行数: ${textParts.length}`);
      console.log(`总字符数: ${fullText.length}`);
      console.log(`\n【页面文字内容】\n${fullText}\n`);
      console.log('==========================================\n');
    } catch (error) {
      console.error('[EPUBView] 输出页面文本内容时出错:', error);
    }
  }

  /**
   * 应用样式设置
   */
  applyStyles(styles: {
    fontSize?: number;
    fontFamily?: string;
    lineHeight?: number;
    theme?: string;
    margin?: number;
  }): void {
    const wrapper = this.contentElement.querySelector('.chapter-wrapper') as HTMLElement;
    if (!wrapper) return;

    let styleElement = this.contentElement.querySelector('#epub-reader-styles') as HTMLStyleElement;
    if (!styleElement) {
      styleElement = document.createElement('style');
      styleElement.id = 'epub-reader-styles';
      this.contentElement.appendChild(styleElement);
    }

    const rules: string[] = [];
    
    if (styles.fontSize) {
      rules.push(`font-size: ${styles.fontSize}px !important;`);
    }
    if (styles.fontFamily) {
      rules.push(`font-family: ${styles.fontFamily} !important;`);
    }
    if (styles.lineHeight) {
      rules.push(`line-height: ${styles.lineHeight} !important;`);
    }
    if (styles.margin !== undefined) {
      rules.push(`padding: ${styles.margin}px !important;`);
    }

    // 应用主题
    if (styles.theme) {
      this.currentTheme = styles.theme;
      const themes: Record<string, { bg: string; color: string }> = {
        light: { bg: '#ffffff', color: '#333333' },
        dark: { bg: '#1a1a1a', color: '#e0e0e0' },
        sepia: { bg: '#f4e8d0', color: '#5c4b37' },
        green: { bg: '#e8f5e9', color: '#2e7d32' },
      };
      
      const colors = themes[styles.theme] || themes.light;
      rules.push(`background-color: ${colors.bg} !important;`);
      rules.push(`color: ${colors.color} !important;`);
      
      // 更新容器背景
      this.contentElement.style.backgroundColor = colors.bg;
      this.contentElement.style.color = colors.color;
    }

    if (rules.length > 0) {
      styleElement.textContent = `
        .chapter-wrapper {
          ${rules.join('\n          ')}
        }
        .chapter-wrapper * {
          ${styles.fontSize ? `font-size: ${styles.fontSize}px !important;` : ''}
          ${styles.fontFamily ? `font-family: ${styles.fontFamily} !important;` : ''}
          ${styles.lineHeight ? `line-height: ${styles.lineHeight} !important;` : ''}
        }
      `;
    }
  }

  /**
   * 获取内容元素
   */
  getContentElement(): HTMLElement {
    return this.contentElement;
  }

  /**
   * 销毁
   */
  destroy(): void {
    if (this.contentElement.parentElement) {
      this.contentElement.parentElement.removeChild(this.contentElement);
    }
  }
}
