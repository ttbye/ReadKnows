/**
 * 全新构建的灵活 EPUB 阅读器
 * 支持多种阅读器引擎和分页方式：
 * - epubjs (分页/滚动)
 * - react-reader (分页/滚动)
 * - custom (自定义解析器，分页/滚动)
 * 
 * 根据用户设置动态选择阅读器引擎和分页方式
 */

import { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { BookData, ReadingSettings, ReadingPosition, TOCItem } from '../../../types/reader';
import api from '../../../utils/api';
import toast from 'react-hot-toast';
import { X } from 'lucide-react';

interface ReaderEPUBProProps {
  book: BookData;
  settings: ReadingSettings;
  initialPosition?: ReadingPosition;
  onSettingsChange: (settings: ReadingSettings) => void;
  onProgressChange: (progress: number, position: ReadingPosition) => void;
  onTOCChange: (toc: TOCItem[]) => void;
  onClose: () => void;
}

// 阅读器引擎类型
type ReaderEngine = 'custom' | 'epubjs' | 'react-reader' | 'readium';

// 分页方式类型
type PaginationMode = 'custom-paginated' | 'custom-scrolled' | 
                     'epubjs-paginated' | 'epubjs-scrolled' |
                     'react-reader-paginated' | 'react-reader-scrolled';

export default function ReaderEPUBPro({
  book,
  settings,
  initialPosition,
  onSettingsChange,
  onProgressChange,
  onTOCChange,
  onClose,
}: ReaderEPUBProProps) {
  // 核心状态
  const containerRef = useRef<HTMLDivElement>(null);
  const epubjsContainerRef = useRef<HTMLDivElement>(null);
  const [epubjsContainerReady, setEpubjsContainerReady] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // 阅读器配置
  const [readerEngine, setReaderEngine] = useState<ReaderEngine>('custom');
  const [paginationMode, setPaginationMode] = useState<PaginationMode>('custom-paginated');
  
  // 阅读器实例引用
  const epubjsBookRef = useRef<any>(null);
  const epubjsRenditionRef = useRef<any>(null);
  const reactReaderRenditionRef = useRef<any>(null);
  const [reactReaderLocation, setReactReaderLocation] = useState<string | number>(
    initialPosition?.currentLocation || 0
  );
  
  // 防抖变量（组件级别，避免每次内容加载时重置）
  const epubjsPageTurnStateRef = useRef<{
    lastPageTurnTime: number;
    isTurningPage: boolean;
  }>({
    lastPageTurnTime: 0,
    isTurningPage: false,
  });
  
  // UI 状态
  const [showTOC, setShowTOC] = useState(false);
  const [toc, setToc] = useState<TOCItem[]>([]);
  
  // 检测设备类型
  const isMobile = useMemo(() => {
    return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent) || window.innerWidth < 768;
  }, []);

  // 获取阅读器偏好设置
  useEffect(() => {
    const fetchReaderPreferences = async () => {
      try {
        const response = await api.get('/reading/preferences');
        const preferences = response.data.preferences || {};
        const epubPrefs = preferences.epub || {};
        
        // 获取阅读器类型
        let engine = (epubPrefs.readerType || 'custom') as ReaderEngine;
        
        // 获取分页方式
        let mode = (epubPrefs.settings?.paginationMode || 'custom-paginated') as PaginationMode;
        
        // 验证并修正配置不匹配的情况
        if (engine === 'epubjs') {
          // epubjs 必须使用 epubjs-* 模式
          if (!mode.startsWith('epubjs-')) {
            console.warn('ReaderEPUBPro: epubjs 引擎配置了不匹配的模式，自动修正', { engine, mode });
            mode = 'epubjs-paginated'; // 默认使用分页模式
          }
        } else if (engine === 'react-reader') {
          // react-reader 必须使用 react-reader-* 模式
          if (!mode.startsWith('react-reader-')) {
            console.warn('ReaderEPUBPro: react-reader 引擎配置了不匹配的模式，自动修正', { engine, mode });
            mode = 'react-reader-paginated';
          }
        } else if (engine === 'custom') {
          // custom 必须使用 custom-* 模式
          if (!mode.startsWith('custom-')) {
            console.warn('ReaderEPUBPro: custom 引擎配置了不匹配的模式，自动修正', { engine, mode });
            mode = 'custom-paginated';
          }
        }
        
        setReaderEngine(engine);
        setPaginationMode(mode);
        
        console.log('ReaderEPUBPro: 加载阅读器配置', { engine, mode });
      } catch (error) {
        console.error('ReaderEPUBPro: 获取阅读器偏好失败', error);
        // 使用默认值
        setReaderEngine('custom');
        setPaginationMode('custom-paginated');
        console.log('ReaderEPUBPro: 使用默认配置', { engine: 'custom', mode: 'custom-paginated' });
      }
    };

    fetchReaderPreferences();
  }, []);

  // 获取文件URL
  const getFileUrl = useCallback(async (): Promise<string | null> => {
    if (!book.file_path && !book.file_name && !book.id) return null;
    
    const ext = book.file_name?.split('.').pop()?.toLowerCase() || 'epub';
    let serverUrl: string;
    
    if (book.id) {
      serverUrl = `/books/${book.id}.${ext}`;
    } else if (book.file_path) {
      if (book.file_path.startsWith('http://') || book.file_path.startsWith('https://') || book.file_path.startsWith('/')) {
        serverUrl = book.file_path;
      } else {
        serverUrl = `/books/${book.file_path}`;
      }
    } else {
      return null;
    }

    // 尝试使用离线存储
    try {
      const { offlineStorage } = await import('../../../utils/offlineStorage');
      if (book.id) {
        const cachedBlob = await offlineStorage.getBook(book.id);
        if (cachedBlob) {
          console.log('ReaderEPUBPro: 使用离线缓存的书籍', { bookId: book.id });
          return offlineStorage.createBlobURL(cachedBlob);
        }
        const blob = await offlineStorage.downloadBook(book.id, ext, serverUrl);
        return offlineStorage.createBlobURL(blob);
      }
    } catch (error) {
      console.warn('ReaderEPUBPro: 离线存储不可用，使用服务器URL', error);
    }

    return serverUrl;
  }, [book.id, book.file_path, book.file_name]);

  // ==================== epubjs 阅读器 ====================
  const initEpubjsReader = useCallback(async (fileUrl: string) => {
    try {
      // 容器应该在 loadReader 中已经准备好了，这里再确认一次
      if (!epubjsContainerRef.current) {
        console.error('ReaderEPUBPro: 容器引用状态', {
          hasRef: !!epubjsContainerRef,
          current: epubjsContainerRef.current,
          readerEngine,
          containerReady: epubjsContainerReady,
        });
        throw new Error('阅读器容器未准备好，请刷新页面重试');
      }

      // 确保容器有尺寸
      const container = epubjsContainerRef.current;
      
      // 如果容器尺寸为0，尝试多次等待
      let retryCount = 0;
      const maxRetries = 10;
      while ((container.offsetWidth === 0 || container.offsetHeight === 0) && retryCount < maxRetries) {
        console.warn(`ReaderEPUBPro: 容器尺寸为0，等待尺寸更新... (${retryCount + 1}/${maxRetries})`, {
          offsetWidth: container.offsetWidth,
          offsetHeight: container.offsetHeight,
          clientWidth: container.clientWidth,
          clientHeight: container.clientHeight,
          parentWidth: container.parentElement?.clientWidth,
          parentHeight: container.parentElement?.clientHeight,
        });
        await new Promise(resolve => setTimeout(resolve, 200));
        retryCount++;
      }
      
      // 如果仍然没有尺寸，使用窗口尺寸
      if (container.offsetWidth === 0 || container.offsetHeight === 0) {
        console.warn('ReaderEPUBPro: 容器尺寸仍为0，使用窗口尺寸');
        container.style.width = `${window.innerWidth}px`;
        container.style.height = `${window.innerHeight - 100}px`;
      }

      const { default: ePub } = await import('epubjs');
      
      // 创建 book 实例
      const bookInstance = ePub(fileUrl, {
        openAs: 'epub',
      });

      epubjsBookRef.current = bookInstance;

      // 等待 book 加载完成
      console.log('ReaderEPUBPro: 等待 book.ready...');
      await bookInstance.ready;
      console.log('ReaderEPUBPro: book.ready 完成');

      // 等待 navigation 加载完成
      console.log('ReaderEPUBPro: 等待 navigation 加载...');
      await bookInstance.loaded.navigation;
      console.log('ReaderEPUBPro: navigation 加载完成');

      // 获取目录（使用 bookInstance.navigation 而不是 bookInstance.loaded.navigation）
      const navigation = bookInstance.navigation;
      console.log('ReaderEPUBPro: 获取目录', {
        hasNavigation: !!navigation,
        tocLength: navigation?.toc?.length || 0,
      });
      
      // 将 TOC 项映射到 spine 索引
      // epubjs 的 spine 索引和 TOC 索引可能不一致，需要通过 href 匹配
      const spine = bookInstance.spine;
      const tocItems: TOCItem[] = (navigation?.toc || []).map((item: any, index: number) => {
        // 通过 href 在 spine 中查找对应的索引
        let spineIndex = -1;
        try {
          const spineItem = spine.get(item.href);
          if (spineItem) {
            spineIndex = spineItem.index;
          } else {
            // 如果直接匹配失败，尝试遍历 spine 查找
            // 注意：spine 可能没有 length 属性，使用 try-catch 处理
            try {
              let i = 0;
              while (true) {
                try {
                  const sItem = spine.get(i);
                  if (sItem && sItem.href === item.href) {
                    spineIndex = i;
                    break;
                  }
                  i++;
                } catch (e) {
                  // 索引超出范围，停止查找
                  break;
                }
              }
            } catch (e) {
              // 忽略错误
            }
          }
        } catch (e) {
          console.warn('ReaderEPUBPro: 查找 spine 索引失败', e);
        }
        
        return {
          id: item.id || `toc-${index}`,
          title: item.label || `目录项 ${index + 1}`,
          href: item.href,
          level: item.level || 1,
          chapterIndex: spineIndex >= 0 ? spineIndex : index, // 使用 spine 索引，如果没有找到则使用 TOC 索引
        };
      });
      setToc(tocItems);
      onTOCChange(tocItems);
      
      console.log('ReaderEPUBPro: 目录设置完成', { tocCount: tocItems.length });

      // 清空容器
      container.innerHTML = '';

      // 使用 getBoundingClientRect 获取准确的容器尺寸
      const containerRect = container.getBoundingClientRect();
      let containerWidth = containerRect.width || container.offsetWidth || container.clientWidth || window.innerWidth;
      let containerHeight = containerRect.height || container.offsetHeight || container.clientHeight;
      
      // 如果容器高度仍然为0或太小，尝试从父元素获取
      if (!containerHeight || containerHeight < 100) {
        const parent = container.parentElement;
        if (parent) {
          const parentRect = parent.getBoundingClientRect();
          const parentHeight = parentRect.height || parent.clientHeight || parent.offsetHeight;
          const parentPaddingTop = parseInt(window.getComputedStyle(parent).paddingTop) || 0;
          containerHeight = parentHeight - parentPaddingTop;
        }
      }
      
      // 如果还是不行，使用窗口高度减去顶部导航栏高度
      if (!containerHeight || containerHeight < 100) {
        containerHeight = window.innerHeight - 100; // 减去顶部导航栏高度
      }
      
      // 确保尺寸是有效的数字，并且合理
      containerWidth = Math.max(containerWidth, 300);
      containerHeight = Math.max(containerHeight, 400);
      
      console.log('ReaderEPUBPro: 容器尺寸计算', {
        rectWidth: containerRect.width,
        rectHeight: containerRect.height,
        offsetWidth: container.offsetWidth,
        offsetHeight: container.offsetHeight,
        clientWidth: container.clientWidth,
        clientHeight: container.clientHeight,
        finalWidth: containerWidth,
        finalHeight: containerHeight,
        parentHeight: container.parentElement?.clientHeight,
        parentPaddingTop: container.parentElement ? window.getComputedStyle(container.parentElement).paddingTop : 'N/A',
      });

      // 确定 flow 模式（如果模式不匹配，使用默认值）
      let flowMode = 'paginated';
      if (paginationMode === 'epubjs-paginated') {
        flowMode = 'paginated';
      } else if (paginationMode === 'epubjs-scrolled') {
        flowMode = 'scrolled';
      } else {
        // 如果模式不匹配（比如 custom-paginated），默认使用 paginated
        console.warn('ReaderEPUBPro: epubjs 模式不匹配，使用默认 paginated 模式', {
          readerEngine,
          paginationMode,
        });
        flowMode = 'paginated';
      }

      console.log('ReaderEPUBPro: 创建 rendition', {
        containerWidth,
        containerHeight,
        flowMode,
        paginationMode,
      });

      // 确保容器样式正确，防止内容偏移
      // 使用百分比而不是固定像素，让容器自适应父元素
      // 注意：不设置 left、top、transform，让 epubjs 自己管理分页布局
      container.style.position = 'relative';
      container.style.overflow = 'hidden';
      container.style.margin = '0';
      container.style.padding = '0';
      // 不设置 left、top、transform，让 epubjs 自己管理
      container.style.width = '100%';
      container.style.height = '100%';
      
      // 创建 rendition
      // 注意：spread: 'none' 确保单页显示，避免双页布局导致的位置问题
      const rendition = bookInstance.renderTo(container, {
        width: containerWidth,
        height: containerHeight,
        flow: flowMode,
        spread: 'none', // 单页模式，避免双页布局
        manager: 'default',
        allowScriptedContent: false,
        // 添加更多配置来确保布局正确
        minSpreadWidth: 0, // 禁用双页布局
      });

      epubjsRenditionRef.current = rendition;

      // 获取当前主题样式
      const currentThemeStyles = {
        light: { bg: '#ffffff', text: '#000000', border: '#e0e0e0' },
        dark: { bg: '#1a1a1a', text: '#ffffff', border: '#404040' },
        sepia: { bg: '#f4e4bc', text: '#5c4b37', border: '#d4c49c' },
        green: { bg: '#c8e6c9', text: '#2e7d32', border: '#a5d6a7' },
      }[settings.theme];

      // 等待 rendition 准备好
      await new Promise(resolve => setTimeout(resolve, 100));

      // 应用主题和样式
      const theme = {
        body: {
          'font-size': `${settings.fontSize}px !important`,
          'line-height': `${settings.lineHeight} !important`,
          'font-family': settings.fontFamily === 'serif' 
            ? '"Songti SC", "SimSun", "宋体", "STSong", serif'
            : '-apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", "WenQuanYi Micro Hei", sans-serif',
          'padding': `${settings.margin}px !important`,
          'text-indent': `${settings.textIndent}em !important`,
          'background-color': currentThemeStyles.bg + ' !important',
          'color': currentThemeStyles.text + ' !important',
          'margin': '0 !important',
          'box-sizing': 'border-box !important',
        },
        'p, div, span, h1, h2, h3, h4, h5, h6, li, td, th': {
          'color': currentThemeStyles.text + ' !important',
        },
      };
      rendition.themes.default(theme);
      
      // 确保分页模式正确设置
      if (flowMode === 'paginated') {
        rendition.flow('paginated');
      } else {
        rendition.flow('scrolled');
      }
      
      console.log('ReaderEPUBPro: 主题和样式已应用', {
        theme: settings.theme,
        fontSize: settings.fontSize,
        fontFamily: settings.fontFamily,
        flowMode,
      });

      // 监听内容加载（必须在 display 之前注册）
      rendition.hooks.content.register((view: any) => {
        const doc = view.document;
        if (!doc) {
          console.warn('ReaderEPUBPro: content hook 触发但 doc 不存在');
          return;
        }
        
        console.log('ReaderEPUBPro: content hook 触发', {
          hasDoc: !!doc,
          hasBody: !!doc.body,
          docTitle: doc.title,
          viewExists: !!view,
        });
        
        // 简化布局重置逻辑，只重置位置，不影响内容显示
        try {
          // 检查是否已经注入过重置样式
          if (!(doc as any).__epubLayoutResetInjected) {
            // 移除无效的字体引用（res:// 协议等）
            const styleSheets = doc.styleSheets;
            for (let i = 0; i < styleSheets.length; i++) {
              try {
                const sheet = styleSheets[i];
                if (!sheet.cssRules) continue;
                
                for (let j = sheet.cssRules.length - 1; j >= 0; j--) {
                  try {
                    const rule = sheet.cssRules[j];
                    if (rule.type === CSSRule.FONT_FACE_RULE) {
                      const fontFaceRule = rule as CSSFontFaceRule;
                      const src = fontFaceRule.style.getPropertyValue('src');
                      // 检查是否包含无效的字体路径（res://, file:// 等）
                      if (src && (src.includes('res://') || src.includes('file://') || src.includes('res:///'))) {
                        console.log('ReaderEPUBPro: 移除无效字体引用', src);
                        sheet.deleteRule(j);
                      }
                    }
                  } catch (e) {
                    // 忽略无法访问的规则（可能是跨域样式表）
                    console.warn('ReaderEPUBPro: 无法访问 CSS 规则', e);
                  }
                }
              } catch (e) {
                // 忽略无法访问的样式表（可能是跨域样式表）
                console.warn('ReaderEPUBPro: 无法访问样式表', e);
              }
            }
            
            // 移除 <link> 标签中的无效字体引用
            const linkTags = doc.querySelectorAll('link[rel="stylesheet"], link[type="text/css"]');
            linkTags.forEach((link: any) => {
              const href = link.getAttribute('href');
              if (href && (href.includes('res://') || href.includes('file://') || href.includes('res:///'))) {
                console.log('ReaderEPUBPro: 移除无效字体链接', href);
                link.remove();
              }
            });
            
            // 移除 <style> 标签中的无效字体引用
            const styleTags = doc.querySelectorAll('style');
            styleTags.forEach((styleTag: HTMLStyleElement) => {
              if (styleTag.textContent) {
                // 使用正则表达式移除包含 res:// 的 @font-face 规则
                const cleanedCSS = styleTag.textContent.replace(
                  /@font-face\s*\{[^}]*src\s*:[^}]*res:\/\/[^}]*\}/gi,
                  '/* 已移除无效字体引用 */'
                );
                if (cleanedCSS !== styleTag.textContent) {
                  console.log('ReaderEPUBPro: 清理 style 标签中的无效字体引用');
                  styleTag.textContent = cleanedCSS;
                }
              }
            });
            
            const style = doc.createElement('style');
            style.textContent = `
              /* 只重置基本样式，不重置位置属性（epubjs需要控制位置来实现分页） */
              html, body {
                margin: 0 !important;
                padding: 0 !important;
                /* 不设置 position、left、top、transform，让 epubjs 自己管理 */
              }
              
              /* 重置所有元素的 box-sizing */
              * {
                box-sizing: border-box !important;
              }
              
              /* 阻止无效字体加载 */
              @font-face {
                font-family: 'BlockedFont';
                src: none;
              }
            `;
            doc.head.appendChild(style);
            (doc as any).__epubLayoutResetInjected = true;
            console.log('ReaderEPUBPro: 注入布局重置 CSS 并清理无效字体引用');
            
            // 使用 MutationObserver 监听新添加的样式和链接，移除无效字体引用
            if (!(doc as any).__epubFontObserver) {
              const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                  mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                      const element = node as HTMLElement;
                      
                      // 检查新添加的 link 标签
                      if (element.tagName === 'LINK') {
                        const href = (element as HTMLLinkElement).getAttribute('href');
                        if (href && (href.includes('res://') || href.includes('file://') || href.includes('res:///'))) {
                          console.log('ReaderEPUBPro: 拦截无效字体链接', href);
                          element.remove();
                        }
                      }
                      
                      // 检查新添加的 style 标签
                      if (element.tagName === 'STYLE') {
                        const styleEl = element as HTMLStyleElement;
                        if (styleEl.textContent) {
                          const cleanedCSS = styleEl.textContent.replace(
                            /@font-face\s*\{[^}]*src\s*:[^}]*res:\/\/[^}]*\}/gi,
                            '/* 已移除无效字体引用 */'
                          );
                          if (cleanedCSS !== styleEl.textContent) {
                            console.log('ReaderEPUBPro: 清理新添加的 style 标签中的无效字体引用');
                            styleEl.textContent = cleanedCSS;
                          }
                        }
                      }
                    }
                  });
                });
              });
              
              observer.observe(doc.head, {
                childList: true,
                subtree: true,
              });
              
              (doc as any).__epubFontObserver = observer;
            }
          }
          
          // 注意：在分页模式下，不要重置滚动位置！
          // epubjs 在分页模式下会自动管理滚动位置
          // 重置滚动位置会破坏 epubjs 的布局
          // 只在 scrolled 模式下才需要重置滚动位置
          // 这里不重置，让 epubjs 自己管理
          
          // 注意：在分页模式下，不要重置 iframe 和 view.element 的位置！
          // epubjs 在分页模式下会使用 transform 或 left 属性来定位每个页面
          // 强制重置这些属性会破坏 epubjs 的布局，导致内容不断向左偏移
          // 只设置基本的样式，不重置位置相关属性
          const iframe = view.element?.closest('iframe');
          if (iframe) {
            const iframeEl = iframe as HTMLElement;
            // 只设置基本的样式，不重置位置
            iframeEl.style.setProperty('max-width', '100%', 'important');
            iframeEl.style.setProperty('box-sizing', 'border-box', 'important');
            // 不重置 position、left、top、transform，让 epubjs 自己管理
          }
          
          // view.element 的位置也由 epubjs 管理，不重置
          // 如果需要，只设置基本的样式属性
          
          // 重置文档元素的基本样式，但不重置位置属性
          // 在分页模式下，epubjs 需要控制文档的位置来实现分页效果
          if (doc.documentElement) {
            doc.documentElement.style.margin = '0';
            doc.documentElement.style.padding = '0';
            // 不重置 position、left、top，让 epubjs 自己管理
          }
          
          if (doc.body) {
            doc.body.style.margin = '0';
            doc.body.style.padding = doc.body.style.padding || '0';
            // 不重置 position、left、top，让 epubjs 自己管理
          }
        } catch (layoutError) {
          console.warn('ReaderEPUBPro: 设置布局防止偏移失败', layoutError);
        }
        
        // 强制应用主题和样式的函数
        // 注意：只设置必要的样式，避免影响布局计算
        const forceApplyTheme = () => {
          try {
            // 强制设置body和html（只设置颜色和字体，谨慎设置可能影响布局的属性）
            if (doc.body) {
              doc.body.style.setProperty('background-color', currentThemeStyles.bg, 'important');
              doc.body.style.setProperty('color', currentThemeStyles.text, 'important');
              doc.body.style.setProperty('font-family', settings.fontFamily === 'serif' 
                ? '"Songti SC", "SimSun", "宋体", "STSong", serif'
                : '-apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", "WenQuanYi Micro Hei", sans-serif', 'important');
              doc.body.style.setProperty('font-size', `${settings.fontSize}px`, 'important');
              doc.body.style.setProperty('line-height', `${settings.lineHeight}`, 'important');
              // padding 和 margin 可能影响布局，只在没有设置时才应用
              if (!doc.body.style.padding || doc.body.style.padding === '0px') {
                doc.body.style.setProperty('padding', `${settings.margin}px`, 'important');
              }
              // margin 保持为 0，避免影响布局
              if (!doc.body.style.margin || doc.body.style.margin === 'auto') {
                doc.body.style.setProperty('margin', '0', 'important');
              }
            }
            if (doc.documentElement) {
              doc.documentElement.style.setProperty('background-color', currentThemeStyles.bg, 'important');
              doc.documentElement.style.setProperty('color', currentThemeStyles.text, 'important');
              // 确保 html 元素不影响布局
              doc.documentElement.style.setProperty('margin', '0', 'important');
              doc.documentElement.style.setProperty('padding', '0', 'important');
            }
            
            // 只设置文本元素的颜色，不设置可能影响布局的属性
            const textElements = doc.querySelectorAll('p, span, div, h1, h2, h3, h4, h5, h6, li, td, th');
            textElements.forEach((el: any) => {
              if (el.style) {
                const tagName = el.tagName?.toLowerCase();
                // 只设置颜色相关样式，不设置布局相关样式
                if (tagName !== 'img' && tagName !== 'svg' && tagName !== 'canvas' && tagName !== 'iframe') {
                  // 只在元素没有设置背景色或背景色是透明时才应用
                  const bgColor = el.style.backgroundColor;
                  if (!bgColor || bgColor === 'transparent' || bgColor === 'rgba(0, 0, 0, 0)') {
                    el.style.setProperty('background-color', currentThemeStyles.bg, 'important');
                  }
                  // 只在元素没有设置颜色或颜色是继承时才应用
                  const textColor = el.style.color;
                  if (!textColor || textColor === 'inherit' || textColor === 'initial') {
                    el.style.setProperty('color', currentThemeStyles.text, 'important');
                  }
                }
              }
            });
          } catch (e) {
            console.warn('ReaderEPUBPro: 强制应用主题失败:', e);
          }
        };
        
        // 立即应用主题
        forceApplyTheme();
        
        // 使用MutationObserver持续监控并强制应用主题
        const themeObserver = new MutationObserver(() => {
          forceApplyTheme();
        });
        
        if (doc.body || doc.documentElement) {
          themeObserver.observe(doc.body || doc.documentElement, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['style', 'class'],
          });
        }
        
        console.log('ReaderEPUBPro: 内容已加载到视图', {
          bodyExists: !!doc.body,
          bodyContent: doc.body ? doc.body.innerHTML.substring(0, 200) : 'N/A',
          bodyChildren: doc.body ? doc.body.children.length : 0,
          viewExists: !!view,
          docTitle: doc.title,
        });
        
        // 添加点击事件处理（epubjs 使用 iframe，需要在 iframe 内添加事件）
        // 注意：epubjs 在每次翻页时可能创建新的 view/document，所以需要在每次 content hook 触发时都绑定事件
        // 但使用 document 级别的标志避免重复绑定到同一个 document
        if (settings.clickToTurn && !(doc as any).__epubClickEventsSetup) {
          try {
            const iframeWindow = doc.defaultView || (doc as any).parentWindow;
            if (!iframeWindow) {
              console.warn('ReaderEPUBPro: 无法获取 iframe window');
              return;
            }
            
            // 标记事件已设置（使用 document 级别，确保每个新的 document 都能绑定事件）
            // 注意：防抖逻辑现在在全局翻页函数中处理
            (doc as any).__epubClickEventsSetup = true;
            console.log('ReaderEPUBPro: 设置点击事件监听器', {
              docTitle: doc.title,
              hasBody: !!doc.body,
            });
            
            // 点击事件处理
            const handleClick = (e: MouseEvent) => {
              if (!settings.clickToTurn) return;
              
              const target = e.target as HTMLElement;
              // 如果点击的是链接、按钮等交互元素，不处理翻页
              if (target.tagName === 'A' || target.tagName === 'BUTTON' || target.closest('a') || target.closest('button')) {
                return;
              }
              
              // 获取容器的实际尺寸（这是最可靠的方法）
              // 在分页模式下，应该使用容器的实际宽度，而不是iframe内部文档的宽度
              let containerWidth = 0;
              let containerHeight = 0;
              
              try {
                // 首先尝试从外部容器获取尺寸
                if (epubjsContainerRef.current) {
                  containerWidth = epubjsContainerRef.current.offsetWidth;
                  containerHeight = epubjsContainerRef.current.offsetHeight;
                }
                
                // 如果外部容器不可用，尝试从iframe元素获取
                if (containerWidth === 0 || containerHeight === 0) {
                  const iframe = epubjsContainerRef.current?.querySelector('iframe') as HTMLIFrameElement;
                  if (iframe) {
                    containerWidth = iframe.offsetWidth || iframe.clientWidth;
                    containerHeight = iframe.offsetHeight || iframe.clientHeight;
                  }
                }
                
                // 如果还是获取不到，使用视口尺寸（作为备选）
                if (containerWidth === 0 || containerHeight === 0) {
                  containerWidth = iframeWindow.innerWidth || doc.documentElement.clientWidth || 800;
                  containerHeight = iframeWindow.innerHeight || doc.documentElement.clientHeight || 600;
                }
              } catch (e) {
                console.warn('ReaderEPUBPro: 获取容器尺寸失败', e);
                containerWidth = 800;
                containerHeight = 600;
              }
              
              // 获取点击位置（相对于容器）
              // 必须使用相对于容器的坐标，而不是绝对坐标
              let x = 0;
              let y = 0;
              
              try {
                // 优先使用容器的位置
                if (epubjsContainerRef.current) {
                  const containerRect = epubjsContainerRef.current.getBoundingClientRect();
                  x = e.clientX - containerRect.left;
                  y = e.clientY - containerRect.top;
                } else {
                  // 如果容器不可用，使用 iframe
                  const iframe = doc.querySelector('iframe') as HTMLIFrameElement;
                  if (iframe) {
                    const iframeRect = iframe.getBoundingClientRect();
                    x = e.clientX - iframeRect.left;
                    y = e.clientY - iframeRect.top;
                  } else {
                    // 最后使用视口坐标
                    x = e.clientX;
                    y = e.clientY;
                  }
                }
              } catch (err) {
                console.warn('ReaderEPUBPro: 无法获取相对位置', err);
                // 使用原始的 clientX/clientY 作为备选
                x = e.clientX;
                y = e.clientY;
              }
              
              // 确保坐标在合理范围内（相对于容器）
              x = Math.max(0, Math.min(x, containerWidth));
              y = Math.max(0, Math.min(y, containerHeight));
              
              // 验证宽度值是否合理
              const validWidth = containerWidth > 0 && containerWidth < 10000 ? containerWidth : 800;
              const validHeight = containerHeight > 0 && containerHeight < 10000 ? containerHeight : 600;
              
              console.log('ReaderEPUBPro: epubjs 点击事件', {
                x,
                y,
                containerWidth: validWidth,
                containerHeight: validHeight,
                pageTurnMode: settings.pageTurnMode,
              });
              
              // 阻止默认行为和事件冒泡
              e.preventDefault();
              e.stopPropagation();
              e.stopImmediatePropagation();
              
              // 确定翻页方向（使用容器的实际宽度）
              let direction: 'prev' | 'next' = 'next';
              if (settings.pageTurnMode === 'vertical') {
                // 上下翻页：上方=上一页，下方=下一页
                direction = y < validHeight / 2 ? 'prev' : 'next';
              } else {
                // 左右翻页：左侧=上一页，右侧=下一页
                direction = x < validWidth / 2 ? 'prev' : 'next';
              }
              
              console.log('ReaderEPUBPro: 点击翻页', {
                mode: settings.pageTurnMode,
                x,
                y,
                containerWidth: validWidth,
                containerHeight: validHeight,
                direction,
                threshold: validWidth / 2,
              });
              
              // 直接调用全局翻页函数，使用与底部导航栏相同的逻辑
              // 如果全局函数不存在，等待一下再重试（可能还未初始化）
              if ((window as any).__readerPageTurn) {
                (window as any).__readerPageTurn(direction);
              } else {
                console.warn('ReaderEPUBPro: 全局翻页函数不存在，等待初始化...');
                // 等待一下再重试
                setTimeout(() => {
                  if ((window as any).__readerPageTurn) {
                    console.log('ReaderEPUBPro: 全局函数已就绪，执行翻页');
                    (window as any).__readerPageTurn(direction);
                  } else {
                    console.error('ReaderEPUBPro: 全局翻页函数仍未就绪');
                  }
                }, 200);
              }
            };
            
            
            // 触摸事件处理（移动端滑动翻页）
            const touchState = { startX: 0, startY: 0 };
            const swipeDebounce = 800; // 800ms 内只允许一次滑动翻页
            
            const handleTouchStart = (e: TouchEvent) => {
              if (e.touches.length > 0) {
                touchState.startX = e.touches[0].clientX;
                touchState.startY = e.touches[0].clientY;
              }
            };
            
            const handleTouchEnd = (e: TouchEvent) => {
              // 检查是否正在翻页
              if (epubjsPageTurnStateRef.current.isTurningPage) {
                touchState.startX = 0;
                touchState.startY = 0;
                return;
              }
              
              // 防抖检查（使用组件级别的 ref）
              const now = Date.now();
              if (now - epubjsPageTurnStateRef.current.lastPageTurnTime < swipeDebounce) {
                touchState.startX = 0;
                touchState.startY = 0;
                return;
              }
              
              if (!touchState.startX || !touchState.startY || !settings.clickToTurn) {
                touchState.startX = 0;
                touchState.startY = 0;
                return;
              }
              
              if (e.changedTouches.length === 0) {
                touchState.startX = 0;
                touchState.startY = 0;
                return;
              }
              
              const endX = e.changedTouches[0].clientX;
              const endY = e.changedTouches[0].clientY;
              const diffX = endX - touchState.startX;
              const diffY = endY - touchState.startY;
              
              // 如果垂直滑动距离大于水平滑动距离，不处理（可能是滚动）
              if (Math.abs(diffY) > Math.abs(diffX)) {
                touchState.startX = 0;
                touchState.startY = 0;
                return;
              }
              
              // 滑动距离阈值
              const minSwipeDistance = 50;
              
              if (Math.abs(diffX) > minSwipeDistance) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                
                // 确定翻页方向，使用全局翻页函数
                let direction: 'prev' | 'next' | null = null;
                
                if (settings.pageTurnMode === 'vertical') {
                  // 上下翻页
                  if (diffY < -50) {
                    console.log('ReaderEPUBPro: 向上滑动，翻到上一页', { diffY });
                    direction = 'prev';
                  } else if (diffY > 50) {
                    console.log('ReaderEPUBPro: 向下滑动，翻到下一页', { diffY });
                    direction = 'next';
                  }
                } else {
                  // 左右翻页
                  if (diffX > 50) {
                    // 向右滑动（手指从左到右），上一页
                    console.log('ReaderEPUBPro: 向右滑动，翻到上一页', { diffX });
                    direction = 'prev';
                  } else if (diffX < -50) {
                    // 向左滑动（手指从右到左），下一页
                    console.log('ReaderEPUBPro: 向左滑动，翻到下一页', { diffX });
                    direction = 'next';
                  }
                }
                
                // 调用全局翻页函数
                if (direction && (window as any).__readerPageTurn) {
                  (window as any).__readerPageTurn(direction);
                } else if (direction) {
                  console.warn('ReaderEPUBPro: 全局翻页函数不存在，直接调用rendition');
                  // 备选方案：直接调用rendition
                  try {
                    if (direction === 'prev') {
                      rendition.prev();
                    } else {
                      rendition.next();
                    }
                  } catch (err) {
                    console.error('ReaderEPUBPro: 滑动翻页失败', err);
                  }
                }
              } else {
                // 滑动距离不够，重置触摸状态
                touchState.startX = 0;
                touchState.startY = 0;
              }
              
              touchState.startX = 0;
              touchState.startY = 0;
            };
            
            // 添加事件监听器（只在 document 上添加，避免重复触发）
            // 注意：不要同时在 doc 和 body 上添加，会导致事件触发两次
            doc.addEventListener('click', handleClick, { capture: true, passive: false });
            doc.addEventListener('touchstart', handleTouchStart, { capture: true, passive: true });
            doc.addEventListener('touchend', handleTouchEnd, { capture: true, passive: false });
            
            console.log('ReaderEPUBPro: epubjs 点击事件监听已添加');
            
            // 清理函数（在 view 销毁时调用）
            if (view.on) {
              view.on('destroy', () => {
                try {
                  doc.removeEventListener('click', handleClick, true);
                  doc.removeEventListener('touchstart', handleTouchStart, true);
                  doc.removeEventListener('touchend', handleTouchEnd, true);
                  // 清除标志，允许下次重新绑定
                  delete (doc as any).__epubClickEventsSetup;
                  console.log('ReaderEPUBPro: 清理事件监听器');
                } catch (e) {
                  console.warn('ReaderEPUBPro: 清理事件监听器失败', e);
                }
              });
            }
          } catch (e) {
            console.warn('ReaderEPUBPro: 设置 epubjs 点击事件失败', e);
          }
        }
      });

      // 恢复阅读位置或显示第一页
      try {
        let displayPromise: Promise<any>;
        
        if (initialPosition?.currentLocation) {
          console.log('ReaderEPUBPro: 恢复阅读位置', initialPosition.currentLocation);
          displayPromise = rendition.display(initialPosition.currentLocation);
        } else if (initialPosition?.chapterIndex !== undefined) {
          const spine = bookInstance.spine;
          const item = spine.get(initialPosition.chapterIndex);
          if (item) {
            console.log('ReaderEPUBPro: 显示指定章节', item.href);
            displayPromise = rendition.display(item.href);
          } else {
            // 如果没有找到指定章节，显示第一页
            const firstItem = bookInstance.spine.get(0);
            if (firstItem) {
              console.log('ReaderEPUBPro: 显示第一页（章节未找到）', firstItem.href);
              displayPromise = rendition.display(firstItem.href);
            } else {
              throw new Error('书籍没有可用的章节');
            }
          }
        } else {
          // 没有初始位置，显示第一页
          const firstItem = bookInstance.spine.get(0);
          if (firstItem) {
            console.log('ReaderEPUBPro: 显示第一页', firstItem.href);
            displayPromise = rendition.display(firstItem.href);
          } else {
            throw new Error('书籍没有可用的章节');
          }
        }
        
        console.log('ReaderEPUBPro: 调用 display()，等待显示完成...');
        await displayPromise;
        console.log('ReaderEPUBPro: display() 完成');
        
        // 等待内容渲染（增加等待时间）
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // 检查容器中是否有内容（epubjs 会创建 iframe）
        const iframe = container.querySelector('iframe');
        const containerInfo = {
          containerHTML: container.innerHTML.substring(0, 300),
          containerChildren: container.children.length,
          hasIframe: !!iframe,
          iframeCount: container.querySelectorAll('iframe').length,
          containerWidth: container.offsetWidth,
          containerHeight: container.offsetHeight,
        };
        
        console.log('ReaderEPUBPro: 内容显示检查', containerInfo);
        
        // 如果找到了 iframe，检查 iframe 内容
        if (iframe) {
          try {
            const iframeElement = iframe as HTMLIFrameElement;
            const iframeDoc = iframeElement.contentDocument || iframeElement.contentWindow?.document;
            if (iframeDoc && iframeDoc.body) {
              console.log('ReaderEPUBPro: iframe 内容检查成功', {
                bodyExists: !!iframeDoc.body,
                bodyContent: iframeDoc.body.innerHTML.substring(0, 200),
                bodyChildren: iframeDoc.body.children.length,
                bodyTextLength: iframeDoc.body.textContent?.length || 0,
              });
            } else {
              console.warn('ReaderEPUBPro: iframe 存在但无法访问内容', {
                hasContentDocument: !!iframeElement.contentDocument,
                hasContentWindow: !!iframeElement.contentWindow,
              });
              
              // 等待 iframe 加载完成
              iframeElement.addEventListener('load', () => {
                console.log('ReaderEPUBPro: iframe load 事件触发');
                try {
                  const doc = iframeElement.contentDocument || iframeElement.contentWindow?.document;
                  if (doc && doc.body) {
                    console.log('ReaderEPUBPro: iframe 加载后内容检查', {
                      bodyExists: !!doc.body,
                      bodyContent: doc.body.innerHTML.substring(0, 200),
                    });
                  }
                } catch (e) {
                  console.warn('ReaderEPUBPro: iframe load 后仍无法访问内容', e);
                }
              }, { once: true });
            }
          } catch (e) {
            console.warn('ReaderEPUBPro: 无法访问 iframe 内容', e);
          }
        } else if (container.children.length === 0) {
          console.warn('ReaderEPUBPro: 容器中没有内容，尝试重新显示');
          // 等待一下再检查
          await new Promise(resolve => setTimeout(resolve, 500));
          
          // 尝试调用 resize 来触发重新渲染
          try {
            console.log('ReaderEPUBPro: 尝试 resize', { containerWidth, containerHeight });
            rendition.resize(containerWidth, containerHeight);
            await new Promise(resolve => setTimeout(resolve, 300));
          } catch (resizeError) {
            console.warn('ReaderEPUBPro: resize 失败', resizeError);
          }
          
          // 再次尝试显示
          if (container.children.length === 0) {
            console.error('ReaderEPUBPro: 容器仍然为空，尝试强制重新显示');
            const firstItem = bookInstance.spine.get(0);
            if (firstItem) {
              console.log('ReaderEPUBPro: 强制显示第一页', firstItem.href);
              await rendition.display(firstItem.href);
              await new Promise(resolve => setTimeout(resolve, 500));
              
              // 再次检查
              const iframeAfter = container.querySelector('iframe');
              console.log('ReaderEPUBPro: 强制显示后检查', {
                hasIframe: !!iframeAfter,
                containerChildren: container.children.length,
              });
            }
          }
        }
      } catch (displayError: any) {
        console.error('ReaderEPUBPro: 显示内容失败', displayError);
        // 尝试显示第一页
        try {
          const firstItem = bookInstance.spine.get(0);
          if (firstItem) {
            console.log('ReaderEPUBPro: 回退到第一页', firstItem.href);
            await rendition.display(firstItem.href);
            console.log('ReaderEPUBPro: 回退显示成功');
          } else {
            throw new Error('书籍没有可用的章节');
          }
        } catch (fallbackError: any) {
          console.error('ReaderEPUBPro: 显示第一页也失败', fallbackError);
          throw new Error(`无法显示内容: ${fallbackError.message || '未知错误'}`);
        }
      }

      // 修复内容偏移的函数（仅在检测到偏移时调用）
      const fixContentOffset = () => {
        try {
          if (!epubjsContainerRef.current || !epubjsRenditionRef.current?.manager) {
            return;
          }
          
          const containerRect = epubjsContainerRef.current.getBoundingClientRect();
          const views = epubjsRenditionRef.current.manager.views;
          
          if (!views || views.length === 0) {
            return;
          }
          
          let hasOffset = false;
          
          views.forEach((view: any) => {
            const elementsToCheck = [
              view.container,
              view.wrapper,
              view.element,
              epubjsContainerRef.current?.querySelector('iframe') as HTMLIFrameElement,
            ].filter(el => el && el instanceof HTMLElement);
            
            elementsToCheck.forEach((element: HTMLElement) => {
              const rect = element.getBoundingClientRect();
              const offset = rect.left - containerRect.left;
              
              // 只在检测到明显偏移时修复（超过20px）
              if (Math.abs(offset) > 20) {
                hasOffset = true;
                element.style.setProperty('transform', 'none', 'important');
                element.style.setProperty('left', '0', 'important');
                console.log('ReaderEPUBPro: 修复内容偏移', { offset, element: element.tagName });
              }
            });
          });
          
          return hasOffset;
        } catch (e) {
          console.warn('ReaderEPUBPro: 修复偏移失败', e);
          return false;
        }
      };
      
      // 监听位置变化
      rendition.on('relocated', (location: any) => {
        const progress = location.start.percentage || 0;
        const spineIndex = location.start.index;
        
        // 从 TOC 中查找对应的章节标题
        // 注意：使用当前的 toc state，因为 tocItems 是局部变量
        let chapterTitle = '';
        const currentTocItem = toc.find(item => item.chapterIndex === spineIndex);
        if (currentTocItem) {
          chapterTitle = currentTocItem.title;
        } else {
          // 如果找不到，尝试从 spine 中获取章节信息
          try {
            const spineItem = epubjsBookRef.current?.spine.get(spineIndex);
            if (spineItem) {
              // 尝试从文档中提取标题
              const view = epubjsRenditionRef.current?.manager?.views?.[0];
              if (view?.document) {
                const titleEl = view.document.querySelector('h1, h2, h3, .chapter-title, [class*="title"]');
                if (titleEl) {
                  chapterTitle = titleEl.textContent?.trim() || '';
                }
              }
            }
          } catch (e) {
            console.warn('ReaderEPUBPro: 获取章节标题失败', e);
          }
        }
        
        const position: ReadingPosition = {
          chapterIndex: spineIndex,
          currentPage: location.start.displayed.page || 1,
          totalPages: location.start.displayed.total || 1,
          progress: progress,
          currentLocation: location.start.cfi,
          chapterTitle: chapterTitle, // 添加章节标题
        };
        onProgressChange(progress, position);
        
        // 延迟检查并修复偏移（仅在检测到偏移时修复）
        setTimeout(() => {
          requestAnimationFrame(() => {
            fixContentOffset();
          });
        }, 500);
        
        // 调试和修复：检查位置偏移问题
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            try {
              if (!epubjsContainerRef.current) {
                console.warn('ReaderEPUBPro: 容器不存在，无法检查位置');
                return;
              }
              
              const containerRect = epubjsContainerRef.current.getBoundingClientRect();
              
              if (epubjsRenditionRef.current && epubjsRenditionRef.current.manager) {
                const views = epubjsRenditionRef.current.manager.views;
                console.log('ReaderEPUBPro: relocated 事件触发，检查位置', {
                  viewsCount: views?.length || 0,
                  containerLeft: containerRect.left,
                  containerWidth: containerRect.width,
                });
                
                if (views && views.length > 0) {
                  views.forEach((view: any, index: number) => {
                    try {
                      // epubjs在分页模式下，transform可能应用在view.container或view.wrapper上
                      // 需要检查多个可能的元素
                      let targetElement: HTMLElement | null = null;
                      let elementType = '';
                      
                      // 1. 检查view.container（epubjs可能在这里应用transform）
                      if (view.container) {
                        targetElement = view.container as HTMLElement;
                        elementType = 'view.container';
                      }
                      // 2. 检查view.wrapper
                      else if (view.wrapper) {
                        targetElement = view.wrapper as HTMLElement;
                        elementType = 'view.wrapper';
                      }
                      // 3. 检查view.element
                      else if (view.element) {
                        targetElement = view.element as HTMLElement;
                        elementType = 'view.element';
                      }
                      // 4. 最后检查iframe
                      else {
                        const iframe = epubjsContainerRef.current?.querySelector('iframe') as HTMLIFrameElement;
                        if (iframe) {
                          targetElement = iframe;
                          elementType = 'iframe';
                        }
                      }
                      
                      if (!targetElement) {
                        console.warn(`ReaderEPUBPro: View ${index} 找不到目标元素`);
                        return;
                      }
                      
                      const rect = targetElement.getBoundingClientRect();
                      const computedStyle = window.getComputedStyle(targetElement);
                      
                      // 计算实际偏移量
                      const offset = rect.left - containerRect.left;
                      
                      // 获取epubjs实际使用的宽度（从rendition配置或iframe内部）
                      let epubjsActualWidth = containerRect.width;
                      try {
                        // 尝试从rendition获取实际宽度
                        const renditionAny = epubjsRenditionRef.current as any;
                        if (renditionAny?.settings?.width) {
                          epubjsActualWidth = renditionAny.settings.width;
                        }
                        // 或者从iframe内部文档获取
                        const iframe = epubjsContainerRef.current?.querySelector('iframe') as HTMLIFrameElement;
                        if (iframe) {
                          const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                          if (iframeDoc) {
                            const iframeBody = iframeDoc.body;
                            if (iframeBody) {
                              const bodyRect = iframeBody.getBoundingClientRect();
                              const bodyComputedStyle = window.getComputedStyle(iframeBody);
                              const bodyPaddingLeft = parseFloat(bodyComputedStyle.paddingLeft) || 0;
                              const bodyPaddingRight = parseFloat(bodyComputedStyle.paddingRight) || 0;
                              const bodyMarginLeft = parseFloat(bodyComputedStyle.marginLeft) || 0;
                              const bodyMarginRight = parseFloat(bodyComputedStyle.marginRight) || 0;
                              epubjsActualWidth = bodyRect.width + bodyPaddingLeft + bodyPaddingRight + bodyMarginLeft + bodyMarginRight;
                            }
                          }
                        }
                      } catch (e) {
                        console.warn('ReaderEPUBPro: 无法获取epubjs实际宽度', e);
                      }
                      
                      // 检查偏移量是否是容器宽度的倍数（考虑padding等）
                      let containerPaddingLeft = 0;
                      let containerPaddingRight = 0;
                      let containerBorderLeft = 0;
                      let containerBorderRight = 0;
                      
                      if (epubjsContainerRef.current) {
                        const containerComputedStyle = window.getComputedStyle(epubjsContainerRef.current);
                        containerPaddingLeft = parseFloat(containerComputedStyle.paddingLeft) || 0;
                        containerPaddingRight = parseFloat(containerComputedStyle.paddingRight) || 0;
                        containerBorderLeft = parseFloat(containerComputedStyle.borderLeftWidth) || 0;
                        containerBorderRight = parseFloat(containerComputedStyle.borderRightWidth) || 0;
                      }
                      const effectiveWidth = containerRect.width - containerPaddingLeft - containerPaddingRight - containerBorderLeft - containerBorderRight;
                      
                      console.log(`ReaderEPUBPro: View ${index} 位置信息`, {
                        elementType: elementType,
                        elementLeft: rect.left,
                        containerLeft: containerRect.left,
                        offset: offset,
                        containerWidth: containerRect.width,
                        effectiveWidth: effectiveWidth,
                        epubjsActualWidth: epubjsActualWidth,
                        containerPaddingLeft,
                        containerPaddingRight,
                        containerBorderLeft,
                        containerBorderRight,
                        offsetLeft: targetElement.offsetLeft,
                        styleLeft: targetElement.style.left,
                        styleTransform: targetElement.style.transform,
                        computedLeft: computedStyle.left,
                        computedTransform: computedStyle.transform,
                        computedPosition: computedStyle.position,
                        computedMarginLeft: computedStyle.marginLeft,
                        computedTranslateX: computedStyle.translate,
                        // 检查偏移是否是宽度的倍数
                        isMultipleOfWidth: Math.abs(offset) > 0 ? Math.abs(Math.abs(offset) / effectiveWidth - Math.round(Math.abs(offset) / effectiveWidth)) < 0.1 : false,
                        expectedMultiplier: Math.abs(offset) > 0 ? Math.round(Math.abs(offset) / effectiveWidth) : 0,
                      });
                      
                      // 如果检测到偏移（超过5px），强制居中修复
                      if (Math.abs(offset) > 5) {
                        console.warn(`ReaderEPUBPro: 检测到 View ${index} 位置偏移 ${offset}px，强制居中修复`, {
                          elementType,
                          targetElement: targetElement.tagName,
                        });
                        
                        // 强制居中：重置所有transform和位置属性
                        targetElement.style.setProperty('transform', 'none', 'important');
                        targetElement.style.setProperty('left', '0', 'important');
                        targetElement.style.setProperty('right', 'auto', 'important');
                        targetElement.style.setProperty('margin-left', 'auto', 'important');
                        targetElement.style.setProperty('margin-right', 'auto', 'important');
                        targetElement.style.setProperty('position', 'relative', 'important');
                        targetElement.style.removeProperty('translate');
                        
                        // 同时修复所有可能的元素（view.container, view.wrapper, view.element, iframe）
                        const allElements = [
                          view.container,
                          view.wrapper,
                          view.element,
                          epubjsContainerRef.current?.querySelector('iframe') as HTMLIFrameElement,
                        ].filter(el => el && el !== targetElement && el instanceof HTMLElement);
                        
                        allElements.forEach((el: HTMLElement) => {
                          el.style.setProperty('transform', 'none', 'important');
                          el.style.setProperty('left', '0', 'important');
                          el.style.setProperty('right', 'auto', 'important');
                          el.style.setProperty('margin-left', 'auto', 'important');
                          el.style.setProperty('margin-right', 'auto', 'important');
                          el.style.setProperty('position', 'relative', 'important');
                        });
                        
                        // 确保容器居中
                        if (epubjsContainerRef.current) {
                          epubjsContainerRef.current.style.setProperty('display', 'flex', 'important');
                          epubjsContainerRef.current.style.setProperty('justify-content', 'center', 'important');
                          epubjsContainerRef.current.style.setProperty('align-items', 'flex-start', 'important');
                        }
                        
                        // 3. 强制让 epubjs 重新计算布局
                        // 注意：不要重新显示页面，只修复 transform 和调用 resize
                        if (epubjsRenditionRef.current) {
                          try {
                            console.log(`ReaderEPUBPro: 修复位置偏移 ${offset}px`);
                            
                            // 等待样式生效，然后调用 resize 触发重新布局
                            setTimeout(() => {
                              try {
                                // 调用 resize 触发重新布局，让 epubjs 重新计算 transform
                                epubjsRenditionRef.current.resize(containerRect.width, containerRect.height);
                                
                                // 再次检查位置
                                setTimeout(() => {
                                  const newRect = targetElement.getBoundingClientRect();
                                  const newOffset = newRect.left - containerRect.left;
                                  const newComputedTransform = window.getComputedStyle(targetElement).transform;
                                  console.log(`ReaderEPUBPro: View ${index} 修复后位置`, {
                                    elementType,
                                    newLeft: newRect.left,
                                    containerLeft: containerRect.left,
                                    newOffset: newOffset,
                                    newComputedTransform: newComputedTransform,
                                    fixed: Math.abs(newOffset) <= 10,
                                  });
                                  
                                  // 如果还是偏移，可能需要更激进的修复
                                  if (Math.abs(newOffset) > 10) {
                                    console.warn(`ReaderEPUBPro: View ${index} resize 后仍偏移 ${newOffset}px`);
                                    // 不再尝试重新显示，避免跳回页面
                                  }
                                }, 200);
                              } catch (fixErr) {
                                console.error('ReaderEPUBPro: 修复位置失败', fixErr);
                              }
                            }, 50);
                          } catch (err) {
                            console.error('ReaderEPUBPro: 修复位置出错', err);
                          }
                        }
                      }
                    } catch (viewErr) {
                      console.error(`ReaderEPUBPro: 检查 View ${index} 失败`, viewErr);
                    }
                  });
                } else {
                  console.warn('ReaderEPUBPro: views 为空，无法检查位置');
                }
              } else {
                console.warn('ReaderEPUBPro: rendition 或 manager 不存在');
              }
            } catch (e) {
              console.error('ReaderEPUBPro: 检查位置偏移失败', e);
            }
          });
        });
        
        // 注意：翻页标志在 finally 块中重置，这里不需要重复重置
        // relocated 事件只是用来更新进度，不是用来重置翻页标志的
      });

      // 键盘快捷键 - 使用全局翻页函数保持一致性
      rendition.on('keyup', (e: KeyboardEvent) => {
        if (e.key === settings.keyboardShortcuts.prev || e.key === 'ArrowLeft') {
          e.preventDefault();
          if ((window as any).__readerPageTurn) {
            (window as any).__readerPageTurn('prev');
          } else {
            rendition.prev();
          }
        } else if (e.key === settings.keyboardShortcuts.next || e.key === 'ArrowRight') {
          e.preventDefault();
          if ((window as any).__readerPageTurn) {
            (window as any).__readerPageTurn('next');
          } else {
            rendition.next();
          }
        }
      });

      // 统一的翻页函数：处理章节内翻页和章节间跳转
      (window as any).__readerPageTurn = async (direction: 'prev' | 'next') => {
        // 检查是否正在翻页
        if (epubjsPageTurnStateRef.current.isTurningPage) {
          console.log('ReaderEPUBPro: 正在翻页中，忽略翻页请求');
          return;
        }
        
        // 检查rendition是否存在
        if (!rendition) {
          console.error('ReaderEPUBPro: rendition不存在，无法翻页');
          return;
        }
        
        // 检查rendition是否已经准备好
        const renditionAny = rendition as any;
        if (!renditionAny.manager || !renditionAny.manager.views || renditionAny.manager.views.length === 0) {
          console.warn('ReaderEPUBPro: rendition未准备好，等待初始化...');
          setTimeout(() => {
            (window as any).__readerPageTurn?.(direction);
          }, 500);
          return;
        }
        
        // 防抖检查
        const now = Date.now();
        const pageTurnDebounce = 300; // 防抖时间
        if (now - epubjsPageTurnStateRef.current.lastPageTurnTime < pageTurnDebounce) {
          console.log('ReaderEPUBPro: 翻页防抖，忽略翻页请求');
          return;
        }
        
        // 设置翻页标志和更新时间
        epubjsPageTurnStateRef.current.isTurningPage = true;
        epubjsPageTurnStateRef.current.lastPageTurnTime = now;
        
        try {
          // 获取当前位置信息（用于日志）
          let currentLocation: any = null;
          try {
            currentLocation = rendition.currentLocation();
            const displayed = currentLocation?.start?.displayed;
            console.log('ReaderEPUBPro: 当前位置', {
              cfi: currentLocation?.start?.cfi,
              spineIndex: currentLocation?.start?.index,
              page: displayed?.page,
              total: displayed?.total,
              displayed: displayed,
            });
          } catch (e) {
            console.warn('ReaderEPUBPro: 无法获取当前位置', e);
          }
          
          // 简化逻辑：直接使用epubjs的next()/prev()方法
          // epubjs会自动处理章节内翻页和章节间跳转
          // 在分页模式下，next()/prev()会自动判断是否在章节边界
          let pageTurnPromise: Promise<any> | undefined;
          
          console.log(`ReaderEPUBPro: 开始翻页 ${direction}`);
          
          if (direction === 'prev') {
            pageTurnPromise = rendition.prev();
          } else {
            pageTurnPromise = rendition.next();
          }
          
          // 等待翻页完成
          if (pageTurnPromise && typeof pageTurnPromise.then === 'function') {
            await pageTurnPromise;
            console.log(`ReaderEPUBPro: ${direction} 翻页完成`);
            
            // 等待内容渲染和分页计算完成
            await new Promise(resolve => setTimeout(resolve, 200));
            
            // 延迟检查并修复偏移（仅在检测到偏移时修复）
            setTimeout(() => {
              fixContentOffset();
            }, 300);
          } else {
            // 如果没有Promise，等待一小段时间
            await new Promise(resolve => setTimeout(resolve, 300));
            console.log(`ReaderEPUBPro: ${direction} 翻页完成（无Promise返回）`);
            
            // 检查并修复偏移
            setTimeout(() => {
              fixContentOffset();
            }, 200);
          }
        } catch (err: any) {
          console.error(`ReaderEPUBPro: ${direction} 翻页失败`, err);
          toast.error(`翻页失败: ${err.message || '未知错误'}`);
        } finally {
          // 重置翻页标志
          setTimeout(() => {
            epubjsPageTurnStateRef.current.isTurningPage = false;
            console.log('ReaderEPUBPro: 翻页标志已重置');
          }, pageTurnDebounce);
        }
      };

      // 确保内容显示后调用 resize 来触发重新布局
      // 注意：不要在 resize 后重新显示内容，这会导致内容偏移
      setTimeout(() => {
        try {
          if (epubjsRenditionRef.current) {
            const finalWidth = container.offsetWidth || containerWidth;
            const finalHeight = container.offsetHeight || containerHeight;
            console.log('ReaderEPUBPro: 调用 resize', { finalWidth, finalHeight });
            epubjsRenditionRef.current.resize(finalWidth, finalHeight);
            // 不重新显示内容，让 epubjs 自己处理布局
            
            // resize后检查并修复偏移
            setTimeout(() => {
              fixContentOffset();
            }, 300);
          }
        } catch (resizeError) {
          console.warn('ReaderEPUBPro: resize 失败', resizeError);
        }
      }, 500);

      setLoading(false);
    } catch (error: any) {
      console.error('ReaderEPUBPro: epubjs 加载失败', error);
      setError(`加载失败: ${error.message || '未知错误'}`);
      setLoading(false);
      toast.error(`加载书籍失败: ${error.message || '未知错误'}`);
    }
  }, [settings, initialPosition, paginationMode, onProgressChange, onTOCChange]);

  // ==================== react-reader 阅读器 ====================
  const [ReactReaderComponent, setReactReaderComponent] = useState<React.ComponentType<any> | null>(null);
  const [reactReaderFileUrl, setReactReaderFileUrl] = useState<string | null>(null);

  const initReactReader = useCallback(async (fileUrl: string) => {
    try {
      const { EpubView } = await import('react-reader');
      
      // 获取目录
      const { EpubParser } = await import('../../../utils/epubParser');
      const parser = await EpubParser.loadFromUrl(fileUrl);
      const epubData = await parser.parse();
      
      const tocItems: TOCItem[] = epubData.toc.map((item, index) => ({
        id: item.id || `toc-${index}`,
        title: item.label || `目录项 ${index + 1}`,
        href: item.href,
        level: 1,
        chapterIndex: index,
      }));
      setToc(tocItems);
      onTOCChange(tocItems);

      // 设置 react-reader 组件和文件URL
      setReactReaderComponent(() => EpubView);
      setReactReaderFileUrl(fileUrl);
      setReactReaderLocation(initialPosition?.currentLocation || 0);

      setLoading(false);
    } catch (error: any) {
      console.error('ReaderEPUBPro: react-reader 加载失败', error);
      setError(`加载失败: ${error.message || '未知错误'}`);
      setLoading(false);
      toast.error(`加载书籍失败: ${error.message || '未知错误'}`);
    }
  }, [initialPosition, paginationMode, onTOCChange]);

  // ==================== 自定义解析器阅读器 ====================
  const [customChapters, setCustomChapters] = useState<any[]>([]);
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  const customReaderContainerRef = useRef<HTMLDivElement>(null);

  const initCustomReader = useCallback(async (fileUrl: string) => {
    try {
      const { EpubParser } = await import('../../../utils/epubParser');
      const parser = await EpubParser.loadFromUrl(fileUrl);
      const epubData = await parser.parse();
      
      setCustomChapters(epubData.chapters);
      
      const tocItems: TOCItem[] = epubData.toc.map((item, index) => ({
        id: item.id || `toc-${index}`,
        title: item.label || `目录项 ${index + 1}`,
        href: item.href,
        level: 1,
        chapterIndex: index,
      }));
      setToc(tocItems);
      onTOCChange(tocItems);

      // 恢复阅读位置
      if (initialPosition?.chapterIndex !== undefined) {
        setCurrentChapterIndex(initialPosition.chapterIndex);
      }

      setLoading(false);
    } catch (error: any) {
      console.error('ReaderEPUBPro: 自定义阅读器加载失败', error);
      setError(`加载失败: ${error.message || '未知错误'}`);
      setLoading(false);
      toast.error(`加载书籍失败: ${error.message || '未知错误'}`);
    }
  }, [initialPosition, onTOCChange]);

  // 自定义阅读器：章节导航
  const handleCustomChapterNav = useCallback((direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      if (currentChapterIndex > 0) {
        setCurrentChapterIndex(currentChapterIndex - 1);
      } else {
        toast('已经是第一章了');
      }
    } else {
      if (currentChapterIndex < customChapters.length - 1) {
        setCurrentChapterIndex(currentChapterIndex + 1);
      } else {
        toast('已经是最后一章了');
      }
    }
  }, [currentChapterIndex, customChapters.length]);

  // 监听 readerEngine 变化，确保容器渲染后再加载
  useEffect(() => {
    if (readerEngine === 'epubjs' && !epubjsContainerRef.current) {
      // readerEngine 刚变为 epubjs，等待 React 渲染容器
      console.log('ReaderEPUBPro: readerEngine 变为 epubjs，等待容器渲染...');
      const checkTimer = setTimeout(() => {
        if (epubjsContainerRef.current) {
          console.log('ReaderEPUBPro: 容器已渲染，ref 回调应该会触发');
        } else {
          console.warn('ReaderEPUBPro: 容器仍未渲染，可能存在问题');
        }
      }, 100);
      return () => clearTimeout(checkTimer);
    }
  }, [readerEngine]);

  // 加载阅读器
  useEffect(() => {
    const loadReader = async () => {
      if (!book.id && !book.file_path) {
        console.warn('ReaderEPUBPro: 书籍信息不完整，无法加载', { bookId: book.id, filePath: book.file_path });
        setLoading(false);
        setError('书籍信息不完整');
        return;
      }
      
      setLoading(true);
      setError(null);

      try {
        const fileUrl = await getFileUrl();
        if (!fileUrl) {
          throw new Error('无法获取书籍文件URL');
        }

        console.log('ReaderEPUBPro: 加载阅读器', { 
          engine: readerEngine, 
          mode: paginationMode,
          fileUrl 
        });

        // 对于 epubjs，需要等待容器渲染完成
        if (readerEngine === 'epubjs') {
          // 等待容器状态就绪（通过回调 ref 设置）
          if (!epubjsContainerReady || !epubjsContainerRef.current) {
            console.log('ReaderEPUBPro: 等待 epubjs 容器就绪...');
            let retryCount = 0;
            const maxRetries = 50;
            while ((!epubjsContainerReady || !epubjsContainerRef.current) && retryCount < maxRetries) {
              await new Promise(resolve => setTimeout(resolve, 100));
              retryCount++;
              if (retryCount % 10 === 0) {
                console.log(`ReaderEPUBPro: 等待 epubjs 容器准备中... (${retryCount}/${maxRetries})`);
              }
            }
          }
          
          if (!epubjsContainerRef.current) {
            console.error('ReaderEPUBPro: epubjs 容器最终未准备好', {
              containerReady: epubjsContainerReady,
              hasRef: !!epubjsContainerRef,
            });
            throw new Error('epubjs 容器未准备好，请刷新页面重试');
          }
        }

        // 根据阅读器类型加载
        switch (readerEngine) {
          case 'epubjs':
            await initEpubjsReader(fileUrl);
            break;
          case 'react-reader':
            await initReactReader(fileUrl);
            break;
          case 'custom':
            await initCustomReader(fileUrl);
            break;
          case 'readium':
            // Readium 暂未实现，回退到自定义阅读器
            console.warn('ReaderEPUBPro: Readium 阅读器暂未实现，使用自定义阅读器');
            toast('Readium 阅读器暂未实现，已切换到自定义阅读器', { icon: 'ℹ️' });
            await initCustomReader(fileUrl);
            break;
          default:
            // 未知的阅读器类型，回退到自定义阅读器
            console.warn(`ReaderEPUBPro: 不支持的阅读器类型: ${readerEngine}，使用自定义阅读器`);
            toast(`不支持的阅读器类型: ${readerEngine}，已切换到自定义阅读器`, { icon: 'ℹ️' });
            await initCustomReader(fileUrl);
            break;
        }
      } catch (error: any) {
        console.error('ReaderEPUBPro: 加载失败', error);
        setError(`加载失败: ${error.message || '未知错误'}`);
        setLoading(false);
        toast.error(`加载书籍失败: ${error.message || '未知错误'}`);
      }
    };

    // 检查必要的配置是否已加载
    if (!readerEngine || !paginationMode) {
      console.log('ReaderEPUBPro: 等待阅读器配置加载', { readerEngine, paginationMode });
      setLoading(true); // 保持加载状态
      return;
    }

    // 对于 epubjs，需要等待容器就绪
    if (readerEngine === 'epubjs') {
      // 检查容器是否已经渲染（通过检查 ref.current 是否存在）
      if (!epubjsContainerRef.current) {
        console.log('ReaderEPUBPro: epubjs 容器 ref 不存在，等待容器渲染...', {
          containerReady: epubjsContainerReady,
          hasRef: !!epubjsContainerRef.current,
          readerEngine,
        });
        // 等待一下，让 React 完成渲染（容器会在 readerEngine 变为 epubjs 时渲染）
        // 使用 setTimeout 等待下一个渲染周期
        const waitTimer = setTimeout(() => {
          if (!epubjsContainerRef.current) {
            console.error('ReaderEPUBPro: 等待容器渲染超时，可能存在问题');
            setError('epubjs 容器未渲染，请刷新页面重试');
            setLoading(false);
          }
        }, 500);
        return () => clearTimeout(waitTimer);
      }
      
      if (!epubjsContainerReady) {
        console.log('ReaderEPUBPro: 等待 epubjs 容器就绪状态...', {
          containerReady: epubjsContainerReady,
          hasRef: !!epubjsContainerRef.current,
        });
        // 等待容器就绪（ref 回调会设置 epubjsContainerReady）
        // 设置超时，避免无限等待
        const waitTimer = setTimeout(() => {
          if (!epubjsContainerReady && epubjsContainerRef.current) {
            console.warn('ReaderEPUBPro: 等待容器就绪超时，但容器存在，尝试继续加载');
            // 容器存在但状态未更新，手动设置状态
            setEpubjsContainerReady(true);
          }
        }, 1000);
        return () => clearTimeout(waitTimer);
      }
    }

    // 延迟执行，确保 DOM 已经渲染
    // epubjs 需要更长的延迟，因为需要等待容器渲染和 ref 回调
    const timer = setTimeout(() => {
      loadReader();
    }, readerEngine === 'epubjs' ? 500 : 100);

    return () => {
      clearTimeout(timer);
      if (epubjsBookRef.current) {
        epubjsBookRef.current.destroy?.();
        epubjsBookRef.current = null;
      }
      if (epubjsRenditionRef.current) {
        epubjsRenditionRef.current.destroy?.();
        epubjsRenditionRef.current = null;
      }
      delete (window as any).__readerPageTurn;
    };
  }, [book.id, book.file_path, readerEngine, paginationMode, epubjsContainerReady, getFileUrl, initEpubjsReader, initReactReader, initCustomReader]);

  // 自定义阅读器：跳转到章节
  const goToChapter = useCallback((chapterIndex: number) => {
    setCurrentChapterIndex(chapterIndex);
    setShowTOC(false);
    
    const position: ReadingPosition = {
      chapterIndex,
      currentPage: 1,
      totalPages: 1,
      progress: customChapters.length > 0 ? chapterIndex / customChapters.length : 0,
    };
    onProgressChange(position.progress, position);
  }, [customChapters.length, onProgressChange]);

  // 更新自定义阅读器的进度
  useEffect(() => {
    if (readerEngine === 'custom' && customChapters.length > 0) {
      const position: ReadingPosition = {
        chapterIndex: currentChapterIndex,
        currentPage: 1,
        totalPages: customChapters.length,
        progress: customChapters.length > 0 ? (currentChapterIndex + 1) / customChapters.length : 0,
      };
      onProgressChange(position.progress, position);
    }
  }, [readerEngine, customChapters.length, currentChapterIndex, onProgressChange]);

  // 键盘快捷键（自定义阅读器）
  useEffect(() => {
    if (readerEngine !== 'custom') return;

    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === settings.keyboardShortcuts.prev || e.key === 'ArrowLeft') {
        e.preventDefault();
        handleCustomChapterNav('prev');
      } else if (e.key === settings.keyboardShortcuts.next || e.key === 'ArrowRight') {
        e.preventDefault();
        handleCustomChapterNav('next');
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [readerEngine, settings.keyboardShortcuts, handleCustomChapterNav]);

  // 暴露翻页函数到全局（自定义阅读器）
  useEffect(() => {
    if (readerEngine === 'custom') {
      (window as any).__readerPageTurn = (direction: 'prev' | 'next') => {
        handleCustomChapterNav(direction);
      };
    }
    return () => {
      if (readerEngine === 'custom') {
        delete (window as any).__readerPageTurn;
      }
    };
  }, [readerEngine, handleCustomChapterNav]);

  const themeStyles = {
    light: { bg: '#ffffff', text: '#000000', border: '#e0e0e0' },
    dark: { bg: '#1a1a1a', text: '#ffffff', border: '#404040' },
    sepia: { bg: '#f4e4bc', text: '#5c4b37', border: '#d4c49c' },
    green: { bg: '#c8e6c9', text: '#2e7d32', border: '#a5d6a7' },
  }[settings.theme];

  // 注意：即使 loading 为 true，也要渲染容器（特别是 epubjs），以便 ref 回调能触发
  // 加载提示显示在容器上方

  if (error) {
    return (
      <div className="flex items-center justify-center h-full" style={{ backgroundColor: themeStyles.bg }}>
        <div className="text-center">
          <p style={{ color: themeStyles.text }} className="mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 rounded-lg"
            style={{ backgroundColor: themeStyles.border, color: themeStyles.text }}
          >
            重新加载
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative h-full w-full overflow-hidden"
      style={{ backgroundColor: themeStyles.bg }}
    >
      {/* 加载提示 - 显示在容器上方（如果 loading 为 true） */}
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center z-50" style={{ backgroundColor: themeStyles.bg }}>
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: themeStyles.text }} />
            <p style={{ color: themeStyles.text }}>加载中...</p>
          </div>
        </div>
      )}
      
      {/* epubjs 阅读器容器 - 直接在容器内渲染，移除多余的div嵌套 */}
      {readerEngine === 'epubjs' && (
        <div 
          ref={(el) => {
              console.log('ReaderEPUBPro: epubjs 容器 ref 回调触发', {
                hasEl: !!el,
                readerEngine,
                currentRef: !!epubjsContainerRef.current,
                timestamp: Date.now(),
              });
              
              // 使用回调 ref 来设置引用和状态
              (epubjsContainerRef as React.MutableRefObject<HTMLDivElement | null>).current = el;
              
              if (el) {
                // 确保容器有明确的尺寸
                if (el.offsetWidth === 0 || el.offsetHeight === 0) {
                  console.warn('ReaderEPUBPro: 容器尺寸为0', {
                    offsetWidth: el.offsetWidth,
                    offsetHeight: el.offsetHeight,
                    clientWidth: el.clientWidth,
                    clientHeight: el.clientHeight,
                    parentWidth: el.parentElement?.clientWidth,
                    parentHeight: el.parentElement?.clientHeight,
                  });
                }
                
                // 立即设置状态（不使用 setTimeout，避免延迟）
                setEpubjsContainerReady(true);
                console.log('ReaderEPUBPro: epubjs 容器就绪', {
                  offsetWidth: el.offsetWidth,
                  offsetHeight: el.offsetHeight,
                  containerReady: true,
                });
              } else {
                console.log('ReaderEPUBPro: epubjs 容器 ref 回调 el 为 null');
                setEpubjsContainerReady(false);
              }
            }}
            className="h-full w-full"
            style={{ 
              backgroundColor: themeStyles.bg,
              minHeight: '400px',
              minWidth: '300px',
              position: 'relative',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'flex-start',
              overflow: 'hidden',
            }}
          />
      )}

      {/* react-reader 阅读器 */}
      {readerEngine === 'react-reader' && ReactReaderComponent && reactReaderFileUrl && (
            <ReactReaderComponent
              url={reactReaderFileUrl}
              location={reactReaderLocation}
              loadingView={
                <div className="flex items-center justify-center h-full" style={{ backgroundColor: themeStyles.bg }}>
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2" style={{ borderColor: themeStyles.text }} />
                </div>
              }
              locationChanged={(epubcifi: string | number) => {
                setReactReaderLocation(epubcifi);
                const progress = typeof epubcifi === 'number' ? epubcifi : 0;
                const position: ReadingPosition = {
                  currentPage: 1,
                  totalPages: 1,
                  progress: progress,
                  currentLocation: epubcifi.toString(),
                };
                onProgressChange(progress, position);
              }}
              tocChanged={(toc: any[]) => {
                if (toc && toc.length > 0) {
                  const tocItems: TOCItem[] = toc.map((item: any, index: number) => ({
                    id: item.id || `toc-${index}`,
                    title: item.label || item.title || `目录项 ${index + 1}`,
                    href: item.href,
                    level: item.level || 1,
                    chapterIndex: index,
                  }));
                  setToc(tocItems);
                  onTOCChange(tocItems);
                }
              }}
              getRendition={(rendition: any) => {
                reactReaderRenditionRef.current = rendition;
                
                // 配置分页模式
                if (paginationMode === 'react-reader-paginated') {
                  rendition.flow('paginated');
                } else {
                  rendition.flow('scrolled');
                }

                // 应用主题
                rendition.themes.default({
                  body: {
                    'font-size': `${settings.fontSize}px !important`,
                    'line-height': `${settings.lineHeight} !important`,
                    'font-family': settings.fontFamily === 'serif' 
                      ? '"Songti SC", "SimSun", "宋体", "STSong", serif'
                      : '-apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", "WenQuanYi Micro Hei", sans-serif',
                    'padding': `${settings.margin}px !important`,
                    'text-indent': `${settings.textIndent}em !important`,
                  },
                });

                // 暴露翻页函数到全局
                (window as any).__readerPageTurn = (direction: 'prev' | 'next') => {
                  if (direction === 'prev') {
                    rendition.prev();
                  } else {
                    rendition.next();
                  }
                };
              }}
            />
      )}

      {/* 自定义阅读器 */}
      {readerEngine === 'custom' && customChapters.length > 0 && (
          <div 
            ref={customReaderContainerRef}
            className="h-full w-full overflow-auto"
            style={{ backgroundColor: themeStyles.bg }}
            onClick={(e) => {
              // 点击翻页：左侧上一章，右侧下一章
              if (paginationMode === 'custom-paginated') {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                const width = rect.width;
                if (clickX < width / 3) {
                  handleCustomChapterNav('prev');
                } else if (clickX > (width * 2) / 3) {
                  handleCustomChapterNav('next');
                }
              }
            }}
          >
            <div 
              className="max-w-4xl mx-auto p-8"
              style={{
                color: themeStyles.text,
                fontFamily: settings.fontFamily === 'serif' 
                  ? '"Songti SC", "SimSun", "宋体", "STSong", serif'
                  : '-apple-system, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", "WenQuanYi Micro Hei", sans-serif',
                fontSize: `${settings.fontSize}px`,
                lineHeight: settings.lineHeight,
                padding: `${settings.margin}px`,
              }}
              dangerouslySetInnerHTML={{ 
                __html: customChapters[currentChapterIndex]?.html || '' 
              }}
            />
        </div>
      )}

      {/* 目录侧边栏 */}
      {showTOC && (
        <div
          className={`fixed top-0 ${isMobile ? 'left-0 right-0' : 'right-0 w-80'} h-full z-40 overflow-y-auto`}
          style={{
            backgroundColor: themeStyles.bg,
            borderLeft: isMobile ? 'none' : `1px solid ${themeStyles.border}`,
            boxShadow: isMobile ? 'none' : `-2px 0 8px rgba(0,0,0,0.1)`,
          }}
        >
          <div className="p-4 border-b" style={{ borderColor: themeStyles.border }}>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold" style={{ color: themeStyles.text }}>目录</h2>
              <button
                onClick={() => setShowTOC(false)}
                className="p-1 rounded-lg hover:bg-opacity-10"
                style={{ color: themeStyles.text }}
              >
                <X size={20} />
              </button>
            </div>
          </div>
          <div className="p-4">
            {toc.map((item) => (
              <div key={item.id} className="mb-2">
                <button
                  onClick={() => {
                    if (readerEngine === 'epubjs' && epubjsRenditionRef.current && epubjsBookRef.current) {
                      const spine = epubjsBookRef.current.spine;
                      const chapterItem = spine.get(item.chapterIndex || 0);
                      if (chapterItem) {
                        epubjsRenditionRef.current.display(chapterItem.href);
                      }
                    } else if (readerEngine === 'react-reader' && reactReaderRenditionRef.current) {
                      // react-reader 的章节跳转需要通过 location
                      // 这里需要根据章节索引计算 location
                    } else if (readerEngine === 'custom' && item.chapterIndex !== undefined) {
                      goToChapter(item.chapterIndex);
                    }
                    setShowTOC(false);
                  }}
                  className="w-full text-left p-2 rounded-lg hover:bg-opacity-10 transition-colors"
                  style={{
                    color: themeStyles.text,
                    paddingLeft: `${(item.level - 1) * 16 + 8}px`,
                  }}
                >
                  {item.title}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
